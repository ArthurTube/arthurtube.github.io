"""Live clocks from timezone rules; supports classic-client omitted prepositions."""
from datetime import datetime, timezone
import os,re,subprocess,unicodedata

ZONES={
 'london':('London','Europe/London','GMT Standard Time'),
 'londres':('London','Europe/London','GMT Standard Time'),
 'lisbon':('Lisbon','Europe/Lisbon','GMT Standard Time'),
 'lisboa':('Lisbon','Europe/Lisbon','GMT Standard Time'),
 'sao paulo':('Sao Paulo','America/Sao_Paulo','E. South America Standard Time'),
 'brasilia':('Brasilia','America/Sao_Paulo','E. South America Standard Time'),
 'formosa':('Formosa, Goias','America/Sao_Paulo','E. South America Standard Time'),
 'goias':('Goias','America/Sao_Paulo','E. South America Standard Time'),
 'madrid':('Madrid','Europe/Madrid','Romance Standard Time'),
 'spain':('Mainland Spain (Madrid; Canary Islands use a different timezone)','Europe/Madrid','Romance Standard Time'),
 'canary islands':('Canary Islands','Atlantic/Canary','GMT Standard Time'),
 'tokyo':('Tokyo','Asia/Tokyo','Tokyo Standard Time'),
 'new york':('New York','America/New_York','Eastern Standard Time'),
 'sydney':('Sydney','Australia/Sydney','AUS Eastern Standard Time'),
 'paris':('Paris','Europe/Paris','Romance Standard Time'),
 'los angeles':('Los Angeles','America/Los_Angeles','Pacific Standard Time'),
 'utc':('UTC','UTC','UTC'),
}

def _clock(label,iana,windows):
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(timezone.utc).astimezone(ZoneInfo(iana)).strftime('In '+label+' it is %H:%M on %Y-%m-%d (%Z, UTC%z).')
    except (ImportError,KeyError):
        pass
    if os.name=='nt':
        # windows is selected only from the fixed mapping above.
        command="[TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([DateTimeOffset]::UtcNow, '"+windows+"').ToString('yyyy-MM-dd HH:mm zzz')"
        try:
            result=subprocess.run(['powershell','-NoProfile','-NonInteractive','-Command',command],capture_output=True,text=True,timeout=5)
            value=result.stdout.strip()
            if result.returncode==0 and re.fullmatch(r'\d{4}-\d{2}-\d{2} \d{2}:\d{2} [+-]\d{2}:\d{2}',value):
                return 'In '+label+' it is '+value+' (UTC offset shown).'
        except (OSError,subprocess.TimeoutExpired):pass
    return 'Timezone data is unavailable for '+label+'. I cannot calculate its current time.'

def clock_reply(question):
    clean=''.join(c for c in unicodedata.normalize('NFKD',str(question).lower()) if not unicodedata.combining(c))
    clean=re.sub(r'^\s*cyber\b[,:!; -]*','',clean)
    clean=' '.join(clean.rstrip('.?!').split())
    match=re.fullmatch(r'(?:what time is it|what is the time|time)(?:\s+(?:in|em))?\s+(.+)',clean)
    if not match:return None
    city=match[1].strip()
    if city not in ZONES:return 'Please name a supported city, for example London, Madrid, Sao Paulo, Tokyo or New York. I will not guess a timezone.'
    return _clock(*ZONES[city])

def london_time():return _clock(*ZONES['london'])
def is_london_clock_question(question):
    return bool(re.search(r'\blondon\b',str(question),re.I) and re.search(r'\btime\b',str(question),re.I))
