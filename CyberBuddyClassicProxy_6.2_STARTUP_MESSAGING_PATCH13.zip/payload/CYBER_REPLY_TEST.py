"""Experimental native reply format. Not a verified CyberBuddy implementation."""
import socket, selectors, re, time, hashlib
import cyber_bot
import cyber_web
import cyber_lan
print("BUILD:", cyber_bot.CYBER_BUILD)
print("Bot module:", cyber_bot.__file__)
print("Web module:", cyber_web.__file__)

def control_reply(data):
    # ME and MB share the native message parser; receipt is separate from text.
    text=data.decode('cp1252','replace')
    if not text.startswith('ME') or '&&EOT' not in text:
        return None
    sender=re.search(r'\$\$UIN\s*(\d+)',text)
    if not sender:return None
    # Native fields: local numeric identity, one-character state, requester,
    # message marker and local display name. Never put a timestamp here.
    return ('AK&&1111&&1&&%s&&M&&Cyber' % sender[1]).encode('cp1252')

def presence_reply(control):
    # Native ME handling sends presence (AW) and then receipt (AK).
    fields=control.decode('cp1252').split('&&')
    return ('AW&&'+'&&'.join(fields[1:4])+'&&').encode('cp1252')

def parse_message(data):
    text=data.decode('cp1252','replace')
    if text[:2] not in ('ME','MB') or '&&EOT' not in text:return None
    sender=re.search(r'\$\$UIN[ \t]*(\d+)',text)
    if not sender or sender[1]=='1111':return None
    content=text[:text.index('&&EOT')]
    headers=list(re.finditer(r'\$\$(?:UIN|SNDTO|MYIP|AWAY)[^\r\n]*',content))
    if not headers:return None
    body=content[max(m.end() for m in headers):].strip()
    # Character configuration is metadata, not conversation text.
    if '$$CC' in body:
        cc=body[body.index('$$CC'):]
        if '&&&&' in cc:
            body=cc.split('&&&&',1)[1].strip()
        elif '\n' in cc:
            body=cc.split('\n',1)[1].strip()
        else:
            # Native CC record ends with its numeric flag and separators.
            marker=re.search(r'&&0&&(?:&&)?',cc)
            if not marker:return None
            body=cc[marker.end():].strip()
    else:
        if '&&' in body and not body.startswith('&&'):
            character,body=body.split('&&',1)
            if len(character.strip())>80:return None
    # Character name precedes the body separator in the native constructor.
    body=re.sub(r'&&(?:uncertain|Decline|Search|Explain|Sad|Pleased|Blink|RestPose|Acknowledge|Alert|Announce|Confused|Read|Wave|Think|Congratulate)\b',' ',body,flags=re.I)
    # CC reserved flags and speech tags must not become part of the command.
    body=re.sub(r'^\s*(?:0&&(?:&&)?|&&0&&(?:&&)?)\s*','',body)
    body=re.sub(r'\\[A-Za-z]+(?:=[^\\]*)?\\',' ',body)
    body=' '.join(body.split())
    if not body or not re.search(r'[A-Za-zÀ-ÿ]',body):return None
    return text[:2],sender[1],body[:4000]

def attempt(data,reply_ip="127.0.0.2"):
    parsed=parse_message(data)
    if not parsed:return None
    kind,sender,question=parsed

    # One shared router handles native and console messages alike.
    # It owns profile writes, deletion, clocks and sourced research priorities.
    target_uin=_numeric_native_field(data,b'SNDTO')
    private=(target_uin=='1111') or kind=='ME'
    print('CHAT ROUTE: unified classic dispatcher; private='+str(private))
    answer=cyber_bot.reply(sender,question,private=private)
    if not answer:return None

    answer=str(answer).replace('&&',' and ').replace('\r',' ').replace('\n',' ')
    character='$$CCCyber&&CA141FD0-AC7F-11D1-97A3-006008273000&&150&&196&&&&0&&\r\n'
    # The transport supplies a validated local listener address, never packet text.
    reply_ip=str(__import__('ipaddress').IPv4Address(reply_ip))
    return ('%sCyber&&\r\n$$UIN1111\r\n\r\n$$SNDTO%s\r\n$$MYIP%s\r\n%s %s&&EOT' % (kind,sender,reply_ip,character,answer)).encode('cp1252','replace')

def configure_udp(sock):
    # Windows reports ICMP port-unreachable as a UDP receive reset.
    # Disable that notification where supported; also handle it in recv_local.
    if hasattr(sock,'ioctl') and hasattr(socket,'SIO_UDP_CONNRESET'):
        try: sock.ioctl(socket.SIO_UDP_CONNRESET,False)
        except OSError: pass

def recv_local(sock):
    try: return sock.recvfrom(65535)
    except (ConnectionResetError,BlockingIOError): return None
    except OSError as error:
        if getattr(error,'winerror',None) in (10054,10035): return None
        raise

def local_addresses():
    addresses={'127.0.0.1','127.0.0.2'}
    try:
        addresses.update(socket.gethostbyname_ex(socket.gethostname())[2])
        addresses.update(item[4][0] for item in socket.getaddrinfo(socket.gethostname(),None,socket.AF_INET))
    except OSError: pass
    return addresses

def reply_address(data,peer):
    # CyberBuddy advertises its receive interface separately from the UDP sender.
    match=re.search(rb'\$\$MYIP\s*([0-9.]+)',data)
    if match:
        advertised=match[1].decode('ascii')
        if advertised in local_addresses(): return advertised
    return peer[0]

def send_local(sock,payload,peer,receive_address=None):
    # The native app receives on its configured port, often not the source port.
    # Loopback destinations only; do not use addresses supplied in packet text.
    sent=0
    targets={(peer[0],peer[1]),(peer[0],4010),(peer[0],80)}
    if receive_address in local_addresses():
        targets.update({(receive_address,4010),(receive_address,80)})
    for target in targets:
        try:
            sock.sendto(payload,target)
            sent+=1
        except OSError:
            # One unavailable destination must not stop the receiver.
            continue
    return sent>0

def _numeric_native_field(data, field):
    """Read a numeric UIN field without mistaking an IPv4 prefix (127.0.0.2 -> 127) for a UIN."""
    match=re.search(rb'\$\$'+field+rb'[ \t]*([^\r\n& ]+)',data)
    if not match:return ''
    token=match[1]
    return token.decode('ascii') if re.fullmatch(rb'\d+',token) else ''

def native_route_fields(data):
    """Return sender/destination UINs only when the complete native field is numeric."""
    return (_numeric_native_field(data,b'UIN'),_numeric_native_field(data,b'SNDTO'))

def relay_packet(data, reply_ip):
    """Keep the original native packet/$$CC record but route replies back through this server."""
    ip=str(__import__('ipaddress').IPv4Address(reply_ip)).encode('ascii')
    if re.search(rb'\$\$MYIP[ \t]*[0-9.]+',data):
        return re.sub(rb'\$\$MYIP[ \t]*[0-9.]+',b'$$MYIP'+ip,data,count=1)
    # Do not fabricate other protocol fields.  If MYIP is absent, preserve bytes exactly.
    return data

def relay_to_peer(sock, payload, target_peer):
    """Relay only to the server-observed private peer; packet text never chooses the address."""
    sent=0
    host,source_port=target_peer
    for target in {(host,source_port),(host,4010),(host,80)}:
        try:
            sock.sendto(payload,target); sent+=1
        except OSError:
            continue
    return sent>0

def diagnostic(data):
    # Report protocol structure only; never print message text, IDs or addresses.
    prefix=data[:2].decode('ascii','replace')
    kind=prefix if prefix in ('MB','ME','SQ','XO','OX','SY','AK','AW','HM') else 'unknown'
    fields=[m.decode('ascii') for m in re.findall(rb'\$\$(?:MYIP|UIN|SNDTO|AWAY)',data)]
    return 'type=%s bytes=%d fields=%s EOT=%s' % (kind,len(data),','.join(fields) or 'none',b'&&EOT' in data)

def main():
    try:settings=cyber_lan.read_settings()
    except (OSError,ValueError,TypeError) as error:
        print('LAN configuration error:',error)
        print('Falling back to the existing LOCAL-ONLY bot. No memory/settings were reset.')
        settings={'enabled':False,'host_ip':None,'allowed_clients':[],'auto':False}
    poll=selectors.DefaultSelector();sockets=[];bindings=[];recent={};next_status=0;active_peers={};pending_packets={}
    addresses=['127.0.0.2']+([settings['host_ip']] if settings['enabled'] else [])
    for address in addresses:
        for port in (80,4010):
            sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            configure_udp(sock)
            try:
                sock.bind((address,port));sock.setblocking(False)
                poll.register(sock,selectors.EVENT_READ,(address,port));sockets.append(sock);bindings.append((address,port))
            except OSError as error:
                sock.close();print('Cannot listen on UDP',address,port,':',error)
    if not sockets:
        cyber_lan.write_status([],settings,active=False)
        print('No native listeners are available. Check port conflicts; no socket-sharing workaround was enabled.')
        return
    print('CyberBuddy native transport - optional LAN Patch 12')
    print('Build:',cyber_bot.CYBER_BUILD)
    print('Memory file:',cyber_bot.MEMORY.resolve())
    print('Listening:',bindings)
    if settings['enabled']:
        if settings.get('auto'):
            print('AUTO PRIVATE-LAN mode: host interface detected automatically; same private LAN clients allowed.')
            print('LAN host:',settings['host_ip'],'; no CONFIGURE_NATIVE_LAN step required.')
        else:
            print('LAN host:',settings['host_ip'],'; trusted client count:',len(settings['allowed_clients']))
        if not any(ip==settings['host_ip'] for ip,port in bindings):
            print('LAN is NOT available. Close the original CyberBuddy app on the hosting PC if it owns these UDP ports, then restart the services.')
    else:print('LOCAL-ONLY mode: no usable private LAN/VPN interface was detected.')
    print('No message bodies are logged. Ctrl+C closes this service.')
    try:
        while True:
            if time.monotonic()>=next_status:
                cyber_lan.write_status(bindings,settings);next_status=time.monotonic()+5
            for key,_ in poll.select(1):
                packet=recv_local(key.fileobj)
                if packet is None:continue
                data,peer=packet
                if not cyber_lan.allowed_peer(peer[0],settings):
                    print('Ignored a sender outside the configured trusted clients.');continue
                listen_address,port=key.data
                # Reply to the actual source only; an advertised MYIP cannot redirect traffic.
                remote=not __import__('ipaddress').ip_address(peer[0]).is_loopback
                receive_address=peer[0] if remote else reply_address(data,peer)
                reply_ip=listen_address
                signature=hashlib.sha256(peer[0].encode()+b'\0'+data).digest();now=time.monotonic()
                if recent.get(signature,0)>now-3:continue
                recent={k:v for k,v in recent.items() if v>now-3};recent[signature]=now
                try:
                    sender_uin,target_uin=native_route_fields(data)
                    if sender_uin:
                        # Identity is mapped only to the address actually observed by the server.
                        active_peers[sender_uin]=(peer[0],peer[1],now)
                        # A client may become reachable after another user already sent to it.
                        # Flush only packets queued for this exact UIN, to this observed peer.
                        waiting=pending_packets.pop(sender_uin,[])
                        for queued_payload,queued_at in waiting:
                            if queued_at > now-300:
                                relay_to_peer(key.fileobj,queued_payload,(peer[0],peer[1]))
                        if waiting:
                            print('Queued native chat delivery retried for a connected client; IDs hidden.')
                    # Cyber 1111 keeps the existing bot path unchanged. Every other destination
                    # uses the original ME/MB packet including its $$CC character record.
                    if sender_uin and target_uin and target_uin != '1111':
                        # User-to-user sends need the same sender-side receipt behavior as the
                        # working Cyber 1111 path. Previously this branch continued before AK.
                        control=control_reply(data)
                        if control:
                            send_local(key.fileobj,control,peer,receive_address)
                        destination=active_peers.get(target_uin)
                        forwarded=relay_packet(data,reply_ip)
                        if destination and destination[2] > now-300:
                            if relay_to_peer(key.fileobj,forwarded,destination[:2]):
                                print('Native user-to-user packet relayed; sender receipt returned; IDs hidden.')
                            else:
                                print('Native user-to-user relay failed; listener remains active.')
                        else:
                            # Do not throw the chat message away just because the recipient has
                            # not yet emitted a native packet during this relay process lifetime.
                            queue=pending_packets.setdefault(target_uin,[])
                            queue.append((forwarded,now))
                            pending_packets[target_uin]=queue[-20:]
                            print('Native destination not active yet; message queued briefly; IDs hidden.')
                        continue
                    control=control_reply(data)
                    if control:send_local(key.fileobj,control,peer,receive_address)
                    response=attempt(data,reply_ip=reply_ip)
                except (OSError,ValueError,TypeError):print('Native reply generation failed.');continue
                if response:
                    if send_local(key.fileobj,response,peer,receive_address):print('Native reply packet sent; client receipt still needs confirmation.')
                    else:print('Reply send failed; listener remains active.')
                else:print('Received: '+diagnostic(data))
    except KeyboardInterrupt:pass
    finally:
        try:cyber_lan.write_status(bindings,settings,active=False)
        except OSError:pass
        for sock in sockets:sock.close()
        poll.close()
if __name__=='__main__':main()
