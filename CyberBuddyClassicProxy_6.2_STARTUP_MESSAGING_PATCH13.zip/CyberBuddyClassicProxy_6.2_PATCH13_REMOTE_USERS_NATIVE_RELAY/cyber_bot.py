"""Unofficial local Cyber recreation. No API keys or network access."""
import json, re, threading
from pathlib import Path
from datetime import datetime, date, timedelta
LOCK = threading.Lock()
MEMORY = Path(__file__).with_name('cyber_memory.json')

def reply(user, text, private=True):
    text = text.strip()
    called = re.match(r'^cyber\b[,:! ]*', text, re.I)
    if not private and not called: return ''
    if called: text = text[called.end():].strip()
    if not text: return 'Yes? I am here.'
    with LOCK:
        try: data = json.loads(MEMORY.read_text(encoding='utf-8'))
        except (OSError, ValueError): data = {}
        if not isinstance(data, dict): data = {}
        profile = data.setdefault(str(user), {})
        if not isinstance(profile, dict): profile = {}; data[str(user)] = profile
        low = text.lower().rstrip('?.!')
        answer = None
        if low in ('forget me', 'delete my memory'):
            data.pop(str(user), None); answer = 'I have forgotten your saved information.'
        for pattern, key in [(r'my name is (.+)', 'name'), (r'i live in (.+)', 'location'), (r'i am (a boy|a girl|male|female)', 'gender'), (r'my website is (.+)', 'website'), (r'my email is (.+)', 'email')]:
            match = re.fullmatch(pattern, text, re.I)
            if match:
                profile[key] = match[1].strip()[:240]; answer = 'I will remember that.'; break
        match = re.fullmatch(r'my birthdate is (\d{2}/\d{2}/\d{4})', text, re.I)
        if match:
            try:
                born = datetime.strptime(match[1], '%m/%d/%Y').date()
                if born > date.today(): raise ValueError()
                profile['birthdate'] = born.isoformat(); answer = 'I have remembered your birthday.'
            except ValueError: answer = 'Please use a valid past date: MM/DD/YYYY.'
        match = re.fullmatch(r'the time here is (.+)', text, re.I)
        if match:
            try:
                clock = datetime.strptime(match[1].upper(), '%I:%M %p')
                now = datetime.now(); offset = clock.hour*60 + clock.minute - now.hour*60 - now.minute
                profile['clock_offset_minutes'] = (offset+720)%1440-720
                answer = 'I have remembered the current clock difference. Daylight-saving changes may need an update.'
            except ValueError: answer = 'Use a time such as 8:30 AM.'
        match = re.fullmatch(r'remember (.+?) is (.+)', text, re.I)
        if match:
            profile.setdefault('facts', {})[match[1].strip().lower()[:120]] = match[2].strip()[:500]
            answer = 'I have learned that from you.'
        if answer is None:
            if low in ('are you there','hello','hi'): answer = 'Hello! I am Cyber. I am here.'
            elif low in ('what is my name','who am i'): answer = profile.get('name','You have not told me your name yet.')
            elif low == 'where do i live': answer = profile.get('location','You have not told me where you live.')
            elif low in ('how old am i','how many days until my birthday','when is my birthday'):
                if 'birthdate' not in profile: answer = 'Tell me: Cyber, my birthdate is MM/DD/YYYY.'
                else:
                    born = date.fromisoformat(profile['birthdate']); today = date.today()
                    def anniversary(year):
                        try: return born.replace(year=year)
                        except ValueError: return date(year,2,28)
                    birthday = anniversary(today.year)
                    age = today.year-born.year-(today<birthday)
                    if birthday<today: birthday=anniversary(today.year+1)
                    answer = f'You are {age} years old. Your next birthday is in {(birthday-today).days} days.'
            elif low == 'what time is it':
                clock=datetime.now()+timedelta(minutes=profile.get('clock_offset_minutes',0))
                answer=clock.strftime('The time is %I:%M %p.')
            elif low.startswith('what is '): answer = profile.get('facts',{}).get(low[8:], 'I do not know that yet. Teach me with: Cyber, remember something is an explanation.')
            elif low == 'help': answer = 'Tell me your name, location or birthday. Ask how old you are. Teach me with remember X is Y. Say forget me to delete your memory.'
            else: answer = 'I do not understand that yet. Type Cyber, help for commands.'
        temporary=MEMORY.with_suffix('.json.tmp')
        temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');temporary.replace(MEMORY)
        return answer

# Expanded documented teaching commands. Memory remains separated by user.
_basic_reply = reply

def _calculate(expression):
    import ast, operator
    if len(expression) > 120: raise ValueError()
    tree = ast.parse(expression, mode='eval')
    ops = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
           ast.Div: operator.truediv, ast.Mod: operator.mod}
    def visit(node):
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            if abs(node.value) > 1e12: raise ValueError()
            return node.value
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
            return -visit(node.operand) if isinstance(node.op, ast.USub) else visit(node.operand)
        if isinstance(node, ast.BinOp) and type(node.op) in ops:
            value = ops[type(node.op)](visit(node.left), visit(node.right))
            if abs(value) > 1e15: raise ValueError()
            return value
        raise ValueError()
    return visit(tree.body)

def reply(user, text, private=True):
    raw = text.strip()
    call = re.match(r'^cyber\b[,:! ]*', raw, re.I)
    if not private and not call: return ''
    if call: raw = raw[call.end():].strip()
    clean = raw.rstrip('.?!').strip()
    low = clean.lower()
    if re.match(r'^research\b',clean,re.I):
        import cyber_web
        return cyber_web.research(clean)
    response = None
    with LOCK:
        try: data = json.loads(MEMORY.read_text(encoding='utf-8'))
        except (OSError, ValueError): data = {}
        if not isinstance(data, dict): data = {}
        profile = data.setdefault(str(user), {})
        if not isinstance(profile, dict): profile={};data[str(user)]=profile
        facts = profile.setdefault('facts', {})
        synonyms = profile.setdefault('synonyms', {})
        m = re.fullmatch(r'"(.+?)" is (not )?the same as "(.+?)"', clean, re.I)
        if m:
            key=m[1].lower(); value=m[3]
            if m[2]:
                if synonyms.get(key, '').lower() == value.lower(): synonyms.pop(key,None)
                response='I have removed that synonym association.'
            else: synonyms[key]=value; response='I have learned that phrase.'
        m = re.fullmatch(r'(.+?) is not (?:a |an )?(.+)',clean,re.I)
        if m and response is None:
            key=m[1].strip('"').lower(); value=m[2].strip('"')
            if re.sub(r'^(?:a|an) ', '', facts.get(key, '').lower()) == re.sub(r'^(?:a|an) ', '', value.lower()): facts.pop(key,None)
            response='I have removed that association if it matched.'
        m = re.fullmatch(r'message for "(.+?)" message is "(.+)"',clean,re.I)
        if m:
            recipient=m[1]; found=re.search(r'\bUIN (\d+)\b',recipient,re.I)
            target=found[1] if found else None
            if target is None:
                matches=[k for k,v in data.items() if isinstance(v,dict) and v.get('name','').lower()==recipient.lower()]
                target=matches[0] if len(matches)==1 else None
            if target and target != '1111':
                dest=data.setdefault(target,{})
                if isinstance(dest,dict):
                    queue=dest.setdefault('pending',[])
                    if len(queue)<100:
                        queue.append({'sender':str(user),'text':m[2][:4000]});response='I saved the message. I will show it when that user next speaks to me.'
                    else: response='That local inbox is full.'
            if response is None: response='Please identify the recipient by UIN.'
        if low in ('i am back','i am here'): profile.pop('away',None);response='Welcome back.'
        elif low.startswith('tell everyone '): profile['away']=clean[14:];response='I saved your away status.'
        elif low.startswith('i will be '): profile['away']=clean;response='I saved your away status.'
        if low == 'what is the date': response=date.today().isoformat()
        if low.startswith('calculate '):
            try: response=str(_calculate(clean[10:]))
            except (ValueError, SyntaxError, ZeroDivisionError, OverflowError): response='Use numbers with +, -, *, /, % and parentheses.'
        if low.startswith('where is '):
            name=low[9:]
            matches=[v for v in data.values() if isinstance(v,dict) and v.get('name','').lower()==name]
            response=(matches[0].get('away','No away status was saved.') if len(matches)==1 else 'I cannot uniquely identify that name.')
        if response is None and low in synonyms:
            low=synonyms[low].lower().rstrip('.?!')
            if low in ('good bye','goodbye'): response='Goodbye!'
            elif low in ('hello','hi'): response='Hello!'
        m=re.fullmatch(r'(?:what|who) is (.+)',low)
        if response is None and m and m[1] in facts: response=facts[m[1]]
        m=re.fullmatch(r'(.+?) is (.+)',clean,re.I)
        if response is None and m and not low.startswith(('what ','who ','my ','remember ')):
            facts[m[1].lower()]=m[2][:500];response='I have learned that association from you.'
        if response is None and low.startswith('i like '): profile['likes']=clean[7:];response='I will remember what you like.'
        if response is None and low.startswith('i have '): profile['possessions']=clean[7:];response='I will remember that.'
        if low == 'help': response='Teach: "Adios" is the same as "Good Bye". Teach: Bob is a fireman. Correct: Bob is not a fireman. Leave messages: message for "UIN 1000" message is "Hello". Calculate: calculate 2+3. Say forget me to erase your profile.'
        pending=profile.pop('pending',[]) if low not in ('forget me','delete my memory') else []
        temp=MEMORY.with_suffix('.json.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(MEMORY)
    if response is None: response=_basic_reply(user,text,private)
    if pending: response += ' Saved messages: ' + ' '.join('From UIN '+item['sender']+': '+item['text'] for item in pending)
    return response

# Common questions from the original Cyber help examples.
_documented_reply = reply

def _london_time():
    from datetime import timezone
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(timezone.utc).astimezone(ZoneInfo('Europe/London')).strftime('In London it is %I:%M %p (%Z).')
    except (ImportError, KeyError):
        import os, subprocess
        if os.name != 'nt': return 'London time-zone data is unavailable on this computer.'
        # Use Windows' installed timezone rules, including daylight saving.
        command="[TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([DateTime]::UtcNow, 'GMT Standard Time').ToString('HH:mm')"
        try:
            result=subprocess.run(['powershell','-NoProfile','-NonInteractive','-Command',command],capture_output=True,text=True,timeout=4)
            clock=result.stdout.strip()
            if result.returncode==0 and re.fullmatch(r'\d{2}:\d{2}',clock):return 'In London it is '+clock+'.'
        except (OSError,subprocess.TimeoutExpired):pass
        return 'I could not read the London time zone from Windows.'

def reply(user,text,private=True):
    raw=' '.join(str(text).split())
    called=re.match(r'^cyber\b[,:! ]*',raw,re.I)
    if not private and not called:return ''
    clean=(raw[called.end():] if called else raw).strip().rstrip('.?!').strip()
    low=clean.lower()
    if low in ('what is today','what day is it','what is the date','what is today s date',"what is today's date"):
        return datetime.now().strftime('Today is %A, %B %d, %Y.')
    if re.fullmatch(r'what time is it in london',low):return _london_time()
    if low in ('r u there','are u there','are you there'):
        return 'Hello! I am Cyber. I am here.'
    expression=re.sub(r'^(?:what is|calculate)\s+','',clean,flags=re.I)
    for word,symbol in [('divided by','/'),('multiplied by','*'),('times','*'),('plus','+'),('minus','-')]:
        expression=re.sub(r'\b'+word+r'\b',symbol,expression,flags=re.I)
    expression=re.sub(r'(?<=\d)\s*[xX]\s*(?=\d)','*',expression)
    if re.fullmatch(r'[0-9\s.+*/%()\-]+',expression) and re.search(r'\d',expression):
        try:
            value=_calculate(expression)
            if isinstance(value,float) and value.is_integer():value=int(value)
            return 'The answer is '+str(value)+'.'
        except (ValueError,SyntaxError,ZeroDivisionError,OverflowError):return 'I cannot calculate that expression. Check the numbers and operators.'
    return _documented_reply(user,text,private)

# Keep deterministic teaching/date/math features; use local LLM for unknowns.
_rule_reply = reply
def reply(user,text,private=True):
    raw=' '.join(str(text).split())
    called=re.match(r'^cyber\b[,:! ]*',raw,re.I)
    if not private and not called:return ''
    clean=(raw[called.end():] if called else raw).strip().rstrip('.?!').strip()
    low=clean.lower()
    # Personal fields must take priority over generic "X is Y" teaching.
    if low.startswith('my birthdate is '):
        value=clean[len('my birthdate is '):]
        value=re.sub(r'(\d)(st|nd|rd|th)\b',r'\1',value,flags=re.I)
        born=None
        for fmt in ('%m/%d/%Y','%B %d, %Y','%B %d %Y','%b %d, %Y','%Y-%m-%d'):
            try:born=datetime.strptime(value,fmt).date();break
            except ValueError:pass
        if born is None:return 'Use a birthdate such as April 3, 2011 or 04/03/2011.'
        return _basic_reply(user,'Cyber, my birthdate is '+born.strftime('%m/%d/%Y'),private)
    if any(low.startswith(prefix) for prefix in ('my name is ','i live in ','my website is ','my email is ','the time here is ')) or low in ('i am a boy','i am a girl','i am male','i am female'):
        return _basic_reply(user,'Cyber, '+clean,private)
    if low in ('how long until my birthday','how many days until my birthday','when is my birthday','how old am i'):
        query='how old am i' if low=='how old am i' else 'how many days until my birthday'
        return _basic_reply(user,'Cyber, '+query,private)
    if low in ('what do you know about me','what is my horoscope','what is my sign'):
        with LOCK:
            try:profiles=json.loads(MEMORY.read_text(encoding='utf-8'))
            except (OSError,ValueError):profiles={}
            profile=profiles.get(str(user),{}) if isinstance(profiles,dict) else {}
            if not isinstance(profile,dict):profile={}
        if low=='what do you know about me':
            info=[key+': '+str(profile[key]) for key in ('name','location','gender','birthdate','website','likes') if key in profile]
            return 'I remember '+('; '.join(info)+'.' if info else 'nothing about you yet. Tell me your name or birthday.')
        if 'birthdate' not in profile:return 'Tell me: Cyber, my birthdate is April 3, 2011.'
        try:born=date.fromisoformat(profile['birthdate'])
        except (ValueError,TypeError):return 'Please tell me your birthdate again.'
        cuts=[(1,20,'Aquarius'),(2,19,'Pisces'),(3,21,'Aries'),(4,20,'Taurus'),(5,21,'Gemini'),(6,21,'Cancer'),(7,23,'Leo'),(8,23,'Virgo'),(9,23,'Libra'),(10,23,'Scorpio'),(11,22,'Sagittarius'),(12,22,'Capricorn')]
        sign='Capricorn'
        for month,day,name in cuts:
            if (born.month,born.day)>=(month,day):sign=name
        return 'Your traditional Western zodiac sign is '+sign+'. I do not predict the future.'
    if low.startswith('research '):
        return 'I have no web-search connection. I can answer from local model knowledge, but I cannot claim an Internet research result.'
    result=_rule_reply(user,'Cyber, '+clean,private)
    if isinstance(result,str) and result.startswith(('I do not know that yet.','I do not understand that yet.')):
        import cyber_ai
        return cyber_ai.answer(user,text)
    if str(text).lower().strip().rstrip('.?!') in ('cyber, forget me','forget me','cyber, delete my memory','delete my memory'):
        import cyber_ai
        with cyber_ai.LOCK:cyber_ai.HISTORY.pop(str(user),None)
    return result

# Normalize legacy formatting before intent selection; never ask the LLM for
# live clocks, directory presence, or a claimed web-research result.
_profile_reply=reply

def reply(user,text,private=True):
    raw=str(text).replace('\u200b','').replace('\ufeff','')
    raw=re.sub(r'&&[A-Za-z]+\b',' ',raw)
    raw=re.sub(r'\\(?:pau|spd|pit|emp|chr|rst|vol)(?:=[^\\]*)?\\',' ',raw,flags=re.I)
    raw=' '.join(raw.split())
    called=re.match(r'^cyber\b[,:! ]*',raw,re.I)
    if not private and not called:return ''
    clean=raw
    while re.match(r'^cyber\b[,:! ]*',clean,re.I):
        clean=re.sub(r'^cyber\b[,:! ]*','',clean,count=1,flags=re.I).strip()
    clean=clean.rstrip('.?!').strip();low=clean.lower()
    if re.search(r'\bwhat time is it in london\b',low):return _london_time()
    if re.search(r'\bresearch\b',low):return 'I am not connected to web search. I cannot verify an Internet research result.'
    if re.search(r'\b(?:u[ -]*i[ -]*n)\s*\d+\s+last\s+on\b',low):
        return 'UIN means User Identification Number. I have no verified last-online information for that user.'
    if re.fullmatch(r"what is (?:john(?:'s| s)|someone(?:'s| s)) web ?site",low):
        return 'I have no verified website saved for that person.'
    location=re.search(r'\bi live in (.+)$',clean,re.I)
    if location:return _basic_reply(user,'Cyber, I live in '+location[1].strip().rstrip('.?!'),private)
    if low in ('who are you talking to','what are my lucky numbers','tell me some trivia','nevermind','never mind'):
        if low in ('nevermind','never mind'):return 'Okay.'
        if low=='tell me some trivia':
            import random
            return random.choice(['An octopus has three hearts.','Venus rotates in the opposite direction to Earth.','The Pacific Ocean is the largest ocean on Earth.','The Moon takes about 27 days to orbit Earth.'])
        if low=='what are my lucky numbers':
            import random,hashlib
            seed=hashlib.sha256((str(user)+date.today().isoformat()).encode()).digest()
            numbers=sorted(random.Random(seed).sample(range(1,50),6))
            return 'For fun only: '+', '.join(map(str,numbers))+'. These numbers do not predict luck.'
        with LOCK:
            try:profiles=json.loads(MEMORY.read_text(encoding='utf-8'))
            except (OSError,ValueError):profiles={}
            profile=profiles.get(str(user),{}) if isinstance(profiles,dict) else {}
            name=profile.get('name') if isinstance(profile,dict) else None
        return 'I am talking to '+(str(name)+'.' if name else 'you. Tell me your name if you like.')
    return _profile_reply(user,'Cyber, '+clean,private)

# Enforce live clocks in both HTTP bot calls and native UDP calls.
_clock_safe_reply=reply
def reply(user,text,private=True):
    raw=str(text).strip()
    raw=re.sub(r'^[\s>*\-]+','',raw)
    called=re.match(r'^cyber\b[,:! ]*',raw,re.I)
    if not private and not called:return ''
    clean=(raw[called.end():] if called else raw).strip()
    import cyber_clock
    clock=cyber_clock.clock_reply(clean)
    if clock is not None:return clock
    return _clock_safe_reply(user,raw,private)

# Published local presence lookup takes priority over model guesses.
_directory_reply=reply
def reply(user,text,private=True):
    if not private and not re.match(r'^\s*cyber\b',str(text),re.I):return ''
    import cyber_directory
    result=cyber_directory.last_online(text)
    if result is not None:return result
    return _directory_reply(user,text,private)

# Exact integer factors and primality; model predictions are not used.
_number_reply=reply
def reply(user,text,private=True):
    import math
    raw=' '.join(str(text).split())
    called=re.match(r'^cyber\b[,:! ]*',raw,re.I)
    if not private and not called:return ''
    clean=(raw[called.end():] if called else raw).strip().rstrip('.?!').strip().lower()
    factor=re.fullmatch(r'(?:what (?:is|are) (?:the )?)?(?:factors|divisors) of ([+-]?\d+)',clean)
    prime=re.fullmatch(r'is ([+-]?\d+) (?:a )?prime(?: number)?',clean)
    pairs=re.fullmatch(r'(?:what (?:is|are) (?:the )?)?factor pairs? of ([+-]?\d+)',clean)
    closest=re.fullmatch(r'(?:what (?:is|are) (?:the )?)?closest factor(?: pairs?)? of ([+-]?\d+)',clean)
    match=factor or prime or pairs or closest
    if match:
        number=int(match[1])
        if number<=0:return 'Use a positive integer. Prime numbers are integers greater than 1.'
        if number>10**12:return 'Exact factor checking is limited to numbers up to 1,000,000,000,000 in this local bot.'
        small=[];large=[]
        for divisor in range(1,math.isqrt(number)+1):
            if number%divisor==0:
                small.append(divisor)
                partner=number//divisor
                if partner!=divisor:large.append(partner)
        factors=small+list(reversed(large))
        is_prime=number>1 and len(factors)==2
        if closest:
            lower=small[-1];upper=number//lower
            return 'The closest positive factor pair of '+str(number)+' is '+str(lower)+' x '+str(upper)+'. These two factors are nearest to each other.'
        if pairs:
            if len(small)>100:return 'There are '+str(len(small))+' positive factor pairs; the full list is too long for one chat reply.'
            return 'The positive factor pairs of '+str(number)+' are '+', '.join(str(n)+' x '+str(number//n) for n in small)+'.'
        if prime:
            return ('Yes, ' if is_prime else 'No, ')+str(number)+(' is a prime number.' if is_prime else ' is not a prime number.')
        if len(factors)>150:return str(number)+' has '+str(len(factors))+' positive factors; the list is too long for a short chat response.'
        return 'The positive factors of '+str(number)+' are '+', '.join(map(str,factors))+'.'+(' It is prime.' if is_prime else '')
    return _number_reply(user,text,private)

_exact39_reply = reply

# Local calculators take priority over conversational AI.
_calculator_reply=reply
def reply(user,text,private=True):
    if not private and not re.match(r'^\s*cyber\b',str(text),re.I):return ''
    import cyber_calculators
    result=cyber_calculators.calculate(text)
    if result is not None:return result
    return _calculator_reply(user,text,private)

# Route biographical dates and conflict questions away from model guesses.
_factual_reply=reply
def reply(user,text,private=True):
    raw=' '.join(str(text).split())
    called=re.match(r'^cyber\b[,:! ]*',raw,re.I)
    if not private and not called:return ''
    clean=(raw[called.end():] if called else raw).strip().rstrip('.?!').strip()
    if clean.lower() in ("what's my name",'what is my name','do you remember my name'):
        return _factual_reply(user,'Cyber, what is my name',True)
    if re.fullmatch(r'when (?:was|did) .+ (?:born|die|died)',clean,re.I):
        import cyber_web
        return cyber_web.research('research '+clean)
    war=re.fullmatch(r'how long (?:will|did|does|has) (.+?) (?:last|lasted)',clean,re.I)
    if war:
        subject=war[1]
        subject=re.sub(r'\bww1\b','World War I',subject,flags=re.I)
        subject=re.sub(r'\bww2\b','World War II',subject,flags=re.I)
        import cyber_web
        return 'I cannot predict when a war will end. '+cyber_web.research('research '+subject)
    return _factual_reply(user,text,private)

# Experimental 28: Wikipedia factual-question router and historical duration correction.
_wikipedia_reply=reply
def reply(user,text,private=True):
    raw=' '.join(str(text).split())
    called=re.match(r'^cyber\b[,:! ]*',raw,re.I)
    if not private and not called:return ''
    clean=(raw[called.end():] if called else raw).strip().rstrip('.?!').strip()
    low=clean.lower()
    import cyber_web
    # Explicit Wikipedia lookup always uses the sourced Wikipedia path.
    explicit=re.match(r'^(?:search|look up|lookup|check)\s+(?:on\s+)?wikipedia\s+(?:for\s+)?(.+)$',clean,re.I)
    explicit2=re.match(r'^wikipedia\s*[:,]?\s*(.+)$',clean,re.I)
    if explicit or explicit2:
        return cyber_web.wikipedia_answer((explicit or explicit2).group(1))
    # Correct "how long will X last" by checking Wikipedia dates first instead of
    # automatically treating every subject as an ongoing war.
    if re.fullmatch(r'how long (?:will|did|does|has) .+? (?:last|lasted)',clean,re.I):
        return cyber_web.wikipedia_answer(clean)
    # Factual questions that are naturally answered by an encyclopedia.
    # Personal-memory, clock, calculator and local-service questions stay on existing routes.
    personal=(' my ',' me ',' i ',' you ',' your ',' cyber')
    factual=bool(re.match(r'^(?:who (?:is|was|were)|what (?:is|was|were)|where (?:is|was|were|did)|when (?:is|was|were|did)|how old (?:is|was)|how many years did)\b',low))
    if factual and not any(x in ' '+low+' ' for x in personal):
        return cyber_web.wikipedia_answer(clean)
    return _wikipedia_reply(user,text,private)

# Experimental 31: future prediction guard.
# Handle unknowable future outcomes before generic conversational/model fallbacks.
_prediction_reply=reply
def reply(user,text,private=True):
    raw=' '.join(str(text).split())
    called=re.match(r'^cyber\b[,:! ]*',raw,re.I)
    if not private and not called:return ''
    clean=(raw[called.end():] if called else raw).strip().rstrip('.?!').strip()
    low=clean.lower()

    # "When will the next ... happen?" has no verified future date.
    m=re.fullmatch(r'when will (.+?) (?:happen|occur|start|begin)',clean,re.I)
    if m:
        subject=m.group(1).strip()
        return 'I cannot reliably predict when '+subject+' will happen. There is no verified date for that future event.'

    # Tournament/election/award and similar future winners cannot be known in advance.
    m=re.fullmatch(r'who will win (.+)',clean,re.I)
    if m:
        subject=m.group(1).strip()
        return 'I cannot reliably predict who will win '+subject+'. The winner will be determined by the actual results.'

    # Generic future-event yes/no questions. Keep factual "will X last" on the
    # Wikipedia duration path, which can distinguish completed and ongoing events.
    m=re.fullmatch(r'will (.+?) (?:happen|occur)',clean,re.I)
    if m:
        subject=m.group(1).strip()
        return 'I cannot reliably predict whether '+subject+' will happen.'

    return _prediction_reply(user,text,private)


# Experimental 33: biography-status and direct historical-date guard.
_exp33_reply=reply
def reply(user,text,private=True):
    raw=' '.join(str(text).split())
    called=re.match(r'^cyber\b[,:! ]*',raw,re.I)
    if not private and not called:return ''
    clean=(raw[called.end():] if called else raw).strip().rstrip('.?!').strip()
    if re.fullmatch(r'is .+? still alive',clean,re.I) or re.fullmatch(r'when did .+? (?:launch|launched|fall|fell|sink|sank|end|ended|begin|began|start|started|collapse|collapsed|land|landed|die|died)',clean,re.I):
        import cyber_web
        return cyber_web.wikipedia_answer(clean)
    return _exp33_reply(user,text,private)


# Experimental 34: broad Wikipedia factual-intent guard.
_exp34_reply=reply
def reply(user,text,private=True):
    raw=' '.join(str(text).split())
    called=re.match(r'^cyber\b[,:! ]*',raw,re.I)
    if not private and not called:return ''
    clean=(raw[called.end():] if called else raw).strip().rstrip('.?!').strip()
    # Strip a spoken "Cyber," even if an older wrapper did not.
    clean=re.sub(r'^cyber\b[,:! ]*','',clean,flags=re.I).strip()
    low=clean.lower()
    # Preserve existing prediction guards by sending future predictions through the
    # previous chain. Route broad encyclopedia-style factual intents to Wikipedia.
    future=bool(re.match(r'^(?:when will|who will win|will .+ (?:happen|occur))\b',low))
    factual=bool(re.match(r'^(?:who (?:is|was|invented|founded|created|discovered|developed)|what (?:is|was|are|were)|where (?:is|was|are|were)|when (?:was|were|did)|why (?:did|does|do|was|were|is|are)|how (?:many|much|far|tall|high|large|big|old|long)|is .+ still alive|did |does |do |is |are |was |were |has |have )',low))
    personal=(' my ',' me ',' i ',' you ',' your ')
    if factual and not future and not any(x in ' '+low+' ' for x in personal):
        import cyber_web
        return cyber_web.wikipedia_answer(clean)
    return _exp34_reply(user,text,private)

# Experimental 35: scientific-estimate guard.
# Established scientific timescales are not the same as unknowable predictions.
_exp35_reply=reply
def reply(user,text,private=True):
    raw=' '.join(str(text).split())
    called=re.match(r'^cyber\b[,:! ]*',raw,re.I)
    if not private and not called:return ''
    clean=(raw[called.end():] if called else raw).strip().rstrip('.?!').strip()
    clean=re.sub(r'^cyber\b[,:! ]*','',clean,flags=re.I).strip()
    low=clean.lower()

    if re.fullmatch(r'when will (?:the )?sun (?:die|end|burn out)',low):
        return ('The Sun is expected to leave its current main-sequence stage in about 5 billion years. '
                'It will expand into a red giant and later shed its outer layers, leaving behind a white dwarf. '
                'The Sun is not massive enough to explode as a supernova. Source: https://en.wikipedia.org/wiki/Sun')

    if re.fullmatch(r'how long will (?:the )?sun last',low):
        return ('The Sun is about 4.6 billion years old and is expected to remain in its current main-sequence stage '
                'for about another 5 billion years. It will then evolve into a red giant and eventually a white dwarf. '
                'Source: https://en.wikipedia.org/wiki/Sun')

    return _exp35_reply(user,text,private)

# Version 39 repair: preserve Wikipedia validator, prioritize personal state.
def _v39_profile(user):
    with LOCK:
        try: data=json.loads(MEMORY.read_text(encoding='utf-8'))
        except (OSError,ValueError):return {}
        value=data.get(str(user),{}) if isinstance(data,dict) else {}
        return value if isinstance(value,dict) else {}
# Experimental 46f: unified per-UIN profile router.
# Personal statements/deletion and Cyber self-biography are resolved before any
# generic AI/research route so user data can never become Cyber's own identity.
_exp46f_previous_reply = reply
CYBER_BUILD = '6.2 - Profile and Runtime Marker Fix 1'

def _exp46f_clean(text):
    s = str(text).replace('\u200b','').replace('\ufeff','').replace('\xa0',' ')
    s = ''.join(ch if (ord(ch) >= 32 or ch in '\t\r\n') else ' ' for ch in s)
    s = ' '.join(s.split())
    s = re.sub(r'^\s*\[?\s*me\s+to\s*\]?\s*', '', s, flags=re.I)
    s = re.sub(r'^\s*cyber\b[,:!; -]*', '', s, flags=re.I)
    return s.strip()

def _exp46f_mutate_profile(user, mutator):
    with LOCK:
        try: data = json.loads(MEMORY.read_text(encoding='utf-8'))
        except (OSError, ValueError): data = {}
        if not isinstance(data, dict): data = {}
        profile = data.setdefault(str(user), {})
        if not isinstance(profile, dict):
            profile = {}; data[str(user)] = profile
        mutator(profile)
        temporary = MEMORY.with_suffix('.json.tmp')
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
        temporary.replace(MEMORY)

def _exp46f_parse_birthday(value):
    value = re.sub(r'(\d)(st|nd|rd|th)\b', r'\1', value.strip(), flags=re.I)
    value = re.sub(r'\s+', ' ', value).rstrip('.?!')
    for fmt in ('%m/%d/%Y','%B %d, %Y','%B %d %Y','%b %d, %Y','%b %d %Y','%Y-%m-%d'):
        try:
            born = datetime.strptime(value, fmt).date()
            if born <= date.today(): return born
        except ValueError:
            pass
    return None

def reply(user, text, private=True):
    visible = _exp46f_clean(text)
    low = visible.rstrip('.?!').strip().lower()
    if not private and not re.match(r'^\s*cyber\b', str(text), re.I):
        return ''

    # Fixed Cyber identity. Never infer Cyber's birthplace from a user's profile.
    if low in {'when were you born','when was cyber born','when were you created','when was cyber created',
               'what is your birthdate','what is your birthday'}:
        return 'I was born in January 2002.'

    # Location belongs to the sender UIN, never to Cyber.
    m = re.fullmatch(r'i\s+live\s+in\s+(.+?)[.!?]*', visible, re.I)
    if m:
        place = m.group(1).strip().strip('"').rstrip('.?!').strip()
        if re.fullmatch(r'Goi(?:a|á)s', place, re.I): place = 'Goiás, Brazil'
        if not place: return 'Please tell me the place where you live.'
        _exp46f_mutate_profile(user, lambda p: p.__setitem__('location', place[:240]))
        return 'I will remember that.'

    if low in {'where do i live','where am i from'}:
        place = _v39_profile(user).get('location')
        return ('You live in '+str(place)+'.') if place else "I don't remember where you live."

    # Accept both classic "birthdate" and natural "birthday" wording.
    m = re.fullmatch(r'my\s+(?:birthdate|birthday)\s+is\s+(.+)', visible, re.I)
    if m:
        born = _exp46f_parse_birthday(m.group(1))
        if born is None: return 'Please use a valid birthday, for example: April 3, 2011.'
        _exp46f_mutate_profile(user, lambda p: p.__setitem__('birthdate', born.isoformat()))
        return 'I will remember that.'

    # Forget only this sender's location. Other profile fields/UINs remain intact.
    forget_location_patterns = (
        r'(?:please\s+)?(?:stop\s+)?remembering\s+(?:my\s+)?location(?:\s+please)?',
        r'(?:please\s+)?forget\s+(?:my\s+)?location(?:\s+please)?',
        r'(?:please\s+)?remove\s+(?:my\s+)?location(?:\s+please)?',
        r'stop\s+remembering\s+.+?(?:\s+please)?(?:\s+remove\s+it)?',
    )
    if any(re.fullmatch(p, low, re.I) for p in forget_location_patterns):
        _exp46f_mutate_profile(user, lambda p: p.pop('location', None))
        return 'I will forget your location.'

    return _exp46f_previous_reply(user, text, private)

# Experimental 46g: explicit field deletion before all model/fallback routes.
_exp46g_previous_reply = reply
CYBER_BUILD = '6.2 - Profile and Runtime Marker Fix 1'

def reply(user, text, private=True):
    if not private and not re.match(r'^\s*cyber\b', str(text), re.I):
        return ''
    low = _exp46f_clean(text).rstrip('.?!').strip().lower()
    match = re.fullmatch(r'(?:please\s+)?(?:forget|delete|remove)\s+my\s+(name|birthday|birthdate|date of birth|location|email|email address|website|gender|likes)(?:\s+please)?', low)
    reset = low in {'forget me','delete my memory','forget everything about me','reset my data'}
    if match or reset:
        aliases = {'birthday':'birthdate','date of birth':'birthdate','email address':'email'}
        field = aliases.get(match[1], match[1]) if match else None
        try:
            if reset:
                with LOCK:
                    try: data=json.loads(MEMORY.read_text(encoding='utf-8'))
                    except FileNotFoundError: data={}
                    if not isinstance(data,dict): raise ValueError('Invalid memory')
                    data.pop(str(user),None)
                    temporary=MEMORY.with_suffix('.json.tmp')
                    temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
                    temporary.replace(MEMORY)
            else:
                # Refuse malformed memory rather than silently replacing it.
                with LOCK:
                    try: data=json.loads(MEMORY.read_text(encoding='utf-8'))
                    except FileNotFoundError: data={}
                    if not isinstance(data,dict): raise ValueError('Invalid memory')
                    profile=data.get(str(user),{})
                    if not isinstance(profile,dict): raise ValueError('Invalid profile')
                    keys={'birthdate':('birthdate','birthday','date_of_birth','age','zodiac'), 'name':('name',)}.get(field,(field,))
                    for key in keys: profile.pop(key,None)
                    temporary=MEMORY.with_suffix('.json.tmp')
                    temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
                    temporary.replace(MEMORY)
        except (OSError,ValueError,TypeError):
            return 'I could not update the memory file. Your data was not confirmed deleted.'
        import cyber_ai
        with cyber_ai.LOCK: cyber_ai.HISTORY.pop(str(user),None)
        if reset:return 'I have cleared your saved profile and temporary AI conversation history.'
        label='birthday' if field=='birthdate' else field
        return 'I no longer have your '+label+' saved. I also cleared your temporary AI conversation history.'
    return _exp46g_previous_reply(user,text,private)

_v39_fixed_previous=reply
CYBER_BUILD = '6.2 - Profile and Runtime Marker Fix 1'
def reply(user,text,private=True):
    if not private and not re.match(r'^\s*cyber\b',str(text),re.I):return ''
    clean=_exp46f_clean(text).rstrip('.?!').strip();low=clean.lower()
    identity={'who are you':'I am Cyber, your local CyberBuddy assistant.','what is your name':'My name is Cyber.','are you cyber':'Yes. I am Cyber.','are you a human':'No. I am a conversational bot.','please answer in english':'I will answer in English.','when were you born':'I was born in January 2002.'}
    if low in identity:return identity[low]
    import cyber_calculators
    result=cyber_calculators.calculate(clean)
    if result is not None:return result
    if re.fullmatch(r'(?:what (?:is|are) (?:the )?)?(?:(?:closest )?factor pairs?|factors|divisors) of [+-]?\d+',low) or re.fullmatch(r'is [+-]?\d+ (?:a )?prime(?: number)?',low):
        return _exact39_reply(user,'Cyber, '+clean,True)
    if low in ('what is my name',"what's my name",'do you remember my name'):
        name=_v39_profile(user).get('name');return 'Your name is '+str(name)+'.' if name else 'You have not told me your name.'
    if low=='what is today':return 'Today is '+date.today().strftime('%A, %B %d, %Y')+'.'
    if low=='what is my zodiac sign':
        value=_v39_profile(user).get('birthdate')
        if not value:return 'You have not told me your birthday.'
        try:born=date.fromisoformat(value)
        except (ValueError,TypeError):return 'Please tell me your birthday again.'
        sign='Capricorn'
        for month,day,label in [(1,20,'Aquarius'),(2,19,'Pisces'),(3,21,'Aries'),(4,20,'Taurus'),(5,21,'Gemini'),(6,21,'Cancer'),(7,23,'Leo'),(8,23,'Virgo'),(9,23,'Libra'),(10,23,'Scorpio'),(11,22,'Sagittarius'),(12,22,'Capricorn')]:
            if (born.month,born.day)>=(month,day):sign=label
        return 'Your traditional Western zodiac sign is '+sign+'.'

    if low=='when is my birthday':
        born=_v39_profile(user).get('birthdate');return 'Your birthday is '+str(born)+'.' if born else 'You have not told me your birthday.'
    if low.startswith(('my name is ','my website is ','my email is ')) or low in ('i am a boy','i am a girl','i am male','i am female'):
        return _basic_reply(user,clean,True)
    return _v39_fixed_previous(user,'Cyber, '+clean,True)

# Classic teaching/unlearning is local, prior to research and AI.
_classic_teaching_previous=reply
CYBER_BUILD = '6.2 - Profile and Runtime Marker Fix 1'
def reply(user,text,private=True):
    if not private and not re.match(r'^\s*cyber\b',str(text),re.I):return ''
    clean=_exp46f_clean(text).replace('“','"').replace('”','"').rstrip('.?!').strip()
    low=clean.lower()
    synonym=re.fullmatch(r'"(.+?)" is (not )?the same as "(.+?)"',clean,re.I)
    remove=re.fullmatch(r'"?(.+?)"? is not (?:a |an )?"?(.+?)"?',clean,re.I)
    teach=re.fullmatch(r'(.+?) is (.+)',clean,re.I)
    if teach and (low.startswith(('what ','who ','where ','when ','why ','how ','my ','your ','remember ','message ')) or synonym or remove):teach=None
    profile=_v39_profile(user)
    query=re.fullmatch(r'(?:what|who) is (.+)',low)
    meaning=re.fullmatch(r'what does (.+?) mean',low)
    facts=profile.get('facts',{});synonyms=profile.get('synonyms',{})
    forgotten=profile.get('forgotten_facts',[])
    if synonym or remove or teach:
        def norm(v):return re.sub(r'^(?:a|an)\s+','',v.strip().strip('"').lower())
        answer=[]
        def mutate(p):
            fs=p.setdefault('facts',{});ss=p.setdefault('synonyms',{});gone=p.setdefault('forgotten_facts',[])
            if synonym:
                key=synonym[1].strip().lower();value=synonym[3].strip()
                if synonym[2]:
                    if ss.get(key,'').lower()==value.lower():ss.pop(key);answer.append('I have removed that synonym association.')
                    else:answer.append('I do not have that matching synonym association saved.')
                elif ss.get(key,'').lower()==value.lower():answer.append('I already know that phrase.')
                else:ss[key]=value;answer.append('I have learned that phrase.')
            elif remove:
                key=remove[1].strip().strip('"').lower();value=remove[2]
                if key in fs and norm(fs[key])==norm(value):
                    fs.pop(key)
                    if key not in gone:gone.append(key)
                    answer.append('I have removed that association.')
                else:answer.append('I do not have that matching association saved.')
            else:
                key=teach[1].strip().lower();value=teach[2].strip()
                if fs.get(key,'').lower()==value.lower():answer.append('I already know that association.')
                else:fs[key]=value[:500];answer.append('I have learned that association from you.')
                if key in gone:gone.remove(key)
        try:_exp46f_mutate_profile(user,mutate)
        except (OSError,ValueError,TypeError):return 'I could not save that change.'
        import cyber_ai
        with cyber_ai.LOCK:cyber_ai.HISTORY.pop(str(user),None)
        return answer[0]
    if meaning:
        key=meaning[1].strip().strip('"')
        return 'You taught me that '+key+' means '+synonyms[key]+'.' if key in synonyms else 'You have not taught me a meaning for that phrase.'
    if query and query[1] in facts:return facts[query[1]]
    if query and query[1] in forgotten:return 'You removed the saved association for '+query[1]+'.'
    if low=='what do i like':return 'You like '+str(profile['likes'])+'.' if profile.get('likes') else 'You have not told me what you like.'
    if low=="what is my dog's name":
        match=re.fullmatch(r'a dog named (.+)',str(profile.get('possessions','')),re.I)
        return 'Your dog is named '+match[1]+'.' if match else 'You have not told me your dog\'s name.'
    if low.startswith(('i like ','i have ')):return _documented_reply(user,'Cyber, '+clean,True)
    return _classic_teaching_previous(user,text,private)

# Original Cyber/CyberBuddy identity must not search for CDC Cyber.
_classic_identity_previous=reply
def reply(user,text,private=True):
    if not private and not re.match(r'^\s*cyber\b',str(text),re.I):return ''
    clean=_exp46f_clean(text).rstrip('.?!').strip()
    clean=re.sub(r'^research\s+','',clean,flags=re.I).lower()
    if re.fullmatch(r'who (?:created|wrote|made|developed) (?:the )?(?:original )?cyber',clean) or clean in ('who created you','who wrote you','who is your creator'):
        return 'The original Cyber was written by John DeFino, the creator of CyberBuddy. This bot is an unofficial recreation.'
    if clean in ('what is cyberbuddy','what is cyber buddy','who created cyberbuddy','who wrote cyberbuddy'):
        return 'CyberBuddy is a Microsoft Agent desktop assistant written by John DeFino. It includes features such as spoken information and instant messaging. This proxy is an unofficial compatibility project.'
    return _classic_identity_previous(user,text,private)

# Explicit research is a lookup request, never a teaching statement.
_research_priority_previous=reply
def reply(user,text,private=True):
    if not private and not re.match(r'^\s*cyber\b',str(text),re.I):return ''
    clean=_exp46f_clean(text).rstrip('.?!').strip()
    if re.match(r'^research\s+',clean,re.I):
        # Original Cyber identity remains grounded in supplied documentation.
        identity=re.sub(r'^research\s+','',clean,flags=re.I).lower()
        if identity in ('who created the original cyber','what is cyberbuddy'):
            return _research_priority_previous(user,identity,True)
        import cyber_web
        return cyber_web.research(clean)
    return _research_priority_previous(user,text,private)

# Natural arithmetic before encyclopedia search; sourced follow-up context by UIN.
_natural_math_previous=reply
_RESEARCH_CONTEXT={}
def reply(user,text,private=True):
    if not private and not re.match(r'^\s*cyber\b',str(text),re.I):return ''
    clean=_exp46f_clean(text).rstrip('.?!').strip();low=clean.lower();key=str(user)
    expression=re.sub(r'^(?:what is|calculate)\s+','',low)
    expression=re.sub(r'\bdivided by\b','/',expression)
    for word,symbol in [('times','*'),('plus','+'),('minus','-'),('x','*')]:expression=re.sub(r'\b'+word+r'\b',symbol,expression)
    if re.fullmatch(r'[\d\s.+*/()\-]+',expression) and re.search(r'\d',expression):
        import cyber_calculators
        try:
            value=cyber_calculators.rational(expression.strip())
            return cyber_calculators.fmt(value)+'.'
        except (ValueError,SyntaxError,ZeroDivisionError,OverflowError):return 'I could not calculate that expression. Check the numbers and operators.'
    followup=re.sub(r'[,;:]?\s+cyber$','',low).strip().rstrip(',;:').strip()
    if followup in ('tell me more','what else'):
        previous=_RESEARCH_CONTEXT.get(key)
        if not previous:return 'What would you like to know more about? Ask a research question first.'
        # Repeat a verified source excerpt rather than pretend to retrieve new facts.
        return 'The last sourced result was: '+previous+' Ask a more specific question for another lookup.'
    if low in ('forget me','delete my memory','reset my data','forget everything about me'):_RESEARCH_CONTEXT.pop(key,None)
    result=_natural_math_previous(user,text,private)
    if isinstance(result,str) and 'Source: https://' in result:
        if len(_RESEARCH_CONTEXT)>=100 and key not in _RESEARCH_CONTEXT:_RESEARCH_CONTEXT.pop(next(iter(_RESEARCH_CONTEXT)))
        _RESEARCH_CONTEXT[key]=result
    return result

# Final event priority: do not let generic encyclopedia rules rewrite this query.
_gaza_priority_previous=reply
def reply(user,text,private=True):
    if not private and not re.match(r'^\s*cyber\b',str(text),re.I):return ''
    clean=_exp46f_clean(text).rstrip('.?!').strip()
    if re.fullmatch(r'(?:research\s+)?when did (?:the )?gaza war that began in 2023 (?:start|begin)',clean,re.I):
        import cyber_web
        return cyber_web.wikipedia_answer(re.sub(r'^research\s+','',clean,flags=re.I))
    return _gaza_priority_previous(user,text,private)

# Final capabilities/research guard for all callers.
_capabilities_previous=reply
def reply(user,text,private=True):
    if not private and not re.match(r'^\s*cyber\b',str(text),re.I):return ''
    clean=_exp46f_clean(text).rstrip('.?!').strip()
    if clean.lower() in ('what can you do','what are your capabilities','what are your features'):
        return 'I can chat with you, remember details you teach me, calculate math, convert units, tell world times, and look up information on Wikipedia. Some features are still experimental.'
    if re.match(r'^research\b',clean,re.I):
        import cyber_web
        topic=re.sub(r'^research\s*','',clean,flags=re.I)
        if not topic:return 'Tell me what to research.'
        if topic.lower() in ('who created the original cyber','what is cyberbuddy'):
            return _capabilities_previous(user,topic,True)
        result=cyber_web.wikipedia_answer(topic)
        if 'Source: https://' in result:_RESEARCH_CONTEXT[str(user)]=result
        return result
    return _capabilities_previous(user,text,private)



# Version 6.2: profile location has priority over every generic AI/web wrapper.
_location62_previous = reply
def reply(user, text, private=True):
    if not private and not re.match(r'^\s*cyber\b', str(text), re.I):
        return ''
    visible = _exp46f_clean(text)
    match = re.fullmatch(r"i\s+live\s+in(?:\s+(.*))?[.!?]*", visible, re.I)
    if match:
        place = (match.group(1) or '').strip().strip('"').rstrip('.?!').strip()
        if not place or place.lower() in ('<name>', '<place>'):
            return 'Please tell me where you live, for example: Cyber, I live in Brazil.'
        if len(place) > 240:
            return 'Please give a place name of at most 240 characters.'
        if re.fullmatch(r'Goi(?:a|á)s', place, re.I):
            place = 'Goiás, Brazil'
        _exp46f_mutate_profile(user, lambda profile: profile.__setitem__('location', place))
        return 'I will remember that you live in '+place+'.'
    if visible.lower().rstrip('.?!').strip() in ('where do i live', 'where am i from', 'what is my location'):
        place = _v39_profile(user).get('location')
        return ('You live in '+str(place)+'.') if place else 'You have not told me where you live.'
    return _location62_previous(user, text, private)



# Version 6.2: personal birthday/clock statements never reach teaching or AI.
_profile62_previous = reply
def reply(user, text, private=True):
    if not private and not re.match(r'^\s*cyber\b', str(text), re.I):
        return ''
    visible = _exp46f_clean(text).rstrip('.?!').strip()
    born_match = re.fullmatch(r"(?:i was born on|my (?:birthdate|birthday|date of birth) is)(?:\s+(.*))?", visible, re.I)
    if born_match:
        born = _exp46f_parse_birthday(born_match.group(1) or '')
        if born is None:
            return 'Please use a valid birthdate, for example: April 3, 2011 or 04/03/2011 (MM/DD/YYYY).'
        _exp46f_mutate_profile(user, lambda profile: profile.__setitem__('birthdate', born.isoformat()))
        return 'I will remember your birthday: '+born.strftime('%B %d, %Y')+'.'
    clock_match = re.fullmatch(r"the time here is(?:\s+(.*))?", visible, re.I)
    if clock_match:
        clock_text = (clock_match.group(1) or '').strip().upper()
        clock = None
        for fmt in ('%I:%M %p','%I:%M%p','%H:%M'):
            try:
                clock = datetime.strptime(clock_text, fmt)
                break
            except ValueError:
                pass
        if clock is None:
            return 'Please use a valid time, for example: the time here is 11:52 AM or 23:52.'
        now = datetime.now()
        difference = (clock.hour*60 + clock.minute - now.hour*60 - now.minute + 720) % 1440 - 720
        _exp46f_mutate_profile(user, lambda profile: profile.__setitem__('clock_offset_minutes', difference))
        return 'I have remembered your current clock difference. This does not identify your time zone; daylight-saving changes may need an update.'
    return _profile62_previous(user, text, private)


# Runtime Fix 2: deterministic local profile/help/version entry point.
_runtime2_previous = reply
CYBER_BUILD = '6.2 - Local Profile Priority Fix 2'

def _runtime2_clean(text):
    import unicodedata
    value = unicodedata.normalize('NFC', str(text))
    value = ''.join(c for c in value if unicodedata.category(c) != 'Cf')
    value = re.sub(r'\\[A-Za-z]+(?:=[^\\]*)?\\', ' ', value)
    # Known classic animation prefix observed in the native-client diagnostic.
    value = re.sub(r'^\s*(?:(?:and\s+|&&)?decline)\s+(?=cyber\b)', '', value, flags=re.I)
    return _exp46f_clean(value).strip().strip('"“”').rstrip('.?!').strip()

def _runtime2_location(user, place=None):
    import tempfile, os
    with LOCK:
        try:
            data = json.loads(MEMORY.read_text(encoding='utf-8'))
        except FileNotFoundError:
            data = {}
        if not isinstance(data, dict):
            raise ValueError('Invalid memory container')
        key = str(user)
        profile = data.get(key, {})
        if not isinstance(profile, dict):
            raise ValueError('Invalid user profile')
        if place is None:
            return profile.get('location')
        profile['location'] = place
        data[key] = profile
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=MEMORY.parent,
                                         prefix=MEMORY.name+'.', suffix='.tmp', delete=False) as handle:
            temporary = Path(handle.name)
            try:
                json.dump(data, handle, ensure_ascii=False, indent=2)
            except BaseException:
                handle.close(); temporary.unlink(missing_ok=True); raise
        try:
            os.replace(temporary, MEMORY)
        finally:
            temporary.unlink(missing_ok=True)
        return place

def reply(user, text, private=True):
    clean = _runtime2_clean(text)
    if not private and not re.match(r'^\s*cyber\b', str(text), re.I):
        return ''
    low = clean.lower()
    if low in ('what version are you running', 'what is your version', 'version', 'build'):
        return 'CyberBuddy Classic Proxy '+CYBER_BUILD+'.'
    if low in ('how do i teach you something', 'how can i teach you', 'how do i teach you',
               'how do you learn', 'how can you learn'):
        return ('Teach me with: Cyber, remember my favorite color is blue. '
                'Then ask: Cyber, what is my favorite color? '
                'For location, say: Cyber, I live in Goiás. '
                'Then ask: Cyber, where do I live?')
    match = re.fullmatch(r"i\s+live(?:\s+in\b)?(?:\s+(.+))?", clean, re.I)
    if match:
        place = (match[1] or '').strip().strip('"“”').rstrip('.?!').strip()
        if not place or len(place) > 240:
            return 'Please give a location of 1 to 240 characters.'
        if re.fullmatch('Goi(?:a|á)s', place, re.I):
            place = 'Goiás, Brazil'
        try:
            _runtime2_location(user, place)
        except (OSError, ValueError, TypeError):
            return 'I could not save your location. Your existing memory was not reset.'
        return 'I will remember that you live in '+place+'.'
    if low in ('where do i live', 'where am i from', 'what is my location'):
        try:
            place = _runtime2_location(user)
        except (OSError, ValueError, TypeError):
            return 'I could not read your saved location. Your existing memory was not reset.'
        return 'You live in '+str(place)+'.' if place else 'You have not told me where you live.'
    import cyber_web
    population = cyber_web.population_answer(clean)
    if population is not None:
        return population
    import cyber_clock
    clock_answer = cyber_clock.clock_reply(clean)
    if clock_answer is not None:
        return clock_answer
    return _runtime2_previous(user, clean, private=True)


# Diagnostic 3: retain only the most recent route per UIN in process memory.
_route3_previous = reply
_ROUTE3_LAST = {}
CYBER_BUILD = '6.2 - Population Research Fix 7'

def reply(user, text, private=True):
    import os, hashlib
    clean = _runtime2_clean(text)
    if not private and not re.match(r'^\s*cyber\b', str(text), re.I):
        return ''
    if clean.lower() == 'diagnose last route':
        previous = _ROUTE3_LAST.get(str(user))
        if previous is None:
            detail = 'No previous message recorded for this UIN in this process.'
        else:
            detail = ('Last cleaned input='+ascii(previous['clean'])+
                      '; location_match='+str(previous['location'])+
                      '; result='+previous['result'])
        return ('DIAG3 PID='+str(os.getpid())+'; UIN-key='+
                hashlib.sha256(str(user).encode()).hexdigest()[:8]+
                '; '+detail+'; module='+str(Path(__file__).resolve())+
                '; memory='+str(MEMORY.resolve()))
    matched = bool(re.fullmatch(r'i\s+live(?:\s+in\b)?(?:\s+(.+))?', clean, re.I))
    if len(_ROUTE3_LAST) >= 100 and str(user) not in _ROUTE3_LAST:
        _ROUTE3_LAST.pop(next(iter(_ROUTE3_LAST)))
    record = {'clean': clean[:240], 'location': matched, 'result': 'pending'}
    _ROUTE3_LAST[str(user)] = record
    answer = _route3_previous(user, text, private)
    record['result'] = ('saved' if str(answer).startswith('I will remember that you live in ')
                        else 'save-failed' if str(answer).startswith('I could not save your location')
                        else 'other')
    # A visible process tag distinguishes simultaneous/stale responders.
    if matched:
        return '[DIAG3 PID '+str(os.getpid())+'] '+str(answer)
    return answer


# Classic Update 8: all transports use one behavior and persistence boundary.
_classic8_previous=reply
CYBER_BUILD='6.2 - Classic Native LAN Patch 12'
def reply(user,text,private=True):
    import cyber_classic, sys
    return cyber_classic.respond(sys.modules[__name__],user,text,private,_classic8_previous)


if __name__ == '__main__':
    print('BUILD:', CYBER_BUILD)
    print('Bot module:', Path(__file__).resolve())
    print('Memory file:', MEMORY.resolve())
    print('Cyber local test - type quit to exit. Memory stays on this computer.')
    while True:
        try: text=input('You: ')
        except (EOFError,KeyboardInterrupt):break
        if text.lower()=='quit':break
        print('Cyber:',reply('local',text))
