"""Local native protocol diagnostic. No fabricated acknowledgements or replies."""
import socket, selectors, re
from pathlib import Path

def describe(data):
    markers = re.findall(rb'(?:\$\$|&&)[A-Za-z]{2,20}', data)
    allowed = {b'$$UIN',b'$$SNDTO',b'$$MYIP',b'$$AWAY',b'&&EOT'}
    return 'bytes=%d known_markers=%s newline=%s' % (len(data), ','.join(sorted({m.decode('ascii') for m in markers if m in allowed})) or 'none', bool(b'\n' in data))

def main():
    poll = selectors.DefaultSelector()
    streams=[]
    log=Path(__file__).with_name('CYBER_NATIVE_TEST.log')
    for port in (80,4010):
        sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        try:
            sock.bind(('127.0.0.2',port));sock.setblocking(False)
            poll.register(sock,selectors.EVENT_READ,port);streams.append(sock)
        except OSError:
            sock.close();print('Could not listen on UDP port',port)
    if not streams: return
    print('Local protocol test on 127.0.0.2. In CyberBuddy Chat, enter 127.0.0.2 as recipient.')
    print('Click Ping, then send the test message. This diagnoses transport; it does not reply yet.')
    print('Only packet sizes and known marker names are saved. Press Ctrl+C to stop.')
    try:
        while True:
            for key,_ in poll.select(timeout=1):
                data,_peer=key.fileobj.recvfrom(65535)
                line='UDP port=%d %s' % (key.data,describe(data))
                print(line)
                with log.open('a',encoding='utf-8') as f:f.write(line+'\n')
    except KeyboardInterrupt: pass
    finally:
        for sock in streams:sock.close()
        poll.close()
if __name__=='__main__': main()
