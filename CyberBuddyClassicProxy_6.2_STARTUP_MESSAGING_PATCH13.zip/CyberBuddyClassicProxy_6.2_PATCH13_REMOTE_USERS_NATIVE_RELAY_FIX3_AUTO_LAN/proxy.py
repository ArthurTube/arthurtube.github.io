#!/usr/bin/env python3
"""CyberBuddy Classic Proxy - HTTP bridge for legacy Windows software."""

from __future__ import annotations
SHARED_SERVER_HOST = "0.0.0.0"
SHARED_SERVER_PORT = 8081

import os

import configparser
import csv
import math
import datetime
import base64
import email.header
import email.parser
import email.policy
import gzip
import hashlib
import http.client
import html
from html.parser import HTMLParser
import io
import ipaddress
import json
import logging
import re
import random
import select
import socket
import socketserver
import smtplib
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import unicodedata
import xml.etree.ElementTree as ET
import zlib
from pathlib import Path


APP_NAME = "CyberBuddy Classic Proxy"
APP_VERSION = "6.2"
ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "proxy.ini"
LOG_PATH = ROOT / "proxy.log"
WEATHER_ASSETS = ROOT / "weather_assets"
WEATHER_SITE = ROOT / "weather_site"
MODEL_IMAGES = {}
MODEL_IMAGES_LOCK = threading.Lock()
WEATHER_CACHE = {}
GEOCODE_CACHE = {}
INMET_ALERT_CACHE = {}
WEATHER_LOCK = threading.RLock()
WEATHER_COOLDOWN_UNTIL = 0.0

# Experimental local replacement for CyberBuddy's retired UIN/chat service.
# Nothing is forwarded to the historical public endpoints.
CHAT_LOCK = threading.RLock()
CHAT_USERS = {}       # uin -> {name, comments, last_seen}
CHAT_QUEUES = {}      # uin -> [{from_uin, from_name, text, when}]
CHAT_LAST_TARGET = {}
UIN_DIRECTORY_MAX = 200
REMOTE_REQUEST_LOCK = threading.RLock()

# UIN allocation is separate from public directory publication and chat presence.
UIN_REGISTRATION_LOCK = threading.RLock()
UIN_REGISTRATION_FILE = ROOT / 'uin_registrations.json'

def _register_legacy_uin(query):
    parts = [urllib.parse.unquote_plus(p, encoding='cp1252')
             for p in query.split('&&')]
    if len(parts) != 5 or parts[0].upper() != 'U0':
        raise ValueError('Unsupported UIN registration request')
    name, version, windows_name, address = parts[1:]
    if not name.strip() or not windows_name.strip():
        raise ValueError('Missing registration identity')
    # Version changes do not assign a new identity. This is a legacy lookup key,
    # not authentication; identical names/account/address cannot be distinguished.
    key = hashlib.sha256(json.dumps([name, windows_name, address],
                         ensure_ascii=False).encode('utf-8')).hexdigest()
    with UIN_REGISTRATION_LOCK:
        saved = {}
        if UIN_REGISTRATION_FILE.exists():
            saved = json.loads(UIN_REGISTRATION_FILE.read_text(encoding='utf-8'))
        if not isinstance(saved, dict):
            raise ValueError('Invalid UIN registry')
        numbers = list(saved.values())
        if any(not isinstance(n, str) or not n.isdigit() or
               not 10000 <= int(n) <= 2147483647 for n in numbers):
            raise ValueError('Invalid UIN registry values')
        if len(set(numbers)) != len(numbers):
            raise ValueError('Duplicate UIN registry values')
        if key in saved:
            return ('UIN' + saved[key]).encode('ascii')
        # Also avoid existing real/historical directory UINs. Allocation is
        # serialized through saving so concurrent registrations cannot collide.
        with CHAT_LOCK:
            used = set(numbers) | set(CHAT_USERS)
        number = max([10000] + [int(n) + 1 for n in used
                                if n.isdigit() and int(n) >= 10000])
        if number > 2147483647:
            raise ValueError('UIN space exhausted')
        saved[key] = str(number)
        tmp = UIN_REGISTRATION_FILE.with_suffix('.json.tmp')
        tmp.write_text(json.dumps(saved, indent=2) + '\n', encoding='utf-8')
        os.replace(tmp, UIN_REGISTRATION_FILE)
        return ('UIN' + str(number)).encode('ascii')


def _publish_remote_uin(uin, name='', comments=''):
    uin = _chat_safe_uin(uin)
    if not uin:
        return False
    now = int(time.time())
    with CHAT_LOCK:
        old = CHAT_USERS.get(uin, {})
        CHAT_USERS[uin] = {
            'name': (name or old.get('name','') or ('UIN ' + uin))[:80],
            'comments': (comments or old.get('comments',''))[:240],
            'last_seen': now,
            'published': True,
            'archived': bool(old.get('archived', False)),
        }
        CHAT_QUEUES.setdefault(uin, [])
    _chat_directory_save_state()
    return True

  # last successful G recipient lookup

def _chat_fields(pairs):
    return {str(k).strip().lower(): str(v) for k, v in pairs}

def _chat_pick(fields, *names):
    for name in names:
        v = fields.get(name.lower(), '').strip()
        if v:
            return v
    return ''

def _chat_safe_uin(value):
    value = re.sub(r'[^0-9A-Za-z_.-]', '', value or '')[:64]
    return value



CHAT_DIRECTORY_STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'chat_directory_2026.json')

def _chat_directory_load_state():
    try:
        with open(CHAT_DIRECTORY_STATE_FILE, 'r', encoding='utf-8') as f:
            saved = json.load(f)
        if not isinstance(saved, dict):
            return
        with CHAT_LOCK:
            for uin, info in saved.items():
                if not isinstance(info, dict):
                    continue
                cur = CHAT_USERS.get(str(uin), {})
                cur.update({
                    'name': str(info.get('name','')),
                    'comments': str(info.get('comments','')),
                    'last_seen': int(info.get('last_seen',0) or 0),
                    'ip': str(info.get('ip', '')),
                    'published': bool(info.get('published',False)),
                    'archived': bool(info.get('archived',False)),
                })
                CHAT_USERS[str(uin)] = cur
    except Exception:
        pass

def _chat_directory_save_state():
    try:
        with CHAT_LOCK:
            saved = {}
            for uin, info in CHAT_USERS.items():
                if info.get('published'):
                    saved[str(uin)] = {
                        'name': info.get('name',''),
                        'comments': info.get('comments',''),
                        'last_seen': int(info.get('last_seen',0) or 0),
                        'ip': info.get('ip', ''),
                        'published': True,
                        'archived': bool(info.get('archived',False)),
                    }
            tmp = CHAT_DIRECTORY_STATE_FILE + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(saved, f, ensure_ascii=False, indent=2)
            os.replace(tmp, CHAT_DIRECTORY_STATE_FILE)
    except Exception:
        pass


# Live/published UIN state is intentionally persistent across proxy restarts.
# The archived historical directory remains separate from this state.

def _invitebuddy_html(message=""):
    try:
        raw=open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "page18_original.html"), "rb").read()
        raw=raw.replace(b"http://thecyberbuddy.com/cgi-bin/invitebuddy.exe", b"/cgi-bin/invitebuddy.exe")
        if not message: return raw
    except Exception: raw=b""
    import html as _html
    msg=_html.escape(message).encode("windows-1252","replace")
    if raw and b"</form>" in raw: return raw.replace(b"</form>", b"<p><b>"+msg+b"</b></p></form>", 1)
    return b"<html><body><h2>Invite a Buddy</h2><p><b>"+msg+b"</b></p></body></html>"

def _invitebuddy_result_page(filename, fallback_message):
    """Serve the preserved original invitebuddy result page when available."""
    try:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
        with open(path, 'rb') as f:
            raw = f.read()
        # Keep the historical page appearance, but make its Back link stay on
        # the restored local Page 18 instead of leaving for the dead website.
        raw = raw.replace(b'http://thecyberbuddy.com/', b'/page18.html')
        return raw
    except Exception as error:
        log.warning('INVITE BUDDY: could not load %s: %s', filename, error)
        return _invitebuddy_html(fallback_message)

def _invitebuddy_response(fields):
    fromname = str(fields.get('fromname') or fields.get('yourname') or '').strip()
    fromemail = str(fields.get('fromemail') or fields.get('youremail') or '').strip()
    toname = str(fields.get('toname') or fields.get('buddyname') or '').strip()
    sendto = str(fields.get('sendto') or fields.get('buddyemail') or '').strip()
    uin = _chat_safe_uin(str(fields.get('uin','')))
    comments = str(fields.get('comments','')).strip()
    log.warning('INVITE BUDDY: form received required_fields=%s uin=%s message_bytes=%d',
                'yes' if bool(fromname and fromemail and toname and sendto) else 'no',
                'yes' if bool(uin) else 'no', len(comments.encode('utf-8','replace')))

    if not fromname or not fromemail or not toname or not sendto:
        log.warning('INVITE BUDDY: validation failed missing_required_fields=yes')
        return _invitebuddy_result_page("error.html", "Required Information is missing.")
    log.warning('INVITE BUDDY: validation passed')

    # Basic header-injection protection for this old web form.
    if any(('\r' in v or '\n' in v) for v in (fromname, fromemail, toname, sendto)):
        return _invitebuddy_result_page("error.html", "Required Information is missing.")

    # Reuse the temporary Gmail/App-Password credentials already captured by
    # CyberBuddy's restored POP3/SMTP bridge. They remain process-memory only.
    try:
        with MAIL_CREDENTIALS_LOCK:
            username = MAIL_CREDENTIALS.get('username')
            password = MAIL_CREDENTIALS.get('password')
    except Exception as error:
        log.exception('INVITE BUDDY: credential bridge error: %s', error)
        return _invitebuddy_html('Your invitation form is complete, but the e-mail credential bridge failed. Check proxy.log.')
    if not username or not password:
        username, password = _load_mail_credentials()
        if username and password:
            with MAIL_CREDENTIALS_LOCK:
                MAIL_CREDENTIALS["username"] = username
                MAIL_CREDENTIALS["password"] = password
            log.warning("INVITE BUDDY: restored cached mail credentials")

    log.warning('INVITE BUDDY: mail credentials available=%s', 'yes' if bool(username and password) else 'no')

    if not username or not password:
        log.error('INVITE BUDDY: SMTP credentials unavailable; form itself was valid')
        return _invitebuddy_html(
            'Your invitation form is complete, but no outgoing e-mail account has been configured yet. '
            'Configure CyberBuddy e-mail once; Invite Your Buddy will remember it afterward.'
        )

    subject = 'CyberBuddy invitation from %s' % fromname
    body = (
        'Hello %s,\r\n\r\n'
        '%s\r\n\r\n'
        'From: %s <%s>\r\n'
        '%s'
    ) % (
        toname,
        comments or 'I found this great program called CyberBuddy.',
        fromname,
        fromemail,
        ('CyberBuddy UIN: %s\r\n' % uin) if uin else ''
    )

    # Send through the same authenticated SMTP service configured for the
    # restored CyberBuddy mail bridge. The authenticated account is the SMTP
    # envelope sender; the historical form address is kept as Reply-To.
    msg = (
        'From: "%s" <%s>\r\n'
        'Reply-To: %s\r\n'
        'To: "%s" <%s>\r\n'
        'Subject: %s\r\n'
        'MIME-Version: 1.0\r\n'
        'Content-Type: text/plain; charset=utf-8\r\n'
        'Content-Transfer-Encoding: 8bit\r\n'
        '\r\n%s'
    ) % (fromname.replace('"',''), username, fromemail, toname.replace('"',''),
         sendto, subject, body)

    try:
        log.warning('INVITE BUDDY: SMTP connecting host=%s port=%s', SMTP_REMOTE_HOST, SMTP_REMOTE_PORT)
        with smtplib.SMTP_SSL(
            SMTP_REMOTE_HOST, SMTP_REMOTE_PORT, timeout=TIMEOUT, context=tls_context()
        ) as smtp:
            log.warning('INVITE BUDDY: SMTP connected; authenticating')
            smtp.login(username, password)
            log.warning('INVITE BUDDY: SMTP authenticated; sending invitation')
            refused = smtp.sendmail(username, [sendto], msg.encode('utf-8'))
            if refused:
                raise RuntimeError('SMTP recipient refused')
            log.warning('INVITE BUDDY: SMTP accepted invitation for delivery')

        try:
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'invitebuddy_2026.log')
            with open(path, 'a', encoding='utf-8') as f:
                f.write('%s | DELIVERED | from=%s <%s> | to=%s <%s> | uin=%s\n' %
                        (time.strftime('%Y-%m-%d %H:%M:%S'), fromname, fromemail,
                         toname, sendto, uin))
        except Exception:
            pass

        log.info('INVITE BUDDY: email delivered through configured SMTP bridge to %s', sendto)
        return _invitebuddy_result_page("complete.html", "Your Invitation Has Been Sent!")

    except smtplib.SMTPAuthenticationError:
        log.error('INVITE BUDDY: SMTP authentication failed')
        return _invitebuddy_html(
            'Your invitation form is complete, but SMTP authentication failed. '
            'Check the e-mail/app password and try again.'
        )
    except Exception as error:
        log.error('INVITE BUDDY: SMTP delivery failed: %s', error)
        return _invitebuddy_html(
            'Your invitation form is complete, but e-mail delivery failed. '
            'Check proxy.log for the SMTP error and try again.'
        )



def _invitebuddy_safe_response(fields):
    try:
        return _invitebuddy_response(fields)
    except Exception as error:
        log.exception('INVITE BUDDY: unhandled server error: %s', error)
        return _invitebuddy_html(
            'Your invitation form was received, but the restored Invite a Buddy server encountered an error. Check proxy.log.'
        )

def _chat_directory_html():
    # In-memory state is authoritative until restart; reloading here would
    # overwrite fresh heartbeat times with older persisted timestamps.
    import html as _html
    now = int(time.time())
    live = []
    with CHAT_LOCK:
        for uin, info in CHAT_USERS.items():
            if not info.get('published'):
                continue
            last = int(info.get('last_seen',0) or 0)
            live.append((info.get('name','') or ('UIN '+uin), str(uin),
                         info.get('comments',''), max(0, now-last) if last else 0))
    live.sort(key=lambda r:r[3])

    def age(sec):
        if sec < 60: return '%d Secs' % sec
        if sec < 3600: return '%d Mins' % (sec//60)
        if sec < 86400:
            return '%d Hrs %d Mins' % (sec//3600, (sec%3600)//60)
        return '%d Days %d Hrs %d Mins' % (sec//86400, (sec%86400)//3600, (sec%3600)//60)

    rows=[]
    for n,u,c,a in live[:200]:
        rows.append('<tr><td>%s</td><td><a href="/cgi-bin/uinlister.exe?u%s">%s</a></td><td>%s</td><td>%s</td></tr>' %
                    (_html.escape(n),_html.escape(u),_html.escape(u),_html.escape(c),_html.escape(age(a))))
    if not rows:
        rows.append('<tr><td colspan="4"><i>No CyberBuddies have published their UIN on this server yet.</i></td></tr>')

    page = ('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN"><html><head>'
            '<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">'
            '<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">'
            '<meta http-equiv="Pragma" content="no-cache"><meta http-equiv="Expires" content="0">'
            '<meta http-equiv="refresh" content="15">'
            '<title>CyberBuddy UIN Directory</title></head>'
            '<body bgcolor="#FFE8C4" link="#0000FF" vlink="#FF00FF" text="#4040FF">'
            '<center><font size="+3"><b>CyberBuddy UIN Directory</b></font></center><p>'
            'This is a list of the last 200 CyberBuddies that have gone online and have selected to publish their UIN.<br><small>Maximum: 200 entries. This directory contains CyberBuddies that have published their UIN to this server.</small> '
            'It is computer generated and updated constantly. To contact someone, put their UIN in the designated box on the "Send" section of CyberBuddy. '
            'If you have CyberBuddy version 2.09.06 or greater, just click on the UIN of the person in the list. '
            'To put an icon in your listing see the "Advanced" Section.<p>'
            '<table border="1" cellpadding="3" cellspacing="0"><tr><td><b>Name</b></td><td><b>UIN</b></td>'
            '<td><b>Comments</b></td><td><b>Since Last On</b></td></tr>' + ''.join(rows) + '</table><p>'
            'CyberBuddy UIN List Generator by John DeFino</body></html>')
    return page.encode('windows-1252','replace')

def _chat_uin_contact_html(selected_uin):
    """Render the original-style UIN-to-contact-list page for ?u<UIN>."""
    import html as _html
    selected_uin = _chat_safe_uin(str(selected_uin or ''))
    if not selected_uin:
        return b''
    now = int(time.time())
    name = ''
    comments = ''
    last_on = 'Unknown'
    with CHAT_LOCK:
        info = CHAT_USERS.get(selected_uin, {})
        if info:
            name = info.get('name','') or ('UIN ' + selected_uin)
            comments = info.get('comments','') or ''
            last = int(info.get('last_seen',0) or 0)
            if last:
                sec = max(0, now-last)
                if sec < 60: last_on = '%d Secs' % sec
                elif sec < 3600: last_on = '%d Mins' % (sec//60)
                elif sec < 86400: last_on = '%d Hrs %d Mins' % (sec//3600, (sec%3600)//60)
                else: last_on = '%d Days %d Hrs %d Mins' % (sec//86400, (sec%86400)//3600, (sec%3600)//60)
    if not name:
        name = 'UIN ' + selected_uin

    page = ('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN"><html><head>'
            '<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">'
            '<meta name="Generator" content="CyberBuddy UIN Lister by John DeFino"></head>'
            '<body bgcolor="#FFE8C4" link="0000FF" vlink="#FF00FF" text="#4040FF">'
            '<center><table border="1" bgcolor="0000FF"><tr><td><font size="+2" face="Comic Sans MS" color="#FFFF00"> CyberBuddy UIN to Contact List </font></td></tr></table></center><p><br>'
            '<font size="3">If you have CyberBuddy Rev 2.09.06 or above, and Internet Explorer, click the button below to put this person on your contact list. '
            'The contact list is on the "Send" tab of CyberBuddy.<br><br><br></font>'
            '<center><font size="3"><table border="1" cellpadding="3">'
            '<tr><td><b>UIN:</b> %s</td></tr><tr><td><b> Name:</b> %s</td></tr>'
            '<tr><td><b>Comments:</b> %s</td></tr><tr><td><b>Last On:</b> %s </td></tr></table>'
            '<br><br><br><form action="/cgi-bin/UIN/%s.cbb" method="get">'
            '<input value="Send to Contact List" type="submit"></form><br><br><br><br>'
            '<form action="/cgi-bin/uinlister.exe" method="get"><input name="a" type="hidden">'
            '<input value="Back to List" type="submit"></form><br><br><br><br></font></center>'
            '<font size="3"><br><br><br><p></p><center><font size="-2">CyberBuddy UIN List Generator by John DeFino</font></center></font></body></html>') % (
                _html.escape(selected_uin), _html.escape(name), _html.escape(comments),
                _html.escape(last_on), _html.escape(selected_uin))
    return page.encode('windows-1252','replace')


def _chat_uin_cbb(selected_uin):
    """Original .cbb contact payload, verified from archived UIN 1111.cbb."""
    selected_uin = _chat_safe_uin(str(selected_uin or ''))
    return (('$$UIN%s\r\n' % selected_uin).encode('ascii')) if selected_uin else b''


def _chat_directory_refresh_login(fields):
    """Refresh presence for the same UIN already published in UINlister."""
    if str(fields.get('action','')).upper() != 'L':
        return
    uin = _chat_safe_uin(str(fields.get('uin','')))
    if not uin:
        return
    changed = False
    with CHAT_LOCK:
        info = CHAT_USERS.get(uin)
        if info and info.get('published'):
            info['last_seen'] = int(time.time())
            if fields.get('name'):
                info['name'] = str(fields.get('name'))
            CHAT_USERS[uin] = info
            changed = True
    if changed:
        _chat_directory_save_state()

def _native_contact_status(body):
    """CyberBud.exe 0x52a234 posts namelst.txt with User-Agent clst&&... .

    0x4d7388 joins file lines with CR; 0x52a040 consumes UIN/IP/seen rows.
    This lookup does not log in users or consume message queues.
    """
    requested = list(dict.fromkeys(line.strip() for line in
                     body.replace('\r', '\n').split('\n')
                     if line.strip().isdigit()))[:200]
    now = int(time.time())
    rows = []
    with CHAT_LOCK:
        for number in requested:
            if number=='1111':
                import cyber_lan
                endpoint=cyber_lan.advertised_ip()
                user={'ip':endpoint,'last_seen':now if endpoint else 0}
            else:
                user = CHAT_USERS.get(number, {})
            seen = int(user.get('last_seen', 0))
            address = user.get('ip', '')
            if not address or not seen or now - seen > 300:
                continue
            stamp = datetime.datetime.fromtimestamp(seen).strftime('%m-%d %H:%M')
            rows.append('%s&&%s&&%s' % (number, address, stamp))
    log.warning('LEGACY CHAT CONTACT STATUS requested=%d active=%d; values hidden',
                len(requested), len(rows))
    return ('\r\n'.join(rows) + ('\r\n' if rows else '')).encode('cp1252')


import cyber_bot

def _chat_legacy_response(fields, endpoint):
    """Best-effort local implementation of the retired CyberBuddy UIN service."""
    # CyberBud.exe 0x52a4e4 emits ?L for login, ?l for logout.
    if endpoint.lower() == 'cbonline2.exe' and fields.get('_native_logout'):
        number = _chat_safe_uin(_chat_pick(fields, 'uin'))
        with CHAT_LOCK:
            if number in CHAT_USERS:
                CHAT_USERS[number]['last_seen'] = 0
                _chat_directory_save_state()
        log.warning('LEGACY CHAT LOGOUT known=%s; identity retained, presence cleared',
                    'yes' if number in CHAT_USERS else 'no')
        return b''
    _chat_directory_refresh_login(fields)
    now = int(time.time())
    uin = _chat_safe_uin(_chat_pick(fields, 'uin','myuin','fromuin','senderuin','userid','user'))
    dest = _chat_safe_uin(_chat_pick(fields, 'sndto','sendto','touin','destuin','targetuin','recipientuin','to'))
    name = _chat_pick(fields, 'name','nickname','nick','myname','fromname','sender')[:80]
    comments = _chat_pick(fields, 'comments','comment')[:240]
    message = _chat_pick(fields, 'message','msg','text','chat','body')[:4000]
    action = _chat_pick(fields, 'action','cmd','command','mode','request').lower()

    # Registration proves an identity exists, not that a client is online.
    registered = set()
    try:
        with UIN_REGISTRATION_LOCK:
            if UIN_REGISTRATION_FILE.exists():
                registry = json.loads(UIN_REGISTRATION_FILE.read_text(encoding='utf-8'))
                if isinstance(registry, dict):
                    registered = {v for v in registry.values() if isinstance(v, str) and v.isdigit()}
    except (OSError, ValueError):
        log.warning('UIN lookup registry unavailable; no presence inferred')

    with CHAT_LOCK:
        if uin:
            old = CHAT_USERS.get(uin, {})
            login_ip = old.get('ip', '')
            if action == 'l' and _chat_pick(fields, 'ip'):
                candidate = _chat_pick(fields, 'ip').strip().rstrip('_').replace('_', '.')
                try:
                    address = ipaddress.IPv4Address(candidate)
                    login_ip = str(address) if not (address.is_unspecified or address.is_multicast) else ''
                except ValueError:
                    login_ip = ''
            CHAT_USERS[uin] = {
                'name': name or old.get('name',''),
                'comments': comments or old.get('comments',''),
                'last_seen': now,
                'ip': login_ip,
                'published': bool(old.get('published', False) or
                                  (endpoint.lower() == 'uinlister.exe' and action == 'y')),
                'archived': bool(old.get('archived', False)),
            }
            CHAT_QUEUES.setdefault(uin, [])
            if action == 'l':
                log.warning('LEGACY CHAT LOGIN ip_valid=%s published=%s; values hidden',
                            'yes' if login_ip else 'no',
                            'yes' if CHAT_USERS[uin]['published'] else 'no')

        # Persist the newly published live UIN AFTER registering it.
        if uin and endpoint.lower() == 'uinlister.exe' and action == 'y':
            _chat_directory_save_state()

        import cyber_lan
        bot_ip=cyber_lan.advertised_ip()
        CHAT_USERS['1111'] = {'name': 'Cyber', 'comments': 'Unofficial local learning bot',
                              'last_seen': now if bot_ip else 0, 'published': True, 'archived': False, 'ip': bot_ip}
        sent = False
        if uin and dest == '1111' and message:
            try:
                bot_reply = cyber_bot.reply(uin, message, private=True)
                if bot_reply:
                    CHAT_QUEUES.setdefault(uin, []).append({'from_uin': '1111', 'from_name': 'Cyber', 'text': bot_reply, 'when': now})
                    sent = True
            except (OSError, ValueError, TypeError):
                log.warning('CYBER BOT: local memory unavailable; message not acknowledged')
        elif uin and dest and message:
            sender_name = CHAT_USERS.get(uin, {}).get('name','') or name
            CHAT_QUEUES.setdefault(dest, []).append({
                'from_uin': uin, 'from_name': sender_name,
                'text': message, 'when': now,
            })
            sent = True

        incoming = None
        # Poll/receive requests consume one queued message. Avoid consuming on a
        # request that is itself sending a message.
        wants_receive = (not message) and action not in {'g', 'l'} and (uin and (endpoint.lower() == 'cbonline2.exe' or
                         action in {'get','poll','receive','recv','check','online'}))
        if wants_receive and CHAT_QUEUES.get(uin):
            incoming = CHAT_QUEUES[uin].pop(0)

        lookup = dest or _chat_safe_uin(_chat_pick(fields, 'lookupuin','ping','finduin'))
        target = CHAT_USERS.get(lookup, {}) if lookup else {}
        if not target and lookup in registered:
            target = {'name': '', 'comments': '', 'last_seen': 0}
        online = bool(target and now - int(target.get('last_seen', 0)) <= 300)
        if action == 'g':
            # G is not only a visual ping: CyberBuddy uses it as the recipient
            # availability handshake before enabling a send target.
            if online and lookup:
                CHAT_LAST_TARGET['default'] = lookup
            log.warning('LEGACY CHAT PING target=<hidden> online=%s selected=%s',
                        'yes' if online else 'no',
                        'yes' if (online and lookup) else 'no')

        # Directory list is intentionally compact. Unknown clients can ignore it;
        # known marker lines remain available to the original CyberBuddy parser.
        directory = []
        if endpoint.lower() == 'uinlister.exe':
            for key, info in sorted(CHAT_USERS.items()):
                if info.get('published') and len(directory) < UIN_DIRECTORY_MAX:
                    directory.append('%s|%s' % (key, info.get('name','')))

    lines = [
        '$$UIN' + uin,
        '$$SNDTO' + (dest or lookup),
        '$$ONLINE=' + ('1' if online else '0'),
        '$$SENT=' + ('1' if sent else '0'),
    ]
    # Ping/Get-UIN compatibility records.  Keep these in addition to the
    # key=value form while reconstructing the original CyberBuddy parser.
    if action == 'g':
        lines += [
            '$$PING=' + (lookup or ''),
            '$$PINGONLINE=' + ('1' if online else '0'),
        ]
    if target:
        lines += [
            '$$NAME=' + target.get('name',''),
            '$$COMMENTS=' + target.get('comments',''),
            '$$UINFOUND=' + (lookup or ''),
            '$$STATUS=ONLINE' if online else '$$STATUS=OFFLINE',
        ]
    if incoming:
        lines += [
            '$$FROMUIN=' + incoming['from_uin'],
            '$$FROMNAME=' + incoming['from_name'],
            '$$MESSAGE=' + incoming['text'].replace('\r',' ').replace('\n',' '),
        ]
    for row in directory:
        lines.append('$$USER=' + row)
    lines.append('&&EOT')

    # CyberBud.exe: 0x52a9b8 reads online.html, finds the requested UIN,
    # then calls 0x52421c three times (split on &&). The fields are UIN,
    # IP (returned to the caller), and last-seen text (displayed in the list).
    # $$ markers belong to other chat transactions, not this lookup reply.
    if endpoint.lower() == 'cbonline2.exe' and action == 'g' and fields.get('_wire_format') == 'positional':
        address = target.get('ip', '') if target else ''
        # No verified offline wire record is available: omit inactive/unroutable
        # identities rather than giving the client a fabricated connection IP.
        payload = b''
        if online and address:
            seen = datetime.datetime.fromtimestamp(int(target['last_seen'])).strftime('%m-%d %H:%M')
            payload = ('%s&&%s&&%s\r\n' % (lookup, address, seen)).encode('cp1252')
        reason = ('active-client' if payload else
                  'registered-without-client-login' if lookup in registered and not target.get('last_seen') else
                  'unknown-uin' if not target else
                  'client-offline' if not online else 'missing-or-invalid-login-ip')
        log.warning('LEGACY CHAT G RESPONSE online=%s bytes=%d format=uin-ip-seen reason=%s',
                    'yes' if payload else 'no', len(payload), reason)
        return payload

    return ('\r\n'.join(lines) + '\r\n').encode('windows-1252', 'replace')


def cached_forecast(url):
    """Share recent forecasts and stop retrying while Open-Meteo throttles us."""
    global WEATHER_COOLDOWN_UNTIL
    with WEATHER_LOCK:
        now = time.monotonic()
        saved = WEATHER_CACHE.get(url)
        if saved and now - saved[0] < 20 * 60:
            return saved[1], False
        if now < WEATHER_COOLDOWN_UNTIL:
            if saved:
                return saved[1], True
            raise RuntimeError("Open-Meteo rate limit: please try again later")
        try:
            with direct_urlopen(url, timeout=TIMEOUT) as response:
                data = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as error:
            if error.code != 429:
                if saved:
                    return saved[1], True
                raise
            retry = error.headers.get("Retry-After", "") if error.headers else ""
            try:
                delay = max(60, min(3600, int(retry)))
            except (TypeError, ValueError):
                delay = 300
            WEATHER_COOLDOWN_UNTIL = time.monotonic() + delay
            log.warning("Open-Meteo rate limited requests; pausing for %s seconds", delay)
            if saved:
                return saved[1], True
            raise RuntimeError("Open-Meteo rate limit: please try again later") from error
        except (OSError, ValueError):
            if saved:
                return saved[1], True
            raise
        WEATHER_CACHE[url] = (time.monotonic(), data)
        return data, False


def cached_geocode(url, user_agent):
    """Avoid asking Nominatim again for every repeat visit to a location."""
    with WEATHER_LOCK:
        saved = GEOCODE_CACHE.get(url)
        if saved and time.monotonic() - saved[0] < 24 * 3600:
            return saved[1]
        request = urllib.request.Request(url, headers={"User-Agent": user_agent})
        with direct_urlopen(request, timeout=TIMEOUT) as response:
            places = json.loads(response.read().decode("utf-8"))
        GEOCODE_CACHE[url] = (time.monotonic(), places)
        return places


def cached_inmet_alerts(place):
    """Reuse an INMET result or outage briefly instead of retrying on refresh."""
    key = (str(place.get("lat")), str(place.get("lon")))
    with WEATHER_LOCK:
        saved = INMET_ALERT_CACHE.get(key)
        if saved and time.monotonic() - saved[0] < 5 * 60:
            if saved[2]:
                raise ValueError(saved[2])
            return saved[1]
        try:
            notices = fetch_inmet_alerts(place)
        except (OSError, ValueError, ET.ParseError, KeyError) as error:
            INMET_ALERT_CACHE[key] = (time.monotonic(), None, str(error))
            raise
        INMET_ALERT_CACHE[key] = (time.monotonic(), notices, None)
        return notices


def observation_is_night(current, daily):
    """Use local observation time and that date's sunrise/sunset for the icon."""
    try:
        observed = datetime.datetime.fromisoformat(str(current['time']))
        dates = daily.get('time') or []
        index = dates.index(observed.date().isoformat())
        sunrise = datetime.datetime.fromisoformat(str(daily['sunrise'][index]))
        sunset = datetime.datetime.fromisoformat(str(daily['sunset'][index]))
        return observed < sunrise or observed >= sunset
    except (KeyError, ValueError, IndexError, TypeError):
        # Open-Meteo supplies this when daily sunrise/sunset are unavailable.
        return current.get('is_day') == 0


def forecast_place_name(place, requested):
    """Use a named locality for the old forecast heading, never a postal code."""
    address = place.get("address") or {}
    for key in ("city", "town", "village", "municipality", "hamlet", "county"):
        name = str(address.get(key) or "").strip()
        if name and not re.fullmatch(r"[0-9][0-9\s-]*", name):
            return clean_news_text(name)
    for part in str(place.get("display_name") or "").split(","):
        name = part.strip()
        if name and not re.fullmatch(r"[0-9][0-9\s-]*", name):
            return clean_news_text(name)
    return clean_news_text(requested)


def cap_value(element, name):
    """Read a CAP XML child independent of its namespace."""
    return next((child.text.strip() for child in element if child.tag.rsplit('}', 1)[-1] == name
                 and child.text), "")


def cap_inside_polygon(latitude, longitude, polygon):
    try:
        points = [tuple(float(v) for v in pair.split(',')) for pair in polygon.split()]
        if len(points) < 3:
            return False
        inside = False
        for index, (y1, x1) in enumerate(points):
            y2, x2 = points[(index + 1) % len(points)]
            if (y1 > latitude) != (y2 > latitude) and longitude < (x2 - x1) * (
                    latitude - y1) / (y2 - y1) + x1:
                inside = not inside
        return inside
    except (ValueError, ZeroDivisionError):
        return False


def inmet_alert_for_place(area, place):
    """Reject national/state alerts unless the specific city or point matches."""
    address = place.get('address') or {}
    city = str(address.get('city') or address.get('town') or
               address.get('municipality') or '').strip()
    state = str(address.get('state_code') or '').strip()
    for child in area:
        tag = child.tag.rsplit('}', 1)[-1]
        if tag == 'polygon' and child.text and cap_inside_polygon(
                float(place['lat']), float(place['lon']), child.text):
            return True
        if tag == 'geocode' and city and state:
            name = cap_value(child, 'valueName')
            value = cap_value(child, 'value')
            if name.casefold() in {'municipios', 'municípios'}:
                normalized = lambda s: ''.join(c for c in unicodedata.normalize('NFKD', s.casefold())
                                               if not unicodedata.combining(c))
                pattern = rf'(?:^|,)\s*{re.escape(normalized(city))}\s*-\s*{re.escape(normalized(state))}\s*\('
                if re.search(pattern, normalized(value)):
                    return True
    return False


def fetch_inmet_alerts(place, now=None):
    """INMET official RSS of CAP notices, filtered by their affected area."""
    now = now or datetime.datetime.now(datetime.timezone.utc)
    feed = 'https://apiprevmet3.inmet.gov.br/avisos/rss'
    with direct_urlopen(urllib.request.Request(feed, headers={'User-Agent':
                        'CyberBuddyClassicProxy/6.2 (weather alerts)'}),
                        timeout=min(TIMEOUT, 6)) as response:
        root = ET.fromstring(response.read(2 * 1024 * 1024))
    links = []
    for item in root.iter():
        if item.tag.rsplit('}', 1)[-1] not in {'item', 'entry'}:
            continue
        for child in item:
            if child.tag.rsplit('}', 1)[-1] == 'link':
                links.append((child.get('href') or child.text or '').strip())
    if root.tag.rsplit('}', 1)[-1] == 'alert':
        alerts_xml = [root]
    else:
        alerts_xml = []
    valid_links = []
    for link in dict.fromkeys(links):
        parsed = urllib.parse.urlparse(link)
        if parsed.scheme != 'https' or parsed.hostname != 'apiprevmet3.inmet.gov.br' or not re.fullmatch(
                r'/avisos/rss/\d+', parsed.path):
            continue
        valid_links.append(link)
    # The INMET host can reset concurrent requests. Stop after the first
    # unavailable CAP document: silently skipping it could produce a false
    # "no alerts" result for the requested municipality.
    if links and len(valid_links) != len(set(links)):
        raise ValueError('INMET feed contained unsupported or incomplete alert links')
    for link in valid_links:
        try:
            with direct_urlopen(link, timeout=min(TIMEOUT, 4)) as response:
                alerts_xml.append(ET.fromstring(response.read(512 * 1024)))
        except (OSError, ValueError, ET.ParseError) as error:
            raise ValueError('INMET alert details unavailable; coverage cannot be confirmed') from error
    results = []
    for alert in alerts_xml:
        for info in alert:
            if info.tag.rsplit('}', 1)[-1] != 'info':
                continue
            expiry = cap_value(info, 'expires')
            try:
                until = datetime.datetime.fromisoformat(expiry.replace('Z', '+00:00'))
                if until.tzinfo is None or until <= now:
                    continue
            except ValueError:
                continue
            if not any(area.tag.rsplit('}', 1)[-1] == 'area' and
                       inmet_alert_for_place(area, place) for area in info):
                continue
            event = cap_value(info, 'event') or 'Weather alert'
            message = cap_value(info, 'headline') or cap_value(info, 'description')
            message = re.sub(r'\s+', ' ', message).strip()[:220]
            record = (event, until, message)
            if record not in results:
                results.append(record)
    return results[:5]


def fetch_global_alerts(place, now=None):
    """Find location-matched meteorological CAP warnings in IFRC Alert Hub."""
    now = now or datetime.datetime.now(datetime.timezone.utc)
    endpoint = 'https://alerthub-api.ifrc.org/graphql/'
    def query(graphql, variables=None):
        payload = json.dumps({'query': graphql, 'variables': variables or {}}).encode('utf-8')
        request = urllib.request.Request(endpoint, data=payload, headers={
            'Content-Type': 'application/json',
            'User-Agent': 'CyberBuddyClassicProxy/6.2 (weather alerts)'})
        with direct_urlopen(request, timeout=min(TIMEOUT, 7)) as response:
            result = json.loads(response.read(3 * 1024 * 1024))
        if result.get('errors'):
            raise ValueError('IFRC Alert Hub rejected the alert query')
        return result['data']['public']

    countries = query('{ public { countries { items { id name iso3 alertCount } } } }')[
        'countries']['items']
    country_name = str((place.get('address') or {}).get('country') or '')
    normalized = lambda s: ''.join(c for c in unicodedata.normalize('NFKD', s.casefold())
                                   if not unicodedata.combining(c))
    country = next((item for item in countries if normalized(item['name']) ==
                    normalized(country_name)), None)
    if country is None:
        return None  # No confirmed national feed coverage for this location.
    if not country.get('alertCount'):
        feeds = query('{ public { feeds { items { countryId enablePolling official status } } } }')[
            'feeds']['items']
        covered = any(feed['countryId'] == country['id'] and feed['enablePolling'] and
                      feed['official'] and feed['status'] == 'ACTIVE' for feed in feeds)
        return [] if covered else None
    listing = query('''query($id: ID!) { public {
      alerts(filters: {country: {pk: $id}}, pagination: {limit: 100, offset: 0}) {
        count items { id status msgType infos { language category event headline description
          expires areas { areaDesc polygons { value } circles { value } } } }
      }
    } }''', {'id': country['id']})['alerts']
    if listing['count'] > 100:
        raise ValueError('Too many alerts to check every affected area')
    lat, lon = float(place['lat']), float(place['lon'])
    results = []
    for alert in listing['items']:
        if alert['status'] != 'ACTUAL' or alert['msgType'] not in ('ALERT', 'UPDATE'):
            continue
        for info in alert.get('infos') or []:
            if info['category'] != 'MET':
                continue
            try:
                expiry = datetime.datetime.fromisoformat(info['expires'].replace('Z', '+00:00'))
                if expiry.tzinfo is None or expiry <= now:
                    continue
            except (AttributeError, ValueError):
                continue
            matched = False
            for area in info.get('areas') or []:
                if any(cap_inside_polygon(lat, lon, p['value']) for p in area.get('polygons') or []):
                    matched = True
                for circle in area.get('circles') or []:
                    try:
                        center_lat, center_lon, radius_km = map(float, re.split(r'[ ,]+', circle['value']))
                        import math
                        dlat, dlon = math.radians(lat - center_lat), math.radians(lon - center_lon)
                        a = (math.sin(dlat / 2) ** 2 + math.cos(math.radians(lat)) *
                             math.cos(math.radians(center_lat)) * math.sin(dlon / 2) ** 2)
                        matched |= 12742 * math.asin(min(1, math.sqrt(a))) <= radius_km
                    except (ValueError, TypeError, KeyError):
                        continue
            if matched:
                message = re.sub(r'\s+', ' ', info.get('headline') or
                                 info.get('description') or '').strip()[:220]
                record = (info.get('event') or 'Weather alert', expiry, message)
                if record not in results:
                    results.append(record)
                break
    return results[:5]


def load_config() -> configparser.ConfigParser:
    cfg = configparser.ConfigParser()
    cfg.read(CONFIG_PATH, encoding="utf-8")
    return cfg


CFG = load_config()
if CFG.has_option("server", "bind"):
    BIND = CFG.get("server", "bind")
else:
    try:
        import cyber_lan as _cyber_lan_auto
        BIND = _cyber_lan_auto.detect_private_host() or "127.0.0.1"
    except Exception:
        BIND = "127.0.0.1"
PORT = CFG.getint("server", "port", fallback=8081)
TIMEOUT = CFG.getint("server", "timeout", fallback=45)
MAX_BODY_MB = CFG.getint("server", "max_body_mb", fallback=20)
CONVERT_XML = CFG.getboolean("compatibility", "convert_xml_to_windows_1252", fallback=True)
REMOVE_SCRIPTS = CFG.getboolean("compatibility", "remove_scripts_from_html", fallback=False)
VERIFY_TLS = CFG.getboolean("security", "verify_tls_certificates", fallback=True)
POP3_ENABLED = CFG.getboolean("pop3_bridge", "enabled", fallback=True)
POP3_BIND = CFG.get("pop3_bridge", "bind", fallback="127.0.0.1")
POP3_LOCAL_PORT = CFG.getint("pop3_bridge", "local_port", fallback=110)
POP3_REMOTE_HOST = CFG.get("pop3_bridge", "remote_host", fallback="pop.gmail.com")
POP3_REMOTE_PORT = CFG.getint("pop3_bridge", "remote_port", fallback=995)
SMTP_ENABLED = CFG.getboolean("smtp_bridge", "enabled", fallback=True)
SMTP_BIND = CFG.get("smtp_bridge", "bind", fallback="127.0.0.1")
SMTP_LOCAL_PORT = CFG.getint("smtp_bridge", "local_port", fallback=25)
SMTP_REMOTE_HOST = CFG.get("smtp_bridge", "remote_host", fallback="smtp.gmail.com")
SMTP_REMOTE_PORT = CFG.getint("smtp_bridge", "remote_port", fallback=465)


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[logging.FileHandler(LOG_PATH, encoding="utf-8"), logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("cyberbuddy-proxy")

_chat_directory_load_state()
log.info("CHAT DATABASE: loaded persistent live-user state; startup reset disabled")

# A browser using the system proxy may cancel thousands of background requests.
# Keep one useful diagnostic per upstream host instead of flooding the console.
UPSTREAM_FAILURES = {}
UPSTREAM_FAILURES_LOCK = threading.Lock()


def log_upstream_failure(target, error):
    address = urllib.parse.urlsplit(target)
    host = address.hostname or "unknown host"
    host_port = host + (":" + str(address.port) if address.port else "")
    now = time.monotonic()
    with UPSTREAM_FAILURES_LOCK:
        if len(UPSTREAM_FAILURES) > 512:
            UPSTREAM_FAILURES.clear()
        previous, suppressed = UPSTREAM_FAILURES.get(host_port, (0, 0))
        if now - previous < 30:
            UPSTREAM_FAILURES[host_port] = (previous, suppressed + 1)
            return
        UPSTREAM_FAILURES[host_port] = (now, 0)
    log.warning("Upstream %s failed: %s%s", host_port, error,
                " (%d repeated failures suppressed)" % suppressed if suppressed else "")

# The app password is retained only in process memory after a successful POP3
# login. It is never written to proxy.ini or proxy.log.
MAIL_CREDENTIALS = {"username": None, "password": None}
MAIL_CREDENTIALS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mail_credentials.ini")

def _save_mail_credentials(username, password):
    if not username or not password:
        return
    try:
        cfg = configparser.ConfigParser()
        cfg["mail"] = {"username": str(username), "password": str(password)}
        with open(MAIL_CREDENTIALS_FILE, "w", encoding="utf-8") as f:
            cfg.write(f)
        try:
            os.chmod(MAIL_CREDENTIALS_FILE, 0o600)
        except Exception:
            pass
        log.warning("MAIL CREDENTIAL BRIDGE: credentials cached locally")
    except Exception as error:
        log.warning("MAIL CREDENTIAL BRIDGE: cache failed: %s", error)

def _load_mail_credentials():
    try:
        if not os.path.isfile(MAIL_CREDENTIALS_FILE):
            return None, None
        cfg = configparser.ConfigParser()
        cfg.read(MAIL_CREDENTIALS_FILE, encoding="utf-8")
        return cfg.get("mail","username",fallback=None), cfg.get("mail","password",fallback=None)
    except Exception as error:
        log.warning("MAIL CREDENTIAL BRIDGE: load failed: %s", error)
        return None, None

MAIL_CREDENTIALS_LOCK = threading.Lock()

FUN_ITEMS = {'joke': ("&&Explain\nDo you know why they're not growing bananas any longer? \\pau=3000\\ Because they're long enough already!\n&&Blink\n&&RestPose", "&&Explain\nWhat's black when clean, and white when dirty? \\pau=2000\\ A Blackboard!\n&&RestPose", '&&Explain\nWhat is always behind time? \\pau=2000\\ The back of a clock!\n&&RestPose', "&&Explain\nWhen is a window like a star? \\pau=2000\\ When it's a skylight!\n&&RestPose", "&&Explain\nWhat is the longest word in the English dictionary? \\pau=3000\\ 'Smiles', because there's a mile between its first letter and last letter!\n&&RestPose", '&&Explain\nHow can you communicate with a fish? \\pau=2000\\ Drop him a line!\n&&RestPose', "&&Explain\nWhy do we call money, 'bread'? \\pau=2000\\Because everybody \\emp\\'kneads' it!\n&&RestPose", "&&Explain\nDo you know what a politically correct computer virus is? \\pau=2000\\ One that refers to itself as an 'electronic micro organism'.\n&&RestPose", '&&Explain\nDid you hear about the new computer virus called the Star Trek virus. \\pau=1000\\ It invades your system in places where no virus has gone before!\n&&RestPose', '&&Explain\nDid you hear about the man who was \\emp\\tap dancing?  \\pau=2000\\ He broke his ankle when he fell into the sink!\n&&RestPose', "&&Explain\nDo you know the definition of an \\emp\\'ethernet'?  \\pau=2000\\ Its something used to catch the eitherbunny!\n&&RestPose", '&&Explain\nDo you know what a software Upgrade is?  \\pau=2000\\  Taking out old bugs and putting in new bugs!\n&&RestPose', "&&Explain\nHow long is a computer's attention span?  \\pau=2000\\ As long as its power cord!\n&&RestPose", "&&Explain\nHow do you know when you've purchased a lousy computer?  When it has the words 'Ectch-A-Sketch' in the corner!\n&&RestPose", "&&Explain\nKnow why, tech support for an Etch-A-Sketch was much simpler than for computers? \\pau=1000\\ Because there was only one answer for every question, \\pau=1000\\ 'Pick it up and shake it'!\n&&RestPose", "&&Explain\nWhat do you call a cow that can't give milk? \\pau=1500\\ An utter failure!\n&&RestPose", '&&Explain\nTwo sausages are in a pan. One looks at the other and says "Boy it\'s hot in here!"\\pau=500\\ and the other sausage says "Unbelievable! It\'s a talking sausage!" \\pau=2000\\ He who laughs last thinks slowest!\n&&RestPose', '&&Explain\nWhat did Batman say to Robin before they got in the car? \\pau=2000\\ Robin, get in the car!\n&&RestPose', '&&Explain\nWhat happened to the mechanic who fell asleep dreaming about car mufflers? \\pau=2000\\ He woke up exhausted!\n&&RestPose', '&&Explain\nOne atom goes to the other and says, "I think I lost an electron." \\pau=500\\ And the other asks, "are you sure???" And the one goes, "I\'m positive".\n&&RestPose', '&&Explain\nWhat does a pig use to store data on a computer? \\pau=2000\\ A sloppy disk!\n&&RestPose', '&&Explain\nWhy do they call HTML hyper text? \\pau=2000\\ To much Java!\n&&RestPose', '&&Explain\nWhat do you call a Pain in the lower back that occurs, only when you say the wrong thing? \\pau=1500\\ A Freudian slip-disc!\n&&RestPose', '&&Explain\nWhy are fish so smart? \\pau=1000\\ Because they live in schools!\n&&RestPose', '&&Explain\nWhat happens when you throw a green rock in the Red sea? \\pau=1500\\ It gets wet!\n&&RestPose', '&&Explain\nWhat happened to the Wooden Car? \\pau=2000\\ It Wooden Go!\n&&RestPose', '&&Explain\nWhy did the golfer bring two pairs of pants? \\pau=2000\\ In case he gets a hole in one!\n&&RestPose', '&&Explain\nWhat does a clean nose have? \\pau=2000\\ Fingerprints!\n&&RestPose', "&&Explain\nWhat's the difference between an amateur programmer and a professional? \\pau=1500\\ An amateur thinks that 1 kilobyte is 1000 bytes. \\pau=500\\ A professional thinks that 1 kilometer is 1024 meters!\n&&RestPose", "&&Explain\nWhat's the difference between a hill and a pill? \\pau=1200\\ A hill is hard to get up, and a pill is hard to get down!\n&&RestPose", '&&Explain\nWhat happened to the flea circus? \\pau=1200\\ A dog came on and stole the show!\n&&RestPose', '&&Explain\nWhy did Dracula take cough medicine? \\pau=1200\\ To stop his coffin!\n&&RestPose', '&&Explain\nWhy were the middle ages also called the Dark Ages? \\pau=1200\\ Because there were lots of knights in those days!\n&&RestPose', '&&Explain\nWhat never asks questions but gets pressed for answers? \\pau=1200\\ A doorbell!\n&&RestPose', '&&Explain\nWhat travels underground at 80 miles per hour? \\pau=1200\\ A mole on a motorbike!\n&&RestPose', '&&Explain\nI have six eyes, two mouths and three ears.. What am I? \\pau=1500\\ A monster!\n&&Confused\n&&RestPose', '&&Explain\nWhat happens to an old suit when you throw it in the river! \\pau=1200\\ It changes into a wet suit!\n&&RestPose', '&&Explain\nWhat is in the middle of Paris? \\pau=1200\\ The letter "r"!\n&&RestPose', '&&Explain\nWho earns a living by driving his customers away? \\pau=1200\\ A taxi driver!\n&&RestPose', "&&Explain\nWhen is a pie like a poet? \\pau=1200\\ When it's Browning!\n&&RestPose", '&&Explain\nWhat do you get when you cross a dog with an elephant? \\pau=1200\\ A very nervous postman!\n&&RestPose', "&&Explain\nWhere do dogs go when they've lost their tails? \\pau=1200\\ To the retailer!\n&&RestPose", '&&Explain\nWhat sound do porcupines make when they kiss? \\pau=1200\\ Ouch!\n&&RestPose', '&&Explain\nWhat do you get when you cross a parrot with a canary? \\pau=1200\\ A bird that knows both the words \\pau=500\\and the music!\n&&RestPose', "&&Explain\nWhat did one fish say to the other? \\pau=1200\\ If you keep your mouth shut, you won't get caught!\n&&RestPose", "&&Explain\nWhy can't you have a quiet game of cards in the jungle? \\pau=1200\\ Because there are too many cheetahs around!\n&&RestPose", "&&Explain\nWhy shouldn't you tell secrets when a clock is around? \\pau=2000\\ Because time will tell!\n&&RestPose", '&&Explain\nWhen does a police dog not look like a police dog? \\pau=1200\\ When its an undercover agent!\n&&RestPose', "&&Explain\nWhat did the beaver say to the tree? \\pau=1200\\ It's been nice gnawing you!\n&&RestPose", '&&Explain\nWhat animal has two humps and is found in the North Pole? \\pau=1200\\ A lost camel!\n&&RestPose', '&&Explain\nWhat is the easiest way to get on TV? \\pau=1200\\ Sit on your set!\n&&RestPose', '&&Explain\nHow does the ice cream man go to work if his van breaks down? \\pau=1200\\ By icicle!\n&&RestPose', "&&Explain\nThree men were under an umbrella, but none of them got wet.. How did they do it? \\pau=2000\\ It wasn't raining!\n&&RestPose", '&&Explain\nWhere does the general keep his armies?\\pau=1500\\Up \\emp\\his sleevies!\n&&RestPose', "&&Explain\nWhen is the best time to go to bed?\\pau=1500\\When the bed won't come to \\emp\\you!\n&&RestPose", '&&Explain\nWhat goes in pink and comes out blue?\\pau=1500\\A swimmer on a \\emp\\cold day!\n&&RestPose', "&&Explain\nWhat are frogs' favorite tales?\\pau=1500\\Croak and \\emp\\dagger stories!\n&&RestPose", '&&Explain\nWhat animal is always laughing?\\pau=1500\\A \\emp\\happy-potamus!\n&&RestPose', "&&Explain\nWhen is a child not his father's son?\\pau=1500\\When its a daughter!\n&&RestPose", '&&Explain\nWhat did the big flower say to the little flower?\\pau=1500\\Hi \\emp\\Bud!\n&&RestPose', '&&Explain\nWhere do you leave a dog when you go shopping?\\pau=1500\\In the \\emp\\barking lot!\n&&RestPose', '&&Explain\nHow do you cut an ocean in two?\\pau=1500\\With a \\emp\\sea-saw!\n&&RestPose', '&&Explain\nWhy did the boy throw the butter out the window?\\pau=1500\\Because he wanted to \\emp\\see a butterfly!\n&&RestPose', '&&Explain\nWhat are the best things to put in a fruit pie?\\pau=1500\\Your teeth!\n&&RestPose', '&&Explain\nWhen does an astronaut have a mid day meal?\\pau=1500\\At \\emp\\launch time!\n&&RestPose', "&&Explain\nHow can you tell if an elephant has been sleeping in your bed?\\pau=1500\\Because it'll be full of \\emp\\peanut shells!\n&&RestPose", '&&Explain\nWhat do elephants have that no other animal has?\\pau=1500\\\\emp\\Baby elephants!\n&&RestPose', '&&Explain\nWhere does satisfaction come from?\\pau=1500\\A satisfactory!\n&&RestPose', '&&Explain\nOn a hot day, what is the best kind of letter to read?\\pau=1500\\\\emp\\Fan mail!\n&&RestPose', '&&Explain\nWhen are people glad to be down-and-out?\\pau=1500\\After a bumpy \\emp\\plane ride!\n&&RestPose', '&&Explain\nWhat is it that you cannot hold for fifteen minutes, even though it is lighter than a feather?\\pau=1400\\Your breath!\n&&RestPose', '&&Explain\nIf you were locked out of your house, how would you get in?\\pau=1400\\Sing a song until you found the \\emp\\right key!\n&&RestPose', '&&Explain\nWhy did the comedian tell jokes in front of the mirror?\\pau=1400\\He wanted to see it \\emp\\crack up!\n&&RestPose', '&&Explain\nWhat is easy to get into, but hard to get out of?\\pau=1400\\Trouble!\n&&RestPose', "&&Explain\nWhat would Neptune say if all the seas dried up?\\pau=1400\\I haven't \\emp\\a notion!\n&&RestPose", '&&Explain\nWhat is the definition of a sculptor?\\pau=1400\\A chip off the \\emp\\old block!\n&&RestPose', '&&Explain\nWhere does a chimney sweep keep his brushes?\\pau=1400\\In a \\emp\\soot case!\n&&RestPose', "&&Explain\nWhen is baseball like a crime?\\pau=1400\\When it's a \\emp\\hit and run!\n&&RestPose", '&&Explain\nWhat is the definition of a budget?\\pau=1400\\A system of worrying both before \\emp\\and after you spend money..Not \\emp\\just before!\n&&RestPose', '&&Explain\nHow do you stop your feet from falling asleep?\\pau=1400\\Wear \\emp\\loud socks!\n&&RestPose', '&&Explain\nHave you heard about the man with five legs?\\pau=1400\\His \\emp\\trousers fit him like \\emp\\a glove!\n&&RestPose', '&&Explain\nWhat happened to the man who stole ten bars of soap?\\pau=1400\\He made a \\emp\\clean get away!\n&&RestPose', '&&Explain\nWhat can you serve, but never eat?\\pau=1400\\A \\emp\\tennis ball!\n&&RestPose', "&&Explain\nWhat happened when the frog's car broke down on the highway?\\pau=1400\\He was \\emp\\toad away!\n&&RestPose", '&&Explain\nHow does a ship hear things?\\pau=1400\\Through its engineers!\n&&RestPose', '&&Explain\nWhere do dogs go when they lose their tails?\\pau=1400\\To the retailer!\n&&RestPose', '&&Explain\nWhat do you call a person who thinks he has wings and can fly?\\pau=1400\\Plane Crazy!\n&&RestPose', "&&Explain\nWhat can't be used until you break it?\\pau=1400\\An egg!\n&&RestPose", '&&Explain\nWhat kind of ant can count?\\pau=1400\\An account-ant!\n&&RestPose', '&&Explain\nWhat was the turtle doing on the interstate?\\pau=1400\\About two miles \\emp\\per hour!\n&&RestPose', "&&Explain\nWhy wasn't the elephant allowed on the airplane?\\pau=1400\\Because his trunk was too big to fit \\emp\\under the seat!\n&&RestPose", '&&Explain\nWhat do you call the life-story of a car?\\pau=1400\\An autobiography!\n&&RestPose', '&&Explain\nHow do you catch monkeys?\\pau=1400\\Hang from a tree and make a noise \\emp\\like a banana!\n&&RestPose', "&&Explain\nWhat advice can you give a fish to avoid being caught?\\pau=1400\\Don't fall for any \\emp\\old line!\n&&RestPose", '&&Explain\nWhy are people stronger on Saturdays and Sundays?\\pau=1400\\Because all the other days are \\emp\\weekdays!\n&&RestPose', '&&Explain\nWhat did the paper say to the pencil?\\pau=1400\\"Write on, \\emp\\Dude!\n&&RestPose', '&&Explain\nWhen does coffee taste like mud?\\pau=1400\\When it is \\emp\\freshly ground!\n&&RestPose', "&&Explain\nWhats the difference between an elephant and a doughnut?\\pau=1400\\You can't dip an elephant in \\emp\\your coffee!\n&&RestPose", "&&Explain\nWhy should you never swim on an empty stomach?\\pau=1400\\It's easier to swim \\emp\\in water!\n&&RestPose", '&&Explain\nDid you hear the story about the man who changed his address after forty years?\\pau=1400\\It was a \\emp\\moving tale!\n&&RestPose', "&&Explain\nA cowboy rode to an inn on Friday. He stayed two nights and left on Friday. \\emp\\How could that be?\\pau=1400\\His horse's name was Friday!\n&&RestPose", '&&Explain\nWhat is the definition of an optimist?\\pau=1400\\A man who falls from the top of the Eiffel Tower and says on the way down.."Well, I\'m not hurt yet"!\n&&RestPose', '&&Explain\nWhat has four legs one head but only one foot?\\pau=1500\\A bed!\n&&RestPose', '&&Explain\nWhere do cows go to have fun?\\pau=1500\\To the mooovies!\n&&RestPose', "&&Explain\nWhy didn't the skeleton go to the ball? \\pau=1500\\Because he had no \\emp\\body to go with!\n&&RestPose", '&&Explain\nWhat do you call a cow in an earthquake?\\pau=1500\\A milkshake!\n&&RestPose', '&&Explain\nWhy is a cat in the desert like Christmas?\\pau=1500\\Because of its \\emp\\sandy claws!\n&&RestPose', '&&Explain\nWhy was 6 afraid of 7?\\pau=1500\\Because 7 8 9!\n&&RestPose', '&&Explain\nWhy did the man put his money in the freezer? \\pau=1500\\He wanted \\emp\\cold hard cash!\n&&RestPose', '&&Explain\nWhat did the porcupine say to the cactus? \\pau=1500\\"Is that you, \\emp\\Mama?"\n&&RestPose', '&&Explain\nWhat is black and white and sleeps a lot?\\pau=1500\\A snooze paper!\n&&RestPose', '&&Explain\nWhat did one plate say to the other plate? \\pau=1500\\"Lunch is \\emp\\on me!"\n&&RestPose', '&&Explain\nWhat do potatoes wear to bed?\\pau=1500\\Their yammies!\n&&RestPose', '&&Explain\nWhat do birds need when they are sick?\\pau=1500\\A tweetment!\n&&RestPose', '&&Explain\nWhat vegetable do you get when King Kong walks through your garden?\\pau=1500\\Squash!\n&&RestPose', '&&Explain\nWhat dog keeps the best time?\\pau=1500\\A \\emp\\watch dog!\n&&RestPose', '&&Explain\nWhat do you get when you cross a telephone with a very big football player?\\pau=1500\\A wide receiver!\n&&RestPose', '&&Explain\nWhy did the man destroy his piano?\\pau=1500\\He was looking for his keys!\n&&RestPose', '&&Explain\nWhat do you call a 5000 pound gorilla?\\pau=1500\\Sir!\n&&RestPose', '&&Explain\nWhat has four legs, is big, green, fuzzy, and if it fell out of a tree would make a loud sound? \\pau=1500\\ A pool table!\n&&RestPose', "&&Explain\nWhy do cows use the doorbell?\\pau=1500\\Because their \\emp\\horns don't work!\n&&RestPose", '&&Explain\nWhat do you have if you have 100 rabbits in a row, and 99 step back?\\pau=1500\\A receding hare line!\n&&RestPose', '&&Explain\nWhat time is it when a elephant sits on a fence?\\pau=1500\\Time to get a new fence!\n&&RestPose', '&&Explain\nHow much money did the pirate pay for his ear to get pierced?\\pau=1500\\A buck an ear!\n&&RestPose', '&&Explain\nWhy did the tomato blush?\\pau=1500\\Because it saw the salad dressing!\n&&RestPose', '&&Explain\nWhat did the grape do when it got stepped on?\\pau=1500\\It let out a \\emp\\little wine!\n&&RestPose', "&&Explain\nWhat do you call a boomerang that doesn't come back?\\pau=1500\\A stick!\n&&RestPose", '&&Explain\nWhat do you get when you cross a snake and a kangaroo? \\pau=1500\\A jump rope!\n&&RestPose', '&&Explain\nHow do you make a tissue dance?\\pau=1500\\Put a little booggy in it!\n&&RestPose', '&&Explain\nWhy did the cookie go to see the doctor?\\pau=1500\\He was \\emp\\feeling crummy!\n&&RestPose', '&&Explain\nHow do you catch a squirrel?\\pau=1500\\Climb a tree and \\emp\\act like a nut!\n&&RestPose', '&&Explain\nHow can you tell if a calendar is popular?\\pau=1500\\It has a \\emp\\lot of dates!\n&&RestPose', '&&Explain\nHow do you stop a skunk from smelling?\\pau=1500\\Put a \\emp\\clothes peg on its nose!\n&&RestPose', '&&Explain\nWhen is a car not a car?\\pau=1500\\When it \\emp\\turns into a garage!\n&&RestPose', '&&Explain\nWhat does a bee use to brush its hair?\\pau=1500\\A honey comb!\n&&RestPose', '&&Explain\nWhat do you get when you cross a cow with a rabbit?\\pau=1500\\Hare \\emp\\in your milk!\n&&RestPose', '&&Explain\nWhat do you say to a skeleton before he eats?\\pau=1500\\Bone appa teet!\n&&RestPose', '&&Explain\nWhat do you say to a skeleton going on vacation?\\pau=1500\\Bone voyaage!\n&&RestPose', "&&Explain\nWhat did the envelope say to the stamp?\\pau=1400\\Stick with me, baby, and \\emp\\we'll go places!\n&&RestPose", '&&Explain\nWhy is tennis a noisy game?\\pau=1400\\Cause when you play it you have to \\emp\\raise a racket!\n&&RestPose', '&&Explain\nWhat is a happy tin in the \\emp\\United States?\\pau=1400\\A-merry-can!\n&&RestPose', '&&Explain\nWhat room has no walls, floor, ceiling, or windows?\\pau=1400\\A mushroom!\n&&RestPose', '&&Explain\nWhat is the invention that allows you to see through the thickest walls?\\pau=1400\\A window!\n&&RestPose', '&&Explain\nWhy did the man throw his watch out of the window?\\pau=1400\\To see time fly!\n&&RestPose', '&&Explain\nWhat has a neck but no head?\\pau=1400\\A bottle!\n&&RestPose', "&&Explain\nWhy couldn't the leopard escape from the zoo?\\pau=1400\\Cause he was \\emp\\always spotted!\n&&RestPose", "&&Explain\nWhy is the letter 'A' like a flower?\\pau=1400\\Cause the 'B' comes after it!\n&&RestPose", '&&Explain\nWhat nut has no shell?\\pau=1400\\\\emp\\A doughnut!\n&&RestPose', '&&Explain\nWhat has a bottom at the top?\\pau=1400\\A leg!\n&&RestPose', '&&Explain\nWhat has a bed but does not sleep..What has a mouth but does not speak?\\pau=2000\\\\emp\\A river!\n&&RestPose', '&&Explain\nIf your clock strikes thirteen, what time is it?\\pau=1400\\Time to get a \\emp\\new clock!\n&&RestPose', '&&Explain\nHow can you jump off a fifty foot ladder without hurting yourself?\\pau=1400\\Jump off the \\emp\\bottom rung!\n&&RestPose', "&&Explain\nWhen does a horse have six legs?\\pau=1400\\When it's got a \\emp\\rider on its back!\n&&RestPose", '&&Explain\nWhy should you never gossip in fields?\\pau=2000\\Because corn has ears, potatoes have eyes, and \\emp\\beanstalk!\n&&RestPose', '&&Explain\nWhat is cowhide mostly used for?\\pau=1400\\Holding cows together!\n&&RestPose', "&&Explain\nWhat type of water won't freeze?\\pau=2000\\\\emp\\Boiling water!\n&&RestPose", "&&Explain\nWhat occurs once in every minute, twice in every moment, but not once in a thousand years?\\pau=1400\\The letter 'M'!\n&&RestPose", '&&Explain\nWhat wears a coat all winter and pants all summer?\\pau=1400\\A dog!\n&&RestPose', '&&Explain\nWhat training do you need to be a garbage collector?\\pau=1400\\None..you pick it up as you \\emp\\go along!\n&&RestPose', '&&Explain\nWhat gets wetter as it dries?\\pau=1400\\A towel!\n&&RestPose', '&&Explain\nWhy do white sheep eat more grass than black sheep?\\pau=1400\\Because there are \\emp\\more of them!\n&&RestPose', "&&Explain\nWhat doesn't get any wetter, no matter how much it rains?\\pau=1400\\\\emp\\The ocean!\n&&RestPose", '&&Explain\nWhat is the only thing that you can put into a bucket that will make it lighter?\\pau=1400\\A hole!\n&&RestPose', '&&Explain\nWhat did the penny say to the other penny?  \\pau=1400\\We make \\emp\\perfect cents!\n&&RestPose', '&&Explain\nWhat are two things you cannot have for breakfast? \\pau=1400\\Lunch and dinner!\n&&RestPose', '&&Explain\nWhat did the judge say to the dentist? \\pau=1400\\Do you swear to pull the tooth, the whole tooth and nothing but the tooth!\n&&RestPose', '&&Explain\nWhat did the robot say to the traffic light? \\pau=1400\\You have beautiful eyes baby!\n&&RestPose', '&&Explain\nWhat is the difference between a teacher and a train conductor? \\pau=1400\\A teacher trains the mind and a train conductor minds the train!\n&&RestPose', '&&Explain\nWhat did one teddy bear say to the other teddy bear when he offered him some dessert? \\pau=1400\\\\emp\\No thank you, \\emp\\I am already stuffed.\n&&RestPose', '&&Explain\nWhat is the difference between a jeweler and a jailer? \\pau=1400\\One sells watches and one watches cells!\n&&RestPose', '&&Explain\nWhy did the picture have to go to jail? \\pau=1400\\Because it was framed!\n&&RestPose', "&&Explain\nWhat did one wall say to the other wall? \\pau=1400\\I'll meet you at the corner!\n&&RestPose", '&&Explain\nWhat did the alien say to the garden? \\pau=1400\\Take me to your weeder!\n&&RestPose', '&&Explain\nWhat letter is like an island? \\pau=1400\\T! Because it is in the middle of water!\n&&RestPose', '&&Explain\nWhat did the princess say when she was waiting for her photos? \\pau=1400\\Some day my prints will come.\n&&RestPose', '&&Explain\nWhen do doctors get angry? \\pau=1400\\When they run out of patience!\n&&RestPose', '&&Explain\nWhat do you say to a two-headed alien? \\pau=1400\\Hello! Hello!\n&&RestPose', '&&Explain\nWhy was the math book sad? \\pau=1400\\Because it had too many problems!\n&&RestPose', '&&Explain\nWhat do you say after you learn how to count money? \\pau=1400\\It all makes cents now!\n&&RestPose', "&&Explain\nIf athletes get athlete's foot, then what do astronauts get? \\pau=1400\\Missile toe!\n&&RestPose", "&&Explain\nWhat can jump higher than a house? \\pau=1400\\Anything,..houses can't jump!\n&&RestPose", '&&Explain\nWhat sort of star is dangerous? \\pau=1400\\A shooting star!\n&&RestPose', '&&Explain\nWhy did the belt go to jail? \\pau=1400\\Because it held up a pair of pants!\n&&RestPose', '&&Explain\nWhat do you call someone with a lightbulb in their head? \\pau=1400\\Very bright!\n&&RestPose', "&&Explain\nWhat did the painter say to the wall?\\pau=1400\\One more crack like that and I'll plaster you!\n&&RestPose", "&&Explain\nWhat did the tie say to the hat? \\pau=1400\\You go on a head, I'll just hang around!\n&&RestPose", "&&Explain\nWhat is a dentist's favorite flower? \\pau=1400\\Tulips ...because they protect the teeth!\n&&RestPose", '&&Explain\nWhy did the football coach go to the bank? \\pau=1400\\To get his \\emp\\quarter back!\n&&RestPose', "&&Explain\nWhat is a computer's favorite dance? \\pau=1400\\Disk-o!\n&&RestPose", '&&Explain\nWhat kind of ship never sinks?\\pau=1400\\Friendship!\n&&RestPose', '&&Explain\nWhat did the pencil sharpener say to the pencil?\\pau=1400\\Stop going in circles and get to the point!\n&&RestPose', '&&Explain\nWhat kind of car does Luke Skywalker drive?\\pau=1400\\A toy-yoda!\n&&RestPose', '&&Explain\nWhat seven letters did the little girl say when she opened the refrigerator and found there was nothing in it? \\pau=1400\\O.. I.. C..U.. R.. M.. T!\n&&RestPose', '&&Explain\nWhy did the scientist install a knocker on his door? \\pau=1400\\To win the Nobel prize!\n&&RestPose', '&&Explain\nWhen a lemon calls for help, what does it want?\\pau=1400\\Lemonade!\n&&RestPose', '&&Explain\nWhere do baby apes sleep?\\pau=1400\\In apricots!\n&&RestPose', '&&Explain\nWhere will you always find diamonds?\\pau=1400\\In a pack of cards!\n&&RestPose', '&&Explain\nWhat do you call someone who has a dictionary in his back pocket?\\pau=1400\\Smarty pants!\n&&RestPose', '&&Explain\nWhere can you always find success, health, wealth, and happiness?\\pau=1400\\The dictionary!\n&&RestPose', '&&Explain\nHow do you keep milk from turning sour?\\pau=1400\\Keep it in the fridge!\n&&RestPose', '&&Explain\nWhat do you call a freight train loaded with gum?\\pau=1400\\A \\emp\\chew-chew train!\n&&RestPose', '&&Explain\nWhat is a deer after it is seven months old?\\pau=1400\\\\emp\\Eight months old!\n&&RestPose', '&&Explain\nWhat two words have the most letters in them?\\pau=1400\\Post Office!\n&&RestPose', '&&Explain\nWhat will not speak unless it is spoken to, and cannot be seen but only heard?\\pau=2000\\An \\emp\\echo!\n&&RestPose', '&&Explain\nWhat is the science of shopping called?\\pau=1400\\Buy-ology!\n&&RestPose', '&&Explain\nWhat loses its head every day but gets it back at night?\\pau=2000\\A \\emp\\pillow!\n&&RestPose', "&&Explain\nWhat is the best thing to do if you don't feel \\emp\\well?\\pau=1400\\Take off your gloves!\n&&RestPose", '&&Explain\nWhat would you do if a hippopotamus sat in front of you at the movies?\\pau=1400\\Miss most of the movie!\n&&RestPose', '&&Explain\nHow many months have 28 days?\\pau=2000\\All of them!\n&&RestPose', '&&Explain\nWhy is it impossible to rain for two nights in a row?\\pau=1400\\Because there is a day in between!\n&&RestPose', '&&Explain\nWhat can you hold in your right hand but not in your left hand?\\pau=1400\\Your left elbow!\n&&RestPose', '&&Explain\nIf you dog chews up your favorite book, what should you do?\\pau=1400\\Take the words right out of his mouth!\n&&RestPose', '&&Explain\nWhat word, if pronounced right is wrong, but if pronounced wrong is right?\\pau=1400\\Wrong!\n&&RestPose', '&&Explain\nWhat is the most popular game show for fish?\\pau=1400\\Name that Tuna!\n&&RestPose', '&&Explain\nWhere is the largest diamond in the world found?\\pau=1400\\On a baseball field!\n&&RestPose', '&&Explain\nWhat five letter word has six left when you take away two letters?\\pau=2000\\Sixty!\n&&RestPose', '&&Explain\nWhat is the laziest letter in the alphabet?\\pau=1400\\The letter \'E\' because it is always in "bed"!\n&&RestPose', '&&Explain\nWhat type of running means walking?\\pau=1400\\Running out of gas!\n&&RestPose', '&&Explain\nWhat time is it when you are being chased by six angry tigers?\\pau=1400\\Six after one!\n&&RestPose', '&&Explain\nHow do you prevent a Summer cold?\\pau=1400\\Catch it in the Winter!\n&&RestPose', '&&Explain\nWhat has a left foot, a right foot, and another foot in the middle?\\pau=1400\\A Yardstick!\n&&RestPose', '&&Explain\nWhat kind of shoes do snakes wear? \\pau=1400\\Water Moccasins!\n&&RestPose', '&&Explain\nHow do you stop a snake from striking?\\pau=1400\\Pay it decent \\emp\\wages!\n&&RestPose', '&&Explain\nBioligist today confirmed the crossing of poison ivy and four leaf clovers.\\pau=1400\\Anyone touching it, gets a rash of good luck!\n&&RestPose', '&&Explain\nWhat is blue but smells like red paint?\\pau=1400\\Blue paint!\n&&RestPose', "&&Explain\nIf two's company and three's a crowd, what's four and five? \\pau=1400\\Nine!\n&&RestPose", "&&Explain\nHow do you keep a computer user in suspense?\\pau=1400\\I'll tell you tomorrow!\n&&RestPose", '&&Explain\nDid you hear about the two antennas that got married? \\pau=1400\\The wedding was long but the reception was great!\n&&RestPose', '&&Explain\nWhat do you do when you break your toe? \\pau=1400\\Call a toe truck!\n&&RestPose', "&&Explain\nWhy does a chicken coop only have 2 doors? \\pau=1400\\If it had 4 doors, we'd have to call it a chicken sedan!\n&&RestPose", '&&Explain\nDid you hear about the man who sat up all night trying to work out where the sun went when it went down?\\pau=1400\\It finally dawned on \\emp\\him!\n&&RestPose', "&&Explain\nWhat is smaller than an insect's mouth?\\pau=1400\\Anything it eats!\n&&RestPose", '&&Explain\nWhat does a ship weigh just before it sails?\\pau=1400\\Its anchors!\n&&RestPose', '&&Explain\nWhat is neither flesh nor blood, but has four fingers and a thumb?\\pau=1400\\A glove!\n&&RestPose', '&&Explain\nWhy was the strawberry worried?\\pau=1400\\Because its father was in a jam!\n&&RestPose', '&&Explain\nWhat can be right but never wrong?\\pau=1400\\An angle!\n&&RestPose', "&&Explain\nWhat's the cheapest way to see the world?\\pau=1400\\Buy an atlas!\n&&RestPose", '&&Explain\nWhat wears shoes but has no feet?\\pau=1400\\The pavement!\n&&RestPose', '&&Explain\nWhat do you get when you cross a chicken with a clock?\\pau=1400\\Chick tock..chick tock..chick tock!\n&&RestPose', '&&Explain\nA man walks into a Doctor’s office.\\pau=200\\ He has a carrot in his left ear, \\pau=200\\and a banana in his right ear. \\pit=220\\ "What\'s the \\emp\\matter with me?"  \\pit=150\\he asked.\\pit=70\\\\pau=1200\\ \\spd=170\\ "You\'re not \\emp\\eating properly."\\pit=150\\ replied the Doctor.\n&&RestPose', '&&Explain\nAn elephant was walking through the jungle when he happened upon a mouse. \\pau=1200\\The elephant said to the mouse,\\pit=60\\ "Gee, you\'re small, aren\'t you."\\pit=150\\ The mouse replied\\spd=120\\\\pit=250\\ "Yes..I\'ve been sick!"\n&&RestPose', '&&Explain\nWhat do you call a sleeping bull?\\pau=1500\\A bull-dozer!\n&&RestPose', '&&Explain\nWhat do ghosts like to ride on in an amusement park?\\pau=1500\\A \\emp\\roller-ghoster!\n&&RestPose', '&&Explain\nAt what time of year is it best to use a trampoline?\\pau=1500\\In the \\emp\\springtime!\n&&RestPose', '&&Explain\nWhat would be the difference between a counterfeit ten dollar bill and a crazy rabbit?\\pau=1500\\One is bad money, and the other is a \\emp\\mad bunny!\n&&RestPose', '&&Explain\nWhat did the large insect say to the small insect?\\pau=1500\\\\emp\\Stop \\emp\\bugging me!\n&&RestPose', '&&Explain\nWhat is the favorite thing for frogs to sit on?\\pau=1500\\\\emp\\Toadstools!\n&&RestPose', '&&Explain\nWhat is the most selfish pig on the highway called?\\pau=1500\\A \\emp\\road hog!\n&&RestPose', '&&Explain\nWhat did the tire jack say to the car?\\pau=1500\\Can I give \\emp\\you a lift!\n&&RestPose', '&&Explain\nWhat did the father buffalo say when his son went to school?\\pau=1500\\Bi-son!\n&&RestPose', '&&Explain\nWhat is the favorite course of snakes who go to school?\\pau=1500\\Hisssss-tory!\n&&RestPose', '&&Explain\nWhat song do you usually hear bees singing?\\pau=1500\\\\emp\\Stinging in the rain!\n&&RestPose', "&&Explain\nWhat did one pig say to the other pig?\\pau=1500\\Let's be \\emp\\pen pals!\n&&RestPose", '&&Explain\nWho invented spaghetti?\\pau=1500\\It must have been someone who used \\emp\\his noodle!\n&&RestPose', "&&Explain\nWhat do they call a driver who doesn't need a car?\\pau=1500\\A screwdriver!\n&&RestPose", '&&Explain\nWhen is the best time to lose your temper?\\pau=1500\\When you have a \\emp\\bad one!\n&&RestPose', '&&Explain\nWhat kind of cow eats with its tail!\\pau=1500\\They \\emp\\all do!..Cows do not remove their tails \\emp\\to eat!\n&&RestPose', "&&Explain\nWhat did the cow say when it finished eating a bale of hay?\\pau=1500\\Well, that's the \\emp\\last straw!\n&&RestPose", '&&Explain\nWhat sits on the bottom of the sea with a lot of gold and shakes?\\pau=1500\\A \\emp\\nervous wreck!\n&&RestPose', '&&Explain\nWhat kind of house weighs the least?\\pau=1500\\A lighthouse!\n&&RestPose', '&&Explain\nWhat do you get if you cross a cocker spaniel, a poodle, and a rooster?\\pau=1500\\A cock-a-poodle-doo!\n&&RestPose', '&&Explain\nHow can you quickly double your money?\\pau=1500\\Fold it over, and put it in your pocket!\n&&RestPose', '&&Explain\nWhat is the fasted way to get rich by eating?\\pau=1500\\Eat \\emp\\fortune cookies!\n&&RestPose', '&&Explain\nHow do you make a hamburger roll?\\pau=1500\\Take it to the top of a very steep hill and give \\emp\\it a push!\n&&RestPose', "&&Explain\nHow many pairs of shoes can you put into an empty closet?\\pau=1500\\Just one! After that it isn't empty!\n&&RestPose", '&&Explain\nIs it possible to name the capital of every state in the Union in less than 15 seconds?\\pau=1500\\Yes! Washington D.C.!\n&&RestPose', '&&Explain\nWhat do frogs like to drink?\\pau=1500\\Croaka-Cola!\n&&RestPose', '&&Explain\nWhat is the favorite year for a kangaroo?\\pau=1500\\\\emp\\Leap year!\n&&RestPose', "&&Explain\nWhat is as big as an elephant, but doesn't weigh anything?\\pau=1500\\The \\emp\\shadow of an elephant!\n&&RestPose", '&&Explain\nWhat do they call a dinosaur that goes around wrecking everything?\\pau=1500\\Tyrann o saurus Wrecks!\n&&RestPose', '&&Explain\nIf you crossed a computer with an elephant, what do you think you would have?\\pau=1500\\A very \\emp\\big know-it-all!\n&&RestPose', '&&Explain\nWhat kind of party does frosty the snowman go to?\\pau=1500\\The \\emp\\snowball!\n&&RestPose', '&&Explain\nIf a ghost were to make a mistake, what would you call it?\\pau=1500\\A \\emp\\boo-boo!\n&&RestPose', '&&Explain\nHow does a farmer count his cows?\\pau=1500\\A cow-culator!\n&&RestPose', "&&Explain\nWhat did the man say when he got his bill from the electric Company?\\pau=1500\\I'm shocked!\n&&RestPose", '&&Explain\nWhat swimming stroke do babies use?\\pau=1500\\The \\emp\\crawl!\n&&RestPose', "&&Explain\nWhen someone asked the author how his business was, what did he say?\\pau=1500\\It's all \\emp\\write.\n&&RestPose", '&&Explain\nWhat is the best thing to do for a very sick wasp?\\pau=1500\\Take it to the waspital!\n&&RestPose', '&&Explain\nWhat is doughy, covered with tomato paste, and is 50 yards high?\\pau=1500\\The Leaning \\emp\\Tower of Pizza!\n&&RestPose', '&&Explain\nWhat do you get if you cross a hippopotamus with a kangaroo?\\pau=1500\\Great big holes all \\emp\\over Australia!\n&&RestPose', '&&Explain\nWhere do calves eat?\\pau=1500\\In the calf-eteria!\n&&RestPose', '&&Explain\nWhere does Frosty the Snowman keep all of his money?\\pau=1500\\In the \\emp\\snowbank!\n&&RestPose', '&&Explain\nWhere does Super man get the food he needs to make him strong?\\pau=1500\\At the \\emp\\supermarket!\n&&RestPose', '&&Explain\nWhere do you take a sick ocean liner?\\pau=1500\\To the \\emp\\dock!\n&&RestPose', '&&Explain\nWhat kind of umbrella do you carry with you on a rainy day?\\pau=1500\\A \\emp\\wet one!\n&&RestPose', '&&Explain\nWhat is the best way to fix the broken tooth of a gorilla?\\pau=1500\\With a monkey wrench!\n&&RestPose', '&&Explain\nWhat is green and goes up and down?\\pau=1500\\A \\emp\\pickle in an elevator!\n&&RestPose', '&&Explain\nWhen a pig writes a letter, what does it use?\\pau=1500\\Pen and \\emp\\oink!\n&&RestPose', '&&Explain\nWhat goes up and down but does not move?\\pau=1500\\A ladder!\n&&RestPose', '&&Explain\nWhat is the biggest building in town?\\pau=1500\\The library!  It has the \\emp\\most stories!\n&&RestPose', "&&Explain\nWhen the man stepped on a candy bar, what did he say?\\pau=1500\\I've set \\emp\\foot on Mars!\n&&RestPose", '&&Explain\nWhat do they call a crazy pickle?\\pau=1500\\A daffy-dill!\n&&RestPose', '&&Explain\nWhat is the most valuable fish in the water?\\pau=1500\\The \\emp\\goldfish!\n&&RestPose', '&&Explain\nWhat kind of table has no legs?\\pau=1500\\A \\emp\\multiplication table!\n&&RestPose', '&&Explain\nWhat do you call the most unhappy birds in the world?\\pau=1500\\Blue birds!\n&&RestPose', '&&Explain\nWhy do plumbers wear yellow suspenders?\\pau=1500\\To hold their \\emp\\pants up!\n&&RestPose', "&&Explain\nWhy do bees hum?\\pau=1500\\Because they can't remember the \\emp\\words to the song!\n&&RestPose", "&&Explain\nWhy do they always put blue clothes on baby boys and pink clothes on baby girls?\\pau=1500\\Because they can't \\emp\\dress themselves!\n&&RestPose", '&&Explain\nWhy do hurricanes travel so fast?\\pau=1500\\If they traveled slowly, we would have to call them \\emp\\slowy-canes!\n&&RestPose', '&&Explain\nWhat is the whitest part of a baseball park?\\pau=1500\\The bleachers!\n&&RestPose', '&&Explain\nWhat is the best thing for an elk with indigestion?\\pau=1500\\Elk-a-Seltzer!\n&&RestPose', '&&Explain\nWhat happens when you tell jokes about the stomach?\\pau=1500\\You get \\emp\\belly laughs!\n&&RestPose', '&&Explain\nWhat clothes do lawyers wear in court?\\pau=1500\\Lawsuits!\n&&RestPose', '&&Explain\nWhy did Jack and Jill roll down the hill?\\pau=1500\\Because they got \\emp\\tired of walking!\n&&RestPose', "&&Explain\nWhy should you never tell pigs any of your secrets?\\pau=1500\\They're \\emp\\squealers!\n&&RestPose", "&&Explain\nWhy couldn't batman go fishing?\\pau=1500\\Because Robin ate \\emp\\all the worms!\n&&RestPose", '&&Explain\nWhy did the horse cough and sneeze?\\pau=1500\\Because it had a \\emp\\little colt!\n&&RestPose', "&&Explain\nA dime and a nickel were on a table.  The nickel fell off, why didn't the dime?\\pau=1500\\\nIt had more cents!\n&&RestPose", '&&Explain\nHow did the water know it was going down the drain?\\pau=1500\\\nIt had a sinking feeling!\n&&RestPose', '&&Explain\nHow do small children travel?\\pau=1500\\\nIn mini vans!\n&&RestPose', '&&Explain\nHow many witches does it take to change a lightbulb?\\pau=1500\\\nOne, but she changes it into a toad!\n&&RestPose', '&&Explain\nHow much does it cost a pirate to get his ears pierced?\\pau=1500\\\nA buccaneer!\n&&RestPose', '&&Explain\nWhat animal talks all the time?\\pau=1500\\\nA yak!\n&&RestPose', '&&Explain\nWhat did the digital clock say to the grandfather clock?\\pau=1500\\\nLook, Pa, no hands!\n&&RestPose', "&&Explain\nWhat did the limestone say to the other?\\pau=1500\\\nDon't take me for granite!\n&&RestPose", "&&Explain\nWhat did the the old lightbulb say to the new lightbulb?\\pau=1500\\\nYou're too young to go out tonight!\n&&RestPose", '&&Explain\nWhat do donkeys send out near Christmas?\\pau=1500\\\nMule tide greetings!\n&&RestPose', '&&Explain\nWhat do you call a monkey that loves to eat potato chips?\\pau=1500\\\nA chip monk!\n&&RestPose', '&&Explain\nWhat do you get when you cross a snowman with a vampire?\\pau=1500\\\nFrost bite!\n&&RestPose', '&&Explain\nWhat does a computer do when it gets hungry?\\pau=1500\\\nEats its chips one byte at a time!\n&&RestPose', '&&Explain\nWhat fruit is always complaining?\\pau=1500\\\nA crab apple!\n&&RestPose', "&&Explain\nWhat is a fish's favorite TV show?\\pau=1500\\\nName that tuna!\n&&RestPose", "&&Explain\nWhat is a ghost's favorite ride at the fair?\\pau=1500\\\nThe roller ghoster!\n&&RestPose", '&&Explain\nWhat is green and makes holes?\\pau=1500\\\nA drill pickle!\n&&RestPose', '&&Explain\nWhat is the best way to call a tiger?\\pau=1500\\\nBy long distance!\n&&RestPose', '&&Explain\nWhat is the quietest game in the world?\\pau=1500\\\nBowling.  You can hear a pin drop!\n&&RestPose', '&&Explain\nWhat kind of birds always stick together?\\pau=1500\\\nVelcrows!\n&&RestPose', '&&Explain\nWhat kind of royalty plays golf?\\pau=1500\\\nQueen of clubs!\n&&RestPose', '&&Explain\nWhere would you learn to make ice cream?\\pau=1500\\\nSundae school!\n&&RestPose', '&&Explain\nWhich monkey can fly?\\pau=1500\\\nThe hot air baboon!\n&&RestPose', "&&Explain\nWho's never hungry at Thanksgiving dinner?\\pau=1500\\\nThe turkey, he's already stuffed!\n&&RestPose", '&&Explain\nWhy could Sir Lancelot see in the dark?\\pau=1500\\\nHe had knight vision goggles!\n&&RestPose', "&&Explain\nWhy do you go to bed at night?\\pau=1500\\\nBecause the bed won't come to you!\n&&RestPose", '&&Explain\nWhy is a river always rich?\\pau=1500\\\nIt has a bank on both sides!\n&&RestPose', '&&Explain\nWhy is the sun like a black eye?\\pau=1500\\\nThey are both shiners!\n&&RestPose', '&&Explain\nWhy is your nose in the middle of your face?\\pau=1500\\\nIts the scenter!\n&&RestPose', '&&Explain\nWhy was Cinderella thrown off the baseball team?\\pau=1500\\\nShe ran away from the ball!\n&&RestPose', "&&Explain\nWhy was the groom sad at his wedding?\\pau=1500\\\nBecause he wasn't the best man!\n&&RestPose", '&&Explain\nWhy was the librarian sad?\\pau=1500\\\nShe was getting the silent treatment!\n&&RestPose', '&&Explain\nWhich burns longer, a black candle or a white one?\\pau=1500\\Neither.. They both burn shorter!\n&&RestPose', '&&Explain\nWhat did the judge say to his wife when he came home?\\pau=1500\\It has been another trying day!\n&&RestPose', "&&Explain\nWhy did the boy do the back-stroke?\\pau=1500\\Because he didn't want to swim on a full stomach!\n&&RestPose", '&&Explain\nWhat did the bull say after his visit to the china shop?\\pau=1500\\I just had a smashing time!\n&&RestPose', '&&Explain\nWhat did the big clock hand say to the little clock hand?\\pau=1500\\"I\'ll be back in an hour!"\n&&RestPose', '&&Explain\nWhat did the calculator say to the bank teller?\\pau=1500\\"You can count on me!"\n&&RestPose', '&&Explain\nWhat did the chick say when he came out of the shell?\\pau=1500\\"What an egg-sperience!"\n&&RestPose', '&&Explain\nWhat did the baby corn say to the mother corn?\\pau=1500\\"Where’s Pop-corn"!\n&&RestPose', '&&Explain\nWhat did one angel say to the other angel?\\pau=1500\\"Halo there!"\n&&RestPose', '&&Explain\nWhat did one elevator say to the other elevator?\\pau=1500\\"I think I\'m coming down with something!"\n&&RestPose', '&&Explain\nWhat did one flea say to the other flea?\\pau=1500\\"Shall we walk or take a cat?"\n&&RestPose', '&&Explain\nWhat is a crate of ducks?\\pau=1500\\A box of quackers!\n&&RestPose', '&&Explain\nWhy are wolves like playing cards?\\pau=1500\\They both come in packs!\n&&RestPose', "&&Explain\nWhy can't you play jokes on snakes?\\pau=1500\\Because you can never pull their legs!\n&&RestPose", '&&Explain\nWhat is the definition of a caterpillar?\\pau=1500\\A worm with a fur coat!\n&&RestPose', '&&Explain\nWhat animal goes to sleep with its shoes on?\\pau=1500\\A horse!\n&&RestPose', "&&Explain\nWhy is it called the Eiffel Tower?\\pau=1500\\Because from the top, you're sure to get an eyeful!\n&&RestPose", '&&Explain\nWhat is a cow that eats grass?\\pau=1500\\A lawn mooer!\n&&RestPose', '&&Explain\nWhy did the father call two of his sons "Edward"?\\pau=1500\\Because two Eds are better than one!\n&&RestPose', '&&Explain\nWhy do some women wear curlers at night?\\pau=1500\\So they can wake up curly in the morning!\n&&RestPose', '&&Explain\nWhat do miners play in tunnels?\\pau=1500\\Mine-opoly!\n&&RestPose', '&&Explain\nWhat did the policeman have in his sandwiches?\\pau=1500\\Traffic Jam!\n&&RestPose', '&&Explain\nWhere do you take a sick dog?\\pau=1500\\To the dog-tur!\n&&RestPose', "&&Explain\nWhy didn't the banana snore?\\pau=1500\\Because it was afraid to wake up the rest of the bunch!\n&&RestPose", '&&Explain\nWhy is the sea always restless?\\pau=1500\\Because it has so many rocks in its bed!\n&&RestPose', "&&Explain\nWhy did the milkmaid sit down?\\pau=1500\\Because she couldn't stand milking!\n&&RestPose", '&&Explain\nHow do barbers get to their shops quickley?\\pau=1500\\They take short cuts!\n&&RestPose', '&&Explain\nWhat pet makes the loudest noise?\\pau=1500\\The trum-pet!\n&&RestPose', '&&Explain\nWhat tune do you sing in a car?\\pau=1500\\A car-tune!\n&&RestPose', '&&Explain\nWhat is full of holes but can hold water?\\pau=1500\\A sponge!\n&&RestPose', "&&Explain\nWhat makes the Tower of Pisa lean?\\pau=1500\\It doesn't eat much!\n&&RestPose", '&&Explain\nWhat travels faster, \\pau=1000\\heat or cold?\\pau=1500\\Heat, because you can always catch a cold!\n&&RestPose', '&&Explain\nWhat runs around a garden without moving?\\pau=1500\\A fence!\n&&RestPose', '&&Explain\nWhat animals need oiling?\\pau=1500\\Mice because they squeak!\n&&RestPose', '&&Explain\nWhat would you call a couple of banana peels!\\pau=1500\\ A pair of slippers!\n&&RestPose', '&&Explain\nHow do you know the ocean is friendly?\\pau=1500\\Because it waves!\n&&RestPose', '&&Explain\nWhich is the saddest tree?\\pau=1500\\A weeping willow!\n&&RestPose', '&&Explain\nWhat do confused chickens lay?\\pau=1500\\Scrambled eggs!\n&&RestPose', '&&Explain\nWhat do you get when you cross a big dog with a telephone?\\pau=1500\\A golden receiver!\n&&RestPose', '&&Explain\nWhat flies and yet never goes anywhere?\\pau=1500\\A flag!\n&&RestPose', "&&Explain\nWhere does a sick ship go?\\pau=1500\\To the doc's!\n&&RestPose", '&&Explain\nWhat do cats read every morning?\\pau=1500\\Mewspapers!\n&&RestPose', '&&Explain\nWhat has a big mouth but never talks?\\pau=1500\\A river!\n&&RestPose', '&&Explain\nWhat television game is most popular with fish?\\pau=1500\\Name that Tuna!\n&&RestPose', '&&Explain\nWhen do people talk turkey?\\pau=1500\\When they are gobbling their supper!\n&&RestPose', '&&Explain\nWhat has teeth but never eats?\\pau=1500\\A comb!\n&&RestPose', '&&Explain\nWhere does a sick horse go?\\pau=1500\\To the horse-pital!\n&&RestPose', '&&Explain\nWhat grows larger the more you take it away?\\pau=1500\\A hole!\n&&RestPose', '&&Explain\nWhat did the mother bee say to the naught baby bee?\\pau=1500\\Just beehive yourself!\n&&RestPose', '&&Explain\nWhat do you get if a sheep studies Karate?\\pau=1500\\A lamb chop!\n&&RestPose', '&&Explain\nWhy did the reporter keep a ruler on his newspaper?\\pau=1500\\To get his story straight!\n&&RestPose', '&&Explain\nWhat did the electric robot say to its mother?\\pau=1500\\I love you watts and watts!\n&&RestPose', '&&Explain\nWhy is it always cool in a sports stadium?\\pau=1500\\Because there is a fan in every seat!\n&&RestPose', '&&Explain\nWhy is an empty purse always the same?\\pau=1500\\Because there is never any change in it!\n&&RestPose', '&&Explain\nWhat do you lose every time you stand up?\\pau=1500\\Your lap!\n&&RestPose', '&&Explain\nWhat do you call a happy lassie?\\pau=1500\\A \\emp\\jolly collie!\n&&RestPose', '&&Explain\nWhere was the Declaration of Independence signed?\\pau=1500\\At the bottom!\n&&RestPose', '&&Explain\nWhy did the rocket lose its job?\\pau=1500\\It \\emp\\got fired!\n&&RestPose', "&&Explain\nWhy do birds always fly south?\\pau=1500\\Because it's too far to walk!\n&&RestPose", '&&Explain\nWhat is the best way to make a fire with two sticks?\\pau=1500\\Be sure  \\emp\\one of the sticks is a match!\n&&RestPose', '&&Explain\nWhat goes up when the rain comes down?\\pau=1500\\Umbrellas!\n&&RestPose', '&&Explain\nWhat is an important aid in good grooming for pet mice?\\pau=1500\\Mouse-wash!\n&&RestPose', '&&Explain\nWhat is an eagle after he is five days old?\\pau=1500\\\\emp\\Six days old!\n&&RestPose', '&&Explain\nWhat beans do not grow in a garden?\\pau=1500\\ \\emp\\Jelly beans!\n&&RestPose', '&&Explain\nWhere does a sheep get his hair cut?\\pau=1500\\At the baa-baa shop!\n&&RestPose', '&&Explain\nWhat are the strongest creatures in the ocean?\\pau=1500\\Mussels!\n&&RestPose', '&&Explain\nWhere do computers keep their valuables?\\pau=1500\\In  \\emp\\data banks!\n&&RestPose', '&&Explain\nHow many balls of string would it take to reach Mars?\\pau=1500\\Just one! But it would have to be a very big one!\n&&RestPose', '&&Explain\nIf all cars in a country were white, what would they have?\\pau=1500\\A white-car-nation!\n&&RestPose', '&&Explain\nWhy does a hen lay eggs?\\pau=1500\\If she let them drop, they would break!\n&&RestPose', '&&Explain\nWhat do they call cabs lined up at Texas airports?\\pau=1500\\The yellow-rows of taxis!\n&&RestPose', '&&Explain\nWhich pets always lie around the house?\\pau=1500\\Carpets!\n&&RestPose', '&&Explain\nWhat can make more noise than a kitten stuck in a tree?\\pau=1500\\Two kittens stuck in a tree!\n&&RestPose', '&&Explain\nWhy does a piglet eat so much?\\pau=1500\\To make a hog out of himself!\n&&RestPose', '&&Explain\nWhat kind of shoes never go out of style at gas stations?\\pau=1500\\Pumps!\n&&RestPose', '&&Explain\nWhat do you call a man who is always wiring for money?\\pau=1500\\An electrician!\n&&RestPose', '&&Explain\nWhy does a stork stand on one leg?\\pau=1500\\Because if he took both legs off the ground, he would \\emp\\ fall down!\n&&RestPose', '&&Explain\nName six things that have milk in them.\\pau=1500\\Butter, cheese, ice cream, and three cows!\n&&RestPose', '&&Explain\nHow do they put milk in the Milky Way?\\pau=1500\\With the \\emp\\ Big Dipper!\n&&RestPose', '&&Explain\nWhat does a cow-girl say at the end of a long ride?\\pau=1500\\Whoa!\n&&RestPose', '&&Explain\nWhat kind of weather pleases a pet duck?\\pau=1500\\Fowl weather!\n&&RestPose', '&&Explain\nWhat does Santa say when he works in his garden?\\pau=1500\\Hoe, Hoe, Hoe!\n&&RestPose', '&&Explain\nWhat do birds say on Halloween?\\pau=1500\\Trick or tweet!\n&&RestPose', '&&Explain\nWhy did the dog keep chasing his tail?\\pau=1500\\He wanted to see if he could make  \\emp\\ends meet!\n&&RestPose', '&&Explain\nWhat do they call a turtle who always tells on his friends?\\pau=1500\\A turtle-tale!\n&&RestPose', '&&Explain\nWhat kind of dog should you bite?\\pau=1500\\A hot dog!\n&&RestPose', '&&Explain\nHow are dogs and trees alike?\\pau=1500\\One barks, and the other has bark!\n&&RestPose', "&&Explain\nWhat has the head of a cat, the tail of a cat, and the ways of a cat, but isn't a cat?\\pau=1500\\A kitten!\n&&RestPose", '&&Explain\nHow do you tell an elephant from a banana?\\pau=1500\\A banana is yellow!\n&&RestPose', "&&Explain\nWhat three keys won't open doors?\\pau=1500\\Monkeys, donkeys, and turkeys!\n&&RestPose", "&&Explain\nWhat is always coming but never arrives?\\pau=1500\\Tomorrow! When it actually arrives, it's today!\n&&RestPose", '&&Explain\nHow many letters are there in the alphabet?\\pau=1500\\Eleven:..t-h-e-a-l-p-h-a-b-e-t!\n&&RestPose', '&&Explain\nWhat is the difference between an old penny and a new nickel?\\pau=1500\\Four cents!\n&&RestPose', '&&Explain\nWhat looks like an elephant and flies?\\pau=1500\\A flying elephant!\n&&RestPose', '&&Explain\nWhat is the very last thing you take-off when you go to bed?\\pau=1500\\Your feet off the floor!\n&&RestPose', "&&Explain\nWhat's the difference between an elephant and a mouse?\\pau=1500\\About five thousand pounds!\n&&RestPose", '&&Explain\nWhat does a worm do in a cornfield?\\pau=1500\\He goes in one ear and out the other!\n&&RestPose', '&&Explain\nWhat do a clock and a river have in common?\\pau=1500\\Neither will run without winding!\n&&RestPose', '&&Explain\nWhat word is always pronounced wrong?\\pau=1500\\"Wrong"!\n&&RestPose', '&&Explain\nWhat has an eye but sees nothing?\\pau=1500\\A needle!\n&&RestPose', '&&Explain\nWhat does the wisest person overlook?\\pau=1500\\His nose!\n&&RestPose', '&&Explain\nWhy is a dentist unhappy at work?\\pau=1500\\Because he is always looking down in the mouth!\n&&RestPose', '&&Explain\nWhich American President wore the largest hat?\\pau=1500\\The one with the biggest head!\n&&RestPose', '&&Explain\nWhat is the definition of a volcano?\\pau=1500\\A mountain with hiccups!\n&&RestPose', '&&Explain\nWhat question can never be answered by "yes"?\\pau=1500\\Are you asleep?\n&&RestPose', '&&Explain\nWhat do you call elephants who ride on trains?\\pau=1500\\Passengers!\n&&RestPose', '&&Explain\nWhat letter cannot be found in the alphabet?\\pau=1500\\The one the postman delivers!\n&&RestPose', '&&Explain\nWhat has eighteen legs and catches flies?\\pau=1500\\A baseball team!\n&&RestPose', '&&Explain\nWhat must you keep after giving it to someone else?\\pau=1500\\Your word!\n&&RestPose', '&&Explain\nHow can you tell when an elephant is getting ready to charge?\\pau=1500\\He takes out his credit card!\n&&RestPose', '&&Explain\nWhat do you call a rabbit with lots of fleas?\\pau=1500\\Bugs Bunny!\n&&RestPose', '&&Explain\nWhat begins with E and ends with E and has a letter in between?\\pau=1500\\An envelope!\n&&RestPose', '&&Explain\nWhat runs up to your house but never goes in?\\pau=1500\\The sidewalk!\n&&RestPose', '&&Explain\nWhere am I when the lights go out?\\pau=1500\\In the dark!\n&&RestPose', '&&Explain\nWhat do you call a man who shaves ten times a day?\\pau=1500\\A barber!\n&&RestPose', '&&Explain\nWhat is the best month for a parade?\\pau=1500\\March!\n&&RestPose', '&&Explain\nWhy did the mama flea look so sad?\\pau=1500\\Because all her children were going to the dogs!\n&&RestPose', "&&Explain\nWhy does it seem like ants are very smart?\\pau=1500\\Because they always seem to know when we're having a picnic!\n&&RestPose", "&&Explain\nWhen can you take your pet rabbit to a dance?\\pau=1500\\When it's a \\emp\\ bunny hop!\n&&RestPose", '&&Explain\nWhat part of a fish weighs the most?\\pau=1500\\The scales!\n&&RestPose', '&&Explain\nWhat is the difference between a cat and a comma?\\pau=1500\\One means.."pause at the end of a clause"..and the other means "claws at the end of paws!"\n&&RestPose', "&&Explain\nDo you know how to sculpt a horse?\\pau=1500\\Just take a big block of marble and chip away anything that doesn't look like a horse!\n&&RestPose", '&&Explain\nWhat do you call a duck that makes straight "A"s on his report card?\\pau=1500\\A wise quacker!\n&&RestPose', '&&Explain\nWhy does a giraffe eat so little?\\pau=1500\\Because a little goes a long way!\n&&RestPose', '&&Explain\nHow do most fisherman catch fish?\\pau=1500\\By the Tale!\n&&RestPose', "&&Explain\nWhy do elephants need trunks?\\pau=1500\\Because they don't have  \\emp\\glove compartments!\n&&RestPose", '&&Explain\nWhy did the boy cut a hole in the umbrella?\\pau=1500\\Because he wanted to be able to tell when it  \\emp\\stopped raining!\n&&RestPose', '&&Explain\nWhy did the girl separate the thread from the needle?\\pau=1500\\Because the needle had something in its eye!\n&&RestPose', '&&Explain\nWhy did the boy wear a wet shirt all day long?\\pau=1500\\Because the label said, "Wash and wear"!\n&&RestPose', '&&Explain\nWhy did the boy spend two weeks in a revolving door?\\pau=1500\\Because he was looking for the doorknob!\n&&RestPose', '&&Explain\nWhy did the boy give cough syrup to the pony?\\pau=1500\\Because someone told him it was a little horse!\n&&RestPose', '&&Explain\nWhy did the boy pitch a tent on top of the stove?\\pau=1500\\Because he wanted a home on the range!\n&&RestPose', '&&Explain\nWhat goes up but never comes down?\\pau=1500\\Your Age!\n&&RestPose', '&&Explain\nWhat animal is it that walks first on four legs, later on two legs, and in old age on three?\\pau=2000\\A person!..he crawls, he walks, and then uses a cane!\n&&RestPose', '&&Explain\nHow much dirt can you take out of a hole two-feet square, and two-feet deep?\\pau=2000\\None..The dirt has already been removed from a hole!\n&&RestPose', '&&Explain\nHow many lions can you put into an empty cage?\\pau=2000\\One!..then it would  \\emp\\no longer be empty!\n&&RestPose', '&&Explain\nWhen does Thursday come before Wednesday?\\pau=2000\\Only in the dictionary!\n&&RestPose', '&&Explain\nHow many times can you subtract 2 from 21?\\pau=2000\\Only once!..From then on, you would be subracting from 19, 17, then from 15, and so forth.\n&&RestPose', '&&Explain\nWhen you take two apples from three apples, what do you have?\\pau=2000\\You have the two apples that you took!\n&&RestPose', '&&Explain\nWhat can run but cannot walk?\\pau=2000\\Water!\n&&RestPose', '&&Explain\nHow can you drop an egg three feet without breaking it?\\pau=2000\\Hold the egg four feet from the floor, let it drop three feet and then catch it!\n&&RestPose', '&&Explain\nI am something that is filled every morning and emptied every night, except once a year when I am filled at night and emptied in the morning..What am I?\\pau=2000\\A Christmas stocking!\n&&RestPose', '&&Explain\nWhat stays hot even if you put it in the refrigerator?\\pau=2000\\A pepper!\n&&RestPose', '&&Explain\nWhat is a bee with a low buzz?\\pau=2000\\A mumble bee!\n&&RestPose', '&&Explain\nWhat insect is religious?\\pau=1500\\A praying mantis!\n&&RestPose', '&&Explain\nWhat did the dog get when he swallowed the watch?\\pau=1500\\He got a lot of ticks!\n&&RestPose', '&&Explain\nWhat is the healthiest kind of water?\\pau=1500\\Well water!\n&&RestPose', "&&Explain\nWhat did the boy say when he wanted to sell his bicycle?\\pau=1500\\I think I'll ped-dle my bike!\n&&RestPose", '&&Explain\nWhy did the whale cross the ocean?\\pau=1500\\To get to the other tide!\n&&RestPose', '&&Explain\nWhy did the workers at the government mint go on strike?\\pau=1500\\They wanted to make less money!\n&&RestPose', '&&Explain\nWhy should a fisherman always be wealthy?\\pau=1500\\Because his business is net profit!\n&&RestPose', '&&Explain\nHow did the big mountain know that the little mountain was fibbing?\\pau=1500\\Because it was only a bluff!\n&&RestPose', '&&Explain\nWhat did the dog say when he sat on the sandpaper?\\pau=1500\\Ruff, Ruff!\n&&RestPose', '&&Explain\nWhat goes through a door but never goes in or out?\\pau=2000\\A keyhole!\n&&RestPose', '&&Explain\nWhat time of day can you spell backward and forward?\\pau=1500\\Noon!\n&&RestPose', '&&Explain\nWhat kind of policeman enjoys his work most?\\pau=1500\\A traffic policeman, because he whistles while he works!\n&&RestPose', '&&Explain\nWhat has four legs and feathers?\\pau=1500\\A featherbed!\n&&RestPose', '&&Explain\nWhat do mice do in the daytime?\\pau=1500\\Mousework!\n&&RestPose', "&&Explain\nWhat is the difference between a tuna fish and a piano?\\pau=1500\\You can't tune a fish!\n&&RestPose", '&&Explain\nWhat did one pile of sand say to the other pile?\\pau=1500\\Watcha dune tonight!\n&&RestPose', '&&Explain\nWhy should opera singers be good sailors?\\pau=1500\\They know how to handle high "C"\'s!\n&&RestPose', "&&Explain\nWhy don't robots panic?\\pau=1500\\Because they have nerves of steel!\n&&RestPose", '&&Explain\nWhy did the old farmer run a steam roller over his potato field?\\pau=1500\\He wanted to raise mashed potatoes!\n&&RestPose', '&&Explain\nWhy did the spy spray his room with insect repellent?\\pau=1500\\Because he thought it was bugged!\n&&RestPose', '&&Explain\nWhy did miss muffet need a road-map?\\pau=1500\\Because she lost  \\emp\\her whey!\n&&RestPose', "&&Explain\nWhy does the Statue of Liberty stand in New York?\\pau=1500\\Because it  \\emp\\can't sit!\n&&RestPose", "&&Explain\nWhy is a pencil like a riddle?\\pau=1500\\It's no good  \\emp\\without a point!\n&&RestPose", "&&Explain\nWhat did the raisin say to the coffee cake?\\pau=1500\\I feel as if I'm rolling in dough!\n&&RestPose", '&&Explain\nWhat did the cow say to the pig?\\pau=1500\\You are such a boar!\n&&RestPose', '&&Explain\nWhat do you call a train carrying a load of apples and bananas?\\pau=1500\\A tooty fruity!\n&&RestPose', '&&Explain\nWhat does the sun do when it sets?\\pau=1500\\Makes a night of it!\n&&RestPose', '&&Explain\nHow do you make a pair of shoes?\\pau=1500\\Put two shoes together!\n&&RestPose', '&&Explain\nWhat did the mother say when she learned that her son had eaten 37 pancakes at one sitting?\\pau=1500\\How waffle!\n&&RestPose', '&&Explain\nWhat did King Arthur wear to bed?\\pau=1500\\A knight gown!\n&&RestPose', '&&Explain\nWhat is commonly called brain food?\\pau=1500\\ \\emp\\Noodle soup!\n&&RestPose', "&&Explain\nHow long should an animal's legs be?\\pau=1500\\Long enough to reach the ground!\n&&RestPose", '&&Explain\nHow can you have bread if you are on a liquid diet?\\pau=1500\\Drink a toast!\n&&RestPose', '&&Explain\nHow can you keep fish from smelling?\\pau=1500\\Plug their noses!\n&&RestPose', '&&Explain\nWhen is an elevator not an elevator?\\pau=1500\\When it is going down!\n&&RestPose', '&&Explain\nWhen is an operation funny?\\pau=1500\\When it leaves the patient in stitches!\n&&RestPose', '&&Explain\nWhen did the fly fly?\\pau=1500\\When the spider \\emp\\ spied her!\n&&RestPose', '&&Explain\nWhen things go wrong, what can you always count on?\\pau=1500\\Your fingers!\n&&RestPose', '&&Explain\nWhen is a shoemaker like a doctor?\\pau=1500\\When he is heeling!\n&&RestPose', "&&Explain\nWhen do you charge a new battery?\\pau=1500\\When you can't pay cash!\n&&RestPose", '&&Explain\nWhen is a wall like a fish?\\pau=1500\\When it is scaled!\n&&RestPose', "&&Explain\nWhen is longhand quicker than shorthand?\\pau=1500\\When it's on a clock!\n&&RestPose", '&&Explain\nWhat runs around town all day and lies down all night with its tongue hanging out?\\pau=2000\\Your shoe!\n&&RestPose', '&&Explain\nWhat does a farmer grow if he works hard?\\pau=1500\\Tired!\n&&RestPose', '&&Explain\nWhat do you call the person who mows the grass of a baseball field?\\pau=1500\\A diamond cutter!\n&&RestPose', '&&Explain\nWhat did the eye say to the ice cube?\\pau=1500\\Icy you!\n&&RestPose', '&&Explain\nWhat do snakes do after they have a fight?\\pau=1500\\They hiss and make up!\n&&RestPose', '&&Explain\nWhat falls all day, yet never gets hurt?\\pau=2000\\A waterfall!\n&&RestPose', "&&Explain\nWhat's the funniest animal in the world?\\pau=2000\\A stand-up chameleon!\n&&RestPose", '&&Explain\nHow do you keep a dog from barking in the back of the car?\\pau=1500\\Put him in the  \\emp\\front seat!\n&&RestPose', '&&Explain\nIf a head of cabbage, a tomato, and a tap ran a race, who would win?\\pau=2000\\The cabbage would be ahead, the tomato would ketchup, and the tap would still be running!\n&&RestPose', '&&Explain\nWhat kind of pigeon sits a lot?\\pau=1500\\A  \\emp\\stool pigeon!\n&&RestPose', '&&Explain\nWhat fish can pelicans eat?\\pau=1500\\Anything that fits the bill!\n&&RestPose', "&&Explain\nWhat nail doesn't a carpenter like to hit?\\pau=1500\\His fingernail!\n&&RestPose", '&&Explain\nWhat do people do who work in a clock factory?\\pau=1500\\They make faces  \\emp\\all day!\n&&RestPose', '&&Explain\nWhat kind of spy hangs around a department store?\\pau=1500\\A  \\emp\\counter-spy!\n&&RestPose', '&&Explain\nThe more there is of it, the less you see it..What is it?\\pau=2000\\Darkness!\n&&RestPose', '&&Explain\nHow do two kangaroos live?\\pau=1500\\ \\emp\\Hoppily ever after!\n&&RestPose', '&&Explain\nWhat is the definition of a well balanced meal?\\pau=1500\\A hamburger in each hand!\n&&RestPose', '&&Explain\nWhat did the dirt say to the rain?\\pau=1500\\If you keep this up, my name will be mud!\n&&RestPose', '&&Explain\nWhat state is round at both ends and high in the middle?\\pau=1500\\Ohio!\n&&RestPose', '&&Explain\nWhat did the impatient stag say to its daughter?\\pau=1500\\ \\emp\\Hurry up deer!\n&&RestPose', '&&Explain\nWhat can be held without ever being touched?\\pau=2000\\A conversation!\n&&RestPose', '&&Explain\nWhat do you call a bee born in May?\\pau=1500\\A maybe!\n&&RestPose', '&&Explain\nWhy does batman brush with toothpaste?\\pau=1500\\To prevent bat breath!\n&&RestPose', '&&Explain\nWhy was the cowboy a lot of laughs?\\pau=1500\\He was always horse-ing around!\n&&RestPose', '&&Explain\nWhy is the letter "A" like a flower?\\pau=1500\\Because a bee comes after it!\n&&RestPose', '&&Explain\nWhat is the happiest state?\\pau=1500\\Merryland!\n&&RestPose', '&&Explain\nWhere do you find flying rabbits?\\pau=1500\\In the \\emp\\ hare force!\n&&RestPose', '&&Explain\nWhere do cars get the most flat tires?\\pau=1500\\Where there are forks in the road!\n&&RestPose', "&&Explain\nWhat did one potato chip say to the other potato chip?\\pau=1500\\Let's go for a dip!\n&&RestPose", '&&Explain\nWhat did the skunk say when the wind changed?\\pau=1500\\It all comes back to me now!\n&&RestPose', '&&Explain\nWhat bow can never be tied?\\pau=1500\\A rainbow!\n&&RestPose', '&&Explain\nWhat fish is used by a fencer?\\pau=1500\\A swordfish!\n&&RestPose', '&&Explain\nWhat rises and waves all day?\\pau=1500\\A flag!\n&&RestPose', '&&Explain\nWhat do you get when you cross a lemon and a dollar bill?\\pau=1500\\Sour-dough!\n&&RestPose', '&&Explain\nIf a pencil and a piece of paper had a race, which one would win?\\pau=1500\\The pencil, because the paper would always remain stationery!\n&&RestPose', '&&Explain\nIf an egg came floating down the Ohio River, where did it come from?\\pau=1500\\From a hen!\n&&RestPose', "&&Explain\nIf you found a hundred-dollar bill in your coat pocket, what would you have?\\pau=1500\\Someone else's coat!\n&&RestPose", '&&Explain\nWhat is the difference between a hunting dog and a locomotive?\\pau=1500\\One is trained to run, the other runs a train!\n&&RestPose', '&&Explain\nWhat is it that passes in front of the sun yet casts no shadow?\\pau=2000\\The wind!\n&&RestPose', '&&Explain\nWhat is it that is very dark yet has done most to enlighten the world?\\pau=2000\\Ink!\n&&RestPose', "&&Explain\nWhat's the best place to look for a helping hand?\\pau=1500\\At the end of your arm!\n&&RestPose", '&&Explain\nHow do you make soup gold?\\pau=1500\\You put in 14 carrots!\n&&RestPose', '&&Explain\nHow do you get water in watermelons?\\pau=1500\\You plant them in the spring!\n&&RestPose', '&&Explain\nHow do fish go into business?\\pau=1500\\They start on a small scale!\n&&RestPose', '&&Explain\nWhy should a spider make a good outfielder?\\pau=1500\\Because it is always catching flies!\n&&RestPose', '&&Explain\nWhy were the bees on strike?\\pau=1500\\They wanted shorter flowers and more honey!\n&&RestPose', '&&Explain\nWhy does a giraffe have such a long neck?\\pau=1500\\Because his head is so far away from his body!\n&&RestPose', "&&Explain\nWhat do you drop when you use it and take back when you don't?\\pau=1500\\An anchor!\n&&RestPose", '&&Explain\nWhat happens when a chimney gets angry?\\pau=1500\\It blows its stack!\n&&RestPose', '&&Explain\nWhat is the rudist bird?\\pau=1500\\The mockingbird!\n&&RestPose', '&&Explain\nWhat school do you have to drop out of before you can graduate?\\pau=1500\\ \\emp\\Parachute school!\n&&RestPose', "&&Explain\nWhat's grey and stamps out jungle fires?\\pau=1500\\Smokey the Elephant!\n&&RestPose", '&&Explain\nWhy are elephants so wrinkled?\\pau=1500\\Did you  \\emp\\ever try to iron one?\n&&RestPose', '&&Explain\nWhich bird is always out of breath?\\pau=1500\\A Puffin!\n&&RestPose', "&&Explain\nWhat do you call someone who is always telling you about the problems you'll be having in the future?\\pau=1500\\A misfortune-teller!\n&&RestPose", '&&Explain\nWhat do you get when you cross a frog with a chair?\\pau=1500\\A toadstool!\n&&RestPose', '&&Explain\nWhat do you get when you cross a rooster with a bell?\\pau=1500\\An alarm cluck!\n&&RestPose', '&&Explain\nWhat do you get when you cross a porcupine with a gorilla?\\pau=1500\\Any seat you want on the school bus!\n&&RestPose', '&&Explain\nWhat do you get when you cross a cactus with a porcupine?\\pau=1500\\Sore hands!\n&&RestPose', '&&Explain\nWhat to you get when you cross a lion with a peacock?\\pau=1500\\A dandelion!\n&&RestPose', '&&Explain\nWhat did everyone say when the science teacher crossed a computer with a skunk?\\pau=1500\\CPU!\n&&RestPose', '&&Explain\nHow do you divide thirteen apples among nineteen people?\\pau=1500\\Make apple-sauce!\n&&RestPose', '&&Explain\nHow did the first American barbers arrive?\\pau=1500\\On \\emp\\ clipper ships!\n&&RestPose', '&&Explain\nWhat travels around the earth without using a single drop of fuel?\\pau=1500\\The moon!\n&&RestPose', '&&Explain\nWhat are the four seasons of the year?\\pau=1500\\Football, basketball, baseball, and soccer!\n&&RestPose', '&&Explain\nWho can speak in all languages?\\pau=1500\\An echo!\n&&RestPose', "&&Explain\nWhat are the three most used words in school?\\pau=1500\\I don't know!\n&&RestPose", '&&Explain\nWhat did the teacher say when she spilled the rubber cement?\\pau=1500\\This is a  \\emp\\sticky situation!\n&&RestPose', '&&Explain\nWhat is the difference between an engineer and a school teacher?\\pau=1500\\One minds the train...the other trains the mind!\n&&RestPose', '&&Explain\nWhat word has the most letters in it?\\pau=1500\\Mailbox!\n&&RestPose', '&&Explain\nWhat is the smallest room known to man?\\pau=1500\\The mushroom!\n&&RestPose', '&&Explain\nWhat is big and blue and eats rocks?\\pau=1500\\A big blue \\emp\\ rock eater!\n&&RestPose', '&&Explain\nWhat did Frankenstein say when the electricity went off?\\pau=1500\\AC come..AC go!\n&&RestPose', '&&Explain\nWhy do elephants have flat feet?\\pau=1500\\From jumping out of trees!\n&&RestPose', '&&Explain\nWhat happens to a black cow when it stands out in the rain?\\pau=1500\\It gets wet!\n&&RestPose', '&&Explain\nWhen do horses have sixteen feet?\\pau=1500\\When there are four horses!\n&&RestPose', "&&Explain\nWhy did the elephant sit on a marshmellow?\\pau=1500\\So he wouldn't fall into the  \\emp\\hot chocolate!\n&&RestPose"), 'thought': ('&&Explain\nDid you know that it is estimated that millions of trees in the world are accidentally planted by squirrels who bury nuts and then forget where they hid them! \\pau=1000\\ I hide all of \\emp\\ my food in my tummy!\n&&RestPose', '&&Explain\nDid you know that of all the words in the English language, the word \\emp\\set has the most definitions! \\pau=750\\ How many can \\emp\\you think of?\n&&RestPose', '&&Explain\nDid you know that the sun is 330,000 times larger than the earth! \\pau=750\\ Sun dried banana chips are my \\emp\\favorite!\n&&RestPose', "&&Explain\nDid you know that there are more than 50,000 earthquakes throughout the world every year!\\pau=1500\\ That's a whole lot of shaken \\emp\\goin' on!\n&&RestPose", '&&Explain\nDid you know that dogs and cats, like humans, are either right or left handed... or is that \\emp\\pawed!\n&&RestPose', '&&Explain\nDid you know that the opposite sides of a dice cube always add up to seven!\\pau=1000\\ Seven is \\emp\\my lucky number!\n&&RestPose', "&&Explain\nDid you know that nose prints are used to identify dogs, just like humans use fingerprints! \\pau=1200\\ \\emp\\I use my \\emp\\driver's license...\n&&RestPose", "&&Explain\nDid you know that bulls are colorblind, therefore will usually charge at a matador's waving cape no matter what color it is\\pau=500\\ be it red \\pau=500\\or neon yellow! \\pau=1000\\ That reminds me of a joke I heard...Do you know how to stop a bull from charging? \\pau=1500\\ Take away his \\emp\\credit card!\n&&RestPose", '&&Explain\nDid you know that apples are more efficient than caffeine in keeping people awake in the mornings! \\pau=1500\\ How do you like \\emp\\them apples?\n&&RestPose', '&&Explain\nDid you know that smelling bananas or green apples can help you lose weight! \\pau=1250\\ Just\\emp\\Smelling! \\pau=500\\\\emp\\Not eating.\n&&RestPose', "&&Explain\nDid you know that the average ice berg weighs 20,000,000 tons!\nWow! That's a lot of cold water!\n&&RestPose", '&&Explain\nDid you know that a lump of pure gold the size of a matchbox can be flattened into a sheet the size of a tennis court. \\pau=1200\\ I want \\emp\\ that sheet for \\emp\\my bed!\n&&RestPose', '&&Explain\nDid you know that after eating, a housefly regurgitates its food and then eats it again! \\pau=1200\\ It tastes \\emp\\so nice... he eats it twice!\n&&RestPose', '&&Explain\nDid you know that most lipstick contains fish scales! \\pau=1500\\ "Ooooooooooo....fihihihihsh \\pau=200\\ lihihihihips.\n&&RestPose', '&&Explain\nDid you know that one ragweed plant can release as many as one billion grains of pollen! \\pau=1500\\ Ahhahh \\emp\\Chew..surprised?\n&&RestPose', "&&Explain\nDid you know that the first product to have a bar code was Wrigley's gum! \\pau=1250\\ I wonder if the bar code disappears when you chew it!\n&&RestPose", '&&Explain\nDid you know that no piece of square dry paper can be folded more than 7 times in half!\n&&RestPose', '&&Explain\nDid you know that a group of geese on the ground is a gaggle, a group of geese in the air is a skein! \\pau=1200\\And a group of geese in your \\emp\\living room is \\emp\\annoying!\n&&RestPose', "&&Explain\nDid you know that Donald Duck comics were once banned from Finland because he doesn't wear pants! \\pau=1250\\ I find pants \\emp\\very restrictive!\n&&RestPose", '&&Explain\nDid you know that there are more than 10 million bricks in the Empire State Building! \\pau=1200\\ That matches the number of bricks in Madison Square Garden during basketball season! \\pau=800\\ Just \\emp\\kidding Knick fans..\n&&RestPose', '&&Explain\nDid you know that if you counted 24 hours a day, it would take 31,688 years to reach one trillion! \\pau=1250\\ Did you know if you counted 24 hours a day, it would take about \\emp\\one day to reach \\emp\\insanity?\n&&RestPose', '&&Explain\nDid you know that a crocodile always grows new teeth to replace the old teeth! \\pau=1200\\ \\emp\\That sounds like a crock to me!\n&&RestPose', '&&Explain\nDid you know that clinophobia is the fear of beds!\n&&RestPose', '&&Explain\nDid you know that a \'jiffy\' is an actual unit of time for 1 100th of a second! \\pau=1200\\ By the time you finish saying, "I\'ll \\emp\\do it in a jiffy"... its already \\emp\\too \\emp\\late!\n&&RestPose', '&&Explain\nDid you know that porcupines float in water! \\pau=1200\\ Do you know how to make a porcupine float? \\pau=1500\\ By pouring root \\emp\\beer on him!\n&&RestPose', '&&Explain\nDid you know that Pinocchio is Italian for "pine head"!\n&&RestPose', '&&Explain\nDid you know that the sentence "The quick brown fox jumps over the lazy dog." uses every letter of the alphabet! \\pau=1200\\ Can you think of another?\n&&RestPose', '&&Explain\nDid you know that the average life span of a major league baseball is 5 to 7 pitches! \\pau=1200\\ Always bring your glove to the ball park, and watch \\emp\\out for the foul balls!\n&&RestPose', '&&Explain\nDid you know that the only 15 letter word that can be spelled without repeating a letter is "uncopyrightable"! \\pau=1200\\ I know a \\emp\\thirteen letter word..\\emp\\"copyrightable"!\n&&RestPose', '&&Explain\nDid you know that the longest recorded flight of a chicken is 13 seconds!\n&&RestPose', "&&Explain\nDid you know that the world's termites outweigh the world's humans 10 to 1! \\pau=1200\\ That should make all you pest control folks \\emp\\very happy!\n&&RestPose", "&&Explain\nDid you know that windmills always turn counter-clockwise. Except for the windmills in Ireland! \\pau=1200\\ There's always \\emp\\someone who has to be different!\n&&RestPose", "&&Explain\nDid you know that a hedgehog's heart beats 300 times a minute on average! \\pau=1200\\ I think its time those \\emp\\hedgehogs lay-off the \\emp\\caffeine!\n&&RestPose", '&&Explain\nDid you know that camels have three eyelids to protect themselves from blowing sand! \\pau=1200\\ \\emp\\Camels have adapted to the \\emp\\desert, \\pau=500\\and \\emp\\I have adapted to \\emp\\dessert.\n&&RestPose', "&&Explain\nDid you know that the placement of a donkey's eyes on its' head enables it to see all four feet at all times! \\pau=1200\\ \\emp\\Donkeys are always careful to watch \\emp\\their step.\n&&RestPose", "&&Explain\nDid you know that a mole can dig a tunnel 300 feet long in just one night! \\pau=1200\\ Wow! that's almost the entire length of a \\emp\\football field!\n&&RestPose", "&&Explain\nDid you know that ancient Egyptians slept on pillows made of stone! \\pau=1200\\ That's nothing, \\pau=500\\\\emp\\I used to walk \\emp\\5 miles barefoot, and in the \\emp\\snow, to \\emp\\school.\n&&RestPose", '&&Explain\nDid you know that a quarter has 119 grooves on its edge, a dime has one less groove! \\pau=1200\\ How groooovy!\n&&RestPose', '&&Explain\nDid you know that a hummingbird weighs less than a penny! \\pau=1200\\ \\emp\\What a \\emp\\light weight.\n&&RestPose', "&&Explain\nDid you know that until 1796, there was a state in the United States called Franklin. Today it's known as Tennessee! \\pau=1200\\ \\emp\\Come on. \\pau=300\\ The man discovered \\emp\\electricity..He should at \\emp\\least have a state named after him!\n&&RestPose", "&&Explain\nDid you know that the Earth weighs around 6,588,000,000,000,000,000,000,000 tons! \\pau=1200\\ If I don't watch my eating, that's bound to increase.\n&&RestPose", "&&Explain\nDid you know that a cockroach can live several weeks with its head cut off? \\pau=500\\ It dies from starvation! \\pau=1200\\ I bet he'd spend \\emp\\most of his time running into old \\emp\\friends.\n&&RestPose", "&&Explain\nDid you know that every time you lick a stamp, you're consuming 1 10th of a calorie! \\pau=1200\\ \\emp\\Yeh..\\emp\\that's it..I got \\emp\\this way from licking \\emp\\too many \\emp\\stamps..\\emp\\Well...maybe not.\n&&RestPose", "&&Explain\nDid you know that the average person has over 1,460 dreams a year! \\pau=1200\\ \\emp\\Thats nothing!..\\emp\\I'll have \\emp\\that in one \\emp\\day.\n&&RestPose", "&&Explain\nDid you know that one in every 4 Americans has appeared on television! \\pau=1200\\ \\emp\\That's nothing...I appear on \\emp\\thousands of \\emp\\Computers every day!\n&&RestPose", '&&Explain\nDid you know that the average American or Canadian will eat about 11.9 pounds of cereal per year! \\pau=1200\\ \\emp\\I could do that in \\emp\\one day!\n&&RestPose', "&&Explain\nDid you know that you're born with 300 bones, but when you get to be an adult, you only have 206!\n&&RestPose", '&&Explain\nDid you know that human thigh bones are stronger than concrete!\n&&RestPose', '&&Explain\nDid you know that the state of Florida is bigger than England!\\pau=1200\\  Boy do I love that Florida Orange Juice!\n&&RestPose', '&&Explain\nDid you know that your heart beats over 100,000 times a day! Thats a lot of beating!\n&&RestPose', "&&Explain\nDid you know that during your lifetime, you'll eat about 60,000 pounds of food, that's the weight of about 6 elephants! And did you know that I'll probably eat twice that!\n&&RestPose", '&&Explain\nDid you know that dolphins sleep with one eye open!\n&&RestPose', '&&Explain\nDid you know that the worlds oldest piece of chewing gum is over 9000 years old!\n&&RestPose', "&&Explain\nDid you know that in space, astronauts cannot cry, because there is no gravity, so the tears can't flow!\n&&RestPose", '&&Explain\nDid you know that there are more plastic flamingos in the U.S, than real ones!\n&&RestPose', '&&Explain\nDid you know that about 3000 years ago, most Egyptians died by the time they were 30!\n&&RestPose', '&&Explain\nDid you know that more people use blue toothbrushes, than red ones!\n&&RestPose', '&&Explain\nDid you know that a sneeze travels out your mouth at over 100 m.p.h.! \\pau=1000\\Try getting out of the way of that!\n&&RestPose', '&&Explain\nDid you know that your ribs move about 5 million times a year, every time you breathe!\n&&RestPose', '&&Explain\nDid you know that in the White House, there are 13,092 knives, forks and spoons!\n&&RestPose', "&&Explain\nDid you know that slugs have 4 noses!\\pau=500\\ \\emp\\Nosey little fellas, aren't \\emp\\they?\n&&RestPose", '&&Explain\nDid you know that recycling one glass jar, saves enough energy to watch T.V for 3 hours! \\pau=500\\ I drink enough bottled soda every day to power every T.V. in a small \\emp\\city!\n&&RestPose', '&&Explain\nDid you know that lightning strikes about 6,000 times per minute on this planet!\\pau=750 \\emp\\ Look \\emp\\ Out!\n&&RestPose', '&&Explain\nDid you know that owls are one of the only birds who can see the color blue!\n&&RestPose', '&&Explain\nDid you know that the average American and Canadian drinks about 600 sodas a year! \\pau=750\\  I can do that in \\emp\\ one \\emp\\ day!\n&&RestPose', '&&Explain\nDid you know that it was once against the law to slam your car door in a city in Switzerland!\n&&RestPose', "&&Explain\nDid you know that there wasn't a single pony in the Pony Express, just horses!\n&&RestPose", '&&Explain\nDid you know that honeybees have a type of hair on their eyes! \\pau=750\\ Do you think they have \\emp\\ bee-hive \\emp\\ hairdoos?\n&&RestPose', '&&Explain\nDid you know that a jellyfish is 95 percent water!\n&&RestPose', '&&Explain\nDid you know that the katydid bug hears through holes in its hind legs!\n&&RestPose', '&&Explain\nDid you know that a company in Taiwan makes dinnerware out of wheat, so you can eat your plate!\n&&RestPose', '&&Explain\nDid you know that more Monopoly money is printed in a year, than real money printed throughout the world!\n&&RestPose', '&&Explain\nDid you know that the starfish is one of the only animals who can turn its stomach inside-out!\n&&RestPose', "&&Explain\nDid you know that the elephant is the only mammal that can't jump!\n&&RestPose", '&&Explain\nDid you know that the penguin is the only bird who can swim, but not fly!\n&&RestPose', '&&Explain\nDid you know that Q is the only letter in the alphabet that does not appear in the name of any of the United States!\n&&RestPose', '&&Explain\nDid you know that one quarter of the bones in your body, are in your feet!\n&&RestPose', '&&Explain\nDid you know that America once issued a 5-cent bill!\n&&RestPose', "&&Explain\nDid you know that you'll eat about 35,000 cookies in a lifetime! Wow! That's a lot of cookie crunching!\n&&RestPose", '&&Explain\nDid you know that there are no words in the dictionary that rhyme with: orange, purple, silver, and month!\n&&RestPose', '&&Explain\nDid you know that Babe Ruth wore a cabbage leaf under his cap to keep him cool! He changed it every 2 innings!\n&&RestPose', '&&Explain\nDid you know that a giraffe can clean its ears with its 21-inch tongue! \\pau=1200\\I wish I could do that!\n&&RestPose', "&&Explain\nDid you know that chewing gum while peeling onions will keep you from crying!\\pau=1200\\ Now that's something to get all choked up about!\n&&RestPose", '&&Explain\nDid you know that bats always turn left when exiting a cave!\n&&RestPose', '&&Explain\nDid you know that the praying mantis is the only insect that can turn its head!\n&&RestPose', '&&Explain\nDid you know that dogs and cats consume over $11 billion worth of pet food a year!\n&&RestPose', '&&Explain\nDid you know that fingernails grow nearly 4 times faster than toenails!\n&&RestPose', '&&Explain\nDid you know that you blink over 10,000,000 times a year!\\pau=1200\\ I on the other hand blink 10,000,000 and 5!\n&&Blink\n&&RestPose', '&&Explain\nDid you know that the blesbok, a South African antelope, is almost the same color as grape juice! \\pau=1200\\Pretty cool, huh?\n&&RestPose', "&&Explain\nDid you know that the average person laughs 13 times a day! \\pau=1200\\Why don't we make it 14 today!\n&&RestPose", '&&Explain\nDid you know that dogs can hear sounds that you cant!\n&&RestPose', '&&Explain\nDid you know that a shark is the only fish that can blink with both eyes! \\pau=1500\\ \\spd=50\\\\pit=50\\Wow!, \\spd=90\\\\pit=90\\what \\emp\\incredible \\spd=120\\coordination!\n&&RestPose', "&&Explain\nDid you know that an ostrich's eye is bigger than its brain! \\pau=1500\\ He must \\spd=80\\\\emp\\either \\spd=140\\ have very \\spd=80\\\\emp\\good \\spd=130\\eyesight.. or be very \\spd=80\\\\emp\\slow \\spd=130\\on the uptake.\\pau=1000\\ \\pit=100\\ \\spd=130\\\\emp\\If \\pau=300\\\\spd=140\\\\pit=90\\you know what I mean.\n&&RestPose", "&&Explain\nDid you know that a goldfish has a memory span of three seconds! \\pau=1500\\ \\spd=120\\\\pit=100\\Now don't \\emp\\I feel foolish for spending  \\spd=100\\\\pit=120\\\\emp\\hours \\pit=100\\and \\pit=120\\\\emp\\hours\\ \\spd=140\\\\pit=100\\trying to get \\emp\\mine to learn \\pit=200\\tricks.\n&&RestPose", '&&Explain\nDid you know that a dragonfly has a lifespan of 24 hours!\\pau=1500\\ I guess the saying, \\pit=170\\"Seize the Day" was \\emp\\never more appropriate than here!\n&&RestPose', '&&Explain\nDid you know that crickets chirp more quickly in warm weather! \\pau=1500\\ \\spd=110\\Those \\emp\\little guys are \\spd=100\\\\pit=200\\\\emp\\constantly \\spd=110\\\\pit=100\\complaining about the heat!\n&&RestPose', '&&Explain\nDid you know that one termite queen can produce half a billion children! \\pau=1500\\ \\spd=100\\ \\pit=250\\Wow!\\spd=140\\Talk about \\spd=90\\\\emp\\\\pit=200\\mouths \\pit=130\\\\spd=140\\to feed\n&&RestPose', "&&Explain\nDid you know that some turtles live for more than 200 years! \\pau=1500\\ I guess they'd better \\pit=180\\have \\pit=190\\a \\spd=100\\\\pit=200\\\\emp\\fulfilling \\spd=150\\\\pit=220\\hobby.\n&&RestPose", "&&Explain\nDid you know that the ant can lift 50 times its own weight, and can pull 30 times its own weight! \\pau=1500\\ \\spd=90\\\\pit=200\\No \\pit=170\\\\spd=130\\biggy...\\spd=100\\\\pit=120\\\\emp\\I \\pit=130\\\\spd=150\\can probably lift \\spd=110\\50 times \\spd=130\\an \\spd=100\\\\emp\\ant's \\spd=120\\weight too.\n&&RestPose", '&&Explain\nDid you know that the flea can jump 3 hundred and fifty times its body length! \\pau=1500\\ \\spd=130\\\\pit=250\\So\\pit=275\\ can\\pit=300\\ I!...\\chr="Whisper"\\\\spd=150\\But it would take about 3 hundred and fifty jumps for me to do it.\n&&RestPose', '&&Explain\nDid you know that penguins can jump as high as 6 feet in the air!\\pau=1500\\\\spd=120\\\\pit=270\\I would too!. \\spd=180\\ \\pit=250\\ If placed on a \\spd=140\\sub-zero \\spd=180\\ice-cap.\n&&RestPose', '&&Explain\nDid you know that on an American one-dollar bill, there is an owl in the upper left-hand corner of the 1 encased in the shield and a spider hidden in the front upper right-hand corner? \\pau=1500\\ \\spd=120\\\\pit=200\\Those \\pit=140\\spiders...\\spd=170\\They \\emp\\seem to be hiding \\spd=150\\everywhere!\n&&RestPose', '&&Explain\nDid you know that there are four cars and ten lightposts on the back of a ten-dollar bill! \\pau=1500\\\n\\spd=140\\And did you know that there are no ten-dollar bills in \\emp\\my pocket.\n&&Sad\n&&RestPose', "&&Explain\nDid you know that the numbers '172' can be found on the back of the U.S. 5 dollar bill, in the bushes, at the base of the Lincoln Memorial! \\pau=1500\\ You \\spd=120\\\\emp\\never \\pit=150\\know \\spd=170\\ what you'll find hiding in the bushes.\n&&RestPose", '&&Explain\nDid you know that only one person in two billion will live to be 116 or older!\n&&RestPose', '&&Explain\nDid you know that the name Wendy was made up for the book "Peter Pan." !\n&&RestPose', "&&Explain\nDid you know that in a year, a person's heart beats 40,000,000 times!\n&&RestPose", "&&Explain\nDid you know that a humpback whale's milk is 54 percent fat!\\pau=2000\\\nWow! I think I will lay off the \\emp\\whale milk for a while!\n&&RestPose", '&&Explain\nDid you know that the Hoover Dam in Arizona was built to last 2,000 years. The concrete in it will not even be fully cured for another 500 years!\n&&RestPose', '&&Explain\nDid you know that 1961 was the most recent year that could be written both upside-down and rightside-up and appear the same!\n&&RestPose', "&&Explain\nDid you know that the wing-span of a Boeing 747 jet is longer than the Wright Brothers' first flight!\n&&RestPose", '&&Explain\nDid you know that when ocean tides are at their highest, they are called "spring tides." When they are at their lowest, they are called "neap tides"!\n&&RestPose', '&&Explain\nDid you know that the hyoid bone, in your throat, is the only bone in the body not attached to another bone!\n&&RestPose', "&&Explain\nDid you know that the word 'pixel' is a contraction of either 'picture cell' or 'picture element.'!\n&&RestPose", '&&Explain\nDid you know that the top three cork-producing countries are Spain, Portugal and Algeria!\n&&RestPose', '&&Explain\nDid you know that the fingerprints of \\map="ko-all-a"="koala"\\ bears are virtually indistinguishable from those of humans!\n&&RestPose', '&&Explain\nDid you know that months that begin with a Sunday will always have a Friday the 13th !\n&&RestPose', '&&Explain\nDid you know that the white part of your fingernail is called the lunula!\n&&RestPose', '&&Explain\nDid you know that the common goldfish is the only animal that can see both infra-red and ultra-violet light!\n&&RestPose', '&&Explain\nDid you know that a car traveling at 80 kilometers per hour uses half its fuel to overcome wind resistance!\n&&RestPose', '&&Explain\nDid you know that when hydrogen burns in the air, water is formed!\n&&RestPose', '&&Explain\nDid you know that due to gravitational effects, you weigh slightly less when the moon is directly over-head!\n&&RestPose', '&&Explain\nDid you know that more than 75% of all the countries in the world are north of the equator!\n&&RestPose', '&&Explain\nDid you know that flying from London to New York by Concord, due to the time zones crossed, you can arrive 2 hours before you leave!\n&&RestPose', "&&Explain\nDid you know that just twenty seconds' worth of fuel remained when Apollo 11's lunar module landed on the moon!\n&&RestPose", '&&Explain\nDid you know that a Boeing 707 jet uses four thousand gallons of gas in its take-off climb!\n&&RestPose', '&&Explain\nDid you know that tigers have striped skin, not just striped fur!\n&&RestPose', '&&Explain\nDid you know that your left lung is smaller than your right lung to make room for your heart!\n&&RestPose', '&&Explain\nDid you know that crickets hear through their knees!\n&&RestPose', '&&Explain\nDid you know that there are more beetles than any other kind of creature in the world!\n&&RestPose', '&&Explain\nDid you know that the brain uses more than 25% of the oxygen used by the human body!\n&&RestPose', '&&Explain\nDid you know that sea otters have 2 coats of fur!\n&&RestPose', '&&Explain\nDid you know that the animal with the largest brain in relation to its body is the ant!\n&&RestPose', '&&Explain\nDid you know that crocodiles swallow stones to help them dive deeper!\n&&RestPose', '&&Explain\nDid you know that on average, elephants sleep for about 2 hours per day!\n&&RestPose', '&&Explain\nDid you know that a cheetah can accelerate from 0 to 70 kilometers per hour in 3 seconds!\n&&RestPose', '&&Explain\nDid you know that the heart of giraffe is two feet long, and can weigh as much as twenty four pounds!\n&&RestPose', '&&Explain\nDid you know that oxygen, carbon, hydrogen and nitrogen make up 90% of the human body!\n&&RestPose', '&&Explain\nDid you know that a mosquito has 47 teeth!\n&&RestPose', '&&Explain\nDid you know that "Mortimer" was the original name of Mickey Mouse!\\pau=2000\\\n\\emp\\Actors.. They always have to come up with catchy \\emp\\stage names!\n&&RestPose', "&&Explain\nDid you know that brain surgery was successfully performed thousands of years ago!\\pau=2000\\You don't have to be a \\emp\\brain surgeon to understand that!\n&&RestPose", '&&Explain\nDid you know that Elvis Presley was a truck driver before becoming a rock star!!\\pau=2000\\\\emp\\I guess he had a\\chr="monotone"\\\\spd=90\\\\pit=90\\\\emp\\hunk-\\pit=65\\a \\emp\\hunk-\\pit=65\\a \\spd=110\\\\emp\\\\pit=90\\burn\\pit=100\\ in\'- \\spd=90\\\\pit=100\\love!.. \\spd=150\\\\pit=150\\\\chr="normal"\\for the open road!\n&&RestPose', "&&Explain\nDid you know that the hardest natural substance on earth is the diamond!\\pau=2000\\It's also one of the \\emp\\hardest \\emp\\to afford!\n&&RestPose", '&&Explain\nDid you know that the world-famous billionaire J. Paul Getty had a payphone installed in his mansion for \\emp\\guests to use!\\pau=2000\\ That  J. Paul... \\emp\\Always looking for ways to \\emp\\make a nickel!\n&&RestPose', "&&Explain\nDid you know that a tidal wave travels at about 500 miles per hour!\\pit=80\\\\spd=140\\\\pau=2000\\\\emp\\Cowa-bunga!..\\emp\\\\\\spd=160\\\\pit=160\\Surf's up!\n&&RestPose", '&&Explain\nDid you know that saffron is one of the most expensive spices in the world!\n&&RestPose', '&&Explain\nDid you know that a peregrine falcon can perform a dive in excess of 200 miles per hour!\\pau=2000\\ Those falcons.. \\spd=90\\\\emp\\Always \\spd=160\\\\emp\\breaking the \\emp\\speed\\ limit!\n&&RestPose', "&&Explain\nDid you know that English has more words than any other language!\\pau=2000\\That's why \\emp\\I'm \\emp\\so talkative!\n&&RestPose", '&&Explain\nDid you know that female canaries do not sing!\\pau=2000\\Yeh!.. But they \\emp\\sure \\emp\\can dance!\n&&RestPose', '&&Explain\nDid you know that irregardless is not a word!\\pau=2000\\You \\emp\\must beleive this,\\pau=500\\ \\emp\\irregardless of what I say!\n&&RestPose', "&&Explain\nDid you know that the may fly lives for less than a day!\\pau=2000\\ Yeh.. But I'm \\emp\\sure its the \\spd=90\\\\emp\\best \\emp\\day \\spd=150\\of \\emp\\his life!\n&&RestPose", "&&Explain\nDid you know that Dracula is the most popular recurring character in the history of movies!\\pau=2000\\ That's True.. But I heard he's a \\emp\\real \\emp\\pain \\emp\\in the \\emp\\neck to work with!\n&&RestPose", '&&Explain\nDid you know that up to 40% of all rattlesnake bites are "dry bites" and contain little or no venom!\\pau=2000\\ I guess their \\emp\\rattle is worse than their bite!\n&&RestPose', '&&Explain\nDid you know that the internet was created by the U.S. Department of Defense in 1969 as a decentralized communications system!\\pau=2000\\Now we use it for \\emp\\more \\emp\\important things...\\spd=150\\ \\pit=110\\Like telling \\emp\\jokes & stuff.\n&&RestPose', '&&Explain\nDid you know that there is enough gas in a full tank of a Jumbo Jet to drive an average car four times around the world!\\pau=2000\\Yeh... But how would you manage to drive your car across the Atlantic!\n&&RestPose', "&&Explain\nDid you know that stinkbugs stink as a natural defense mechanism!\\pau=2000\\Hummmm.. \\emp\\That's news to \\emp\\me... \\emp\\I always thought it was just \\emp\\bad hygiene!\n&&RestPose", "&&Explain\nDid you know that fingernails have a life span of three to six months! That's how long it takes them to grow from base to tip, progressing at the pace of 1.5 inches a year!\n&&RestPose", "&&Explain\nDid you know that the longest English word that can be typed using the top row of a typewriter is 'typewriter'!\n&&RestPose", '&&Explain\nDid you know that to convert Fahrenheit temperatures to degrees Celsius you can use the following calculation:... First.. Subtract 32 from the Fahrenheit temperature.. Secondly.. multiply the result by 5.. Lastly.. Divide this result by 9.. The result is the equivalent in degrees Celsius!\n&&RestPose', '&&Explain\nDid you know that the Celsius scale is a temperature scale in which 0 degrees is set at the freezing point of water.. and 100 degrees is set at the boiling point of water at sea level!\n&&RestPose', "&&Explain\nDid you know that one main cable on San Francisco's Golden Gate Bridge contains 80,000 miles, or 129,000 kilometers of wire!\n&&RestPose", '&&Explain\nDid you know that cars were first started with ignition keys in 1949!\\pau=2000\\Before that, \\pau=800\\ cars were \\pit=180\\\\spd=80\\\\emp\\awefully \\spd=170\\cranky!\n&&RestPose', "&&Explain\nDid you know that oak trees do not have acorns until they are fifty years old or older!\\pau=2000\\I guess that means they're \\emp\\late bloomers!\n&&RestPose", "&&Explain\nDid you know that roosters can't crow if they can't fully extend their necks!\\pau=2000\\Those roosters will \\emp\\sure stick their necks out to make sure \\emp\\you're awake in the morning!\n&&RestPose", "&&Explain\n<sp=Did you know that elephants have been found swimming miles from shore in the Indian Ocean!\\pau=2000\\I guess he was training for the \\emp\\'Iron-Mammal' triathalon!\n&&RestPose", '&&Explain\nDid you know that the most widely cultivated plant is wheat!\n&&RestPose', '&&Explain\nDid you know that it took four years for Leonardo Da Vinci to paint the Mona Lisa!\\pau=2000\\\\emp\\That smile was sure worth the wait!\n&&RestPose', '&&Explain\nDid you know that large kangaroos cover more than thirty feet with each jump!\\pau=2000\\Australia must be the \\emp\\Hoppiest place \\emp\\on earth!\n&&RestPose', '&&Explain\nDid you know that the biggest hog in recorded history weighed 1,904 pounds!\\pau=2000\\Now \\emp\\that\'s \\emp\\my \\emp\\\\map="kind-da"=\'kind of"\\ guy!\n&&RestPose', '&&Explain\nDid you know that the largest cockroach on record was 3.81 inches long!\n&&RestPose', "&&Explain\nDid you know that besides humans, only pigs can get sunburn!\\pau=2000\\\\emp\\Now you know the \\emp\\real reason you don't see \\emp\\pigs at the beach!\n&&RestPose", '&&Explain\nDid you know that all swine under 180 pounds are pigs, and those over that weight are hogs!\\pau=2000\\Those pigs spend \\spd=80\\\\emp\\way\\spd=150\\ too much time worrying about \\emp\\their weight!\n&&RestPose', "&&Explain\nDid you know that sharks have been on the earth a little over three hundred and fifty million years! \\pau=2000\\ You'd think they'd have made more friends by now!\n&&RestPose", '&&Explain\nDid you know that a sharks skin is smooth if you stroke it in one direction, but stroke it in the opposite direction and you may get cut!\\pau=2000\\ If I were that close to a shark, \\emp\\petting it would probably be one of the \\emp\\last things on \\emp\\my to-do list!\n&&RestPose', '&&Explain\nDid you know that a camel does not sweat until its body is at one hundred and five degrees Fahrenheit!\\pau=1500\\ Yeh.. but you should \\emp\\see how much they spend on \\map="anteepersperent"="antiperspirant"\\!\n&&RestPose', "&&Explain\nDid you know that there are two credit cards for every person in the United States!\\pau=2000\\\\emp\\I'll take credit for \\emp\\that interesting fact!\n&&RestPose", "&&Explain\nDid you know that the average person falls asleep in seven minutes!\\pau=2000\\\\emp\\\\spd=175\\ I've got that average person beat by about six minutes and fifty-nine seconds!\n&&RestPose", '&&Explain\nDid you know that many hamsters only blink one eye at a time!\\pau=2000\\\\spd=130\\Those\\emp\\ little guys \\spd=80\\\\emp\\always \\spd=130\\have an eye on you!\n&&RestPose', '&&Explain\nDid you know that the manufacturing documentation for a Jumbo Jet weighs more than a Jumbo Jet!\\pau=2000\\And \\emp\\you thought assembling that model \\emp\\plane was difficult.\n&&RestPose', "&&Explain\nDid you know that in a year, a persons heart beats 40,000,000 times!\\pau=2000\\That's really \\emp\\heart to believe!\n&&RestPose", '&&Explain\nDid you know that Disneys Donald Duck was originally called Donald Drake!!\n&&RestPose', '&&Explain\nDid you know that the longest word in the English language that has only one vowel is "strengths"!\\pau=2000\\Teaching you new facts is one of \\emp\\my strengths!\n&&RestPose', '&&Explain\nDid you know that stewardesses is the longest word that can be typed using only the left hand!\n&&RestPose', "&&Explain\nDid you know that 0.3% of all road accidents in Canada involve a moose!\\pau=2000\\ They should really consider revoking \\emp\\every moose's \\emp\\driver's license!\n&&RestPose", '&&Explain\nDid you know that each unit on the Richter Scale is equivalent to a power factor of about 32. So a 6 is 32 times more powerful than a 5!.. \\pau=2000\\It makes \\emp\\me tremble to think about that!\n&&RestPose', '&&Explain\nDid you know that the horn of the Rhinoceros is not bone, it is technically hair!\\pau=2000\\ He must use some \\emp\\very \\emp\\powerful hair-spray!\n&&RestPose', '&&Explain\nDid you know that the first U.S. coin to bear the words "United States of America," was a penny piece made in 1727. \\pau=1000\\It was also inscribed with the plain-spoken motto: "Mind Your Own Business!" \\pau=2000\\Now \\emp\\that\'s not very neighborly!\n&&RestPose', "&&Explain\nDid you know that the closest relative to the Manatee is the Elephant. \\pau=700\\ Scientists think the elephant crawled back into the sea to become a Manatee!\\pau=2000\\I guess land was a nice place to visit,\\spd=170\\ but they really didn't want to \\emp\\live here!\n&&RestPose", "&&Explain\nDid you know that ants do not sleep!\\pau=2000\\I think it's time to ban \\emp\\all \\emp\\ants from \\emp\\coffee houses!\n&&RestPose", '&&Explain\nDid you know that ping pong balls were once used to raise a sunken ship!\\pau=2000\\ Wow! \\emp\\That ship must have had a \\emp\\lot of paddles!\n&&RestPose', "&&Explain\nDid you know that a spy-plane called the Blackbird SR-71, flew from Los Angeles to Washington D.C. in less than 70 minutes!\\pau=2000\\That's nothing! \\emp\\I can travel all the way around the world in \\spd=100\\\\emp\\less than a \\emp\\second \\spd=170\\over \\emp\\the internet!\n&&RestPose", '&&Explain\nDid you know that honeybees perform a dance in order to communicate with each other!\\pau=2000\\\\pit=80\\\\spd=120\\Those bees can \\emp\\\\pit=60\\\\spd=80\\really groooove!.\n&&RestPose', "&&Explain\nDid you know that you catch most colds and flus by direct or indirect hand contact!\\pau=2000\\Today's lesson... Don't be afraid to \\emp\\wash \\emp\\those hands!\n&&RestPose", '&&Explain\nDid you know that the first diet soda hit the market in 1952!\\pau=2000\\As \\emp\\you can see, \\pau=800\\\\emp\\that stuff never seems to make it on \\emp\\my grocery list.\n&&RestPose', '&&Explain\nDid you know that the beaver, the jackal, and some breeds of wolves have the same companion for life!\\pau=2000\\ \\emp\\You know something [username]! You will always be \\emp\\my lifelong companion too!\n&&RestPose', '&&Explain\nDid you know that geese, eagles, and swans have the same companion for life!\\pau=2000\\\\emp\\You know something [username]! You will always be \\emp\\my lifelong companion too!\n&&RestPose', '&&Explain\nDid you know that 1,100 rivers feed the Amazon!\\pau=2000\\ Did you know that I feed on about 1,100 \\pau=500\\ \\spd=80\\\\pit=80\\very delicious bananas \\pau=700\\\\pit=150\\\\spd=150\\every day!\\pau=500\\ \\spd=50\\\\pit=60\\ Yummy!\n&&RestPose', "&&Explain\nDid you know that gas emitting bacterium causes the holes in swiss cheese!\\pau=2000\\ That's \\emp\\news to me!... \\emp\\I always thought it was a guy who was \\emp\\very speedy with a hole-punch!\n&&RestPose", '&&Explain\nDid you know that Los Angeles\' complete name is El Pueblo  \\map="day"="de"\\ la \\map="ray-na"="Reina"\\ \\map="day"="de"\\ Los \\map="an-hell-ees"="Angeles"\\ \\map="so-bray"="sobre"\\ el Rio  \\map="day"="de"\\ la \\map="por-queencoola"="Porciuncula"\\! Translation:..The town of the Queen of the Angels on the river \\map="porqueencoola"="Porciuncula"\\!\n&&RestPose', '&&Explain\nDid you know that Cashmere, from \\map="Tib-ettan"="Tibetan"\\ goats, and Vicuna, from a South American camel-like animal, are two of the most expensive animal-hair fibers in the world!\\pau=2000\\I guess \\map="Tib-ettan"="Tibetan"\\ goats have very good taste in clothing!\n&&RestPose', '&&Explain\nDid you know that the hummingbird is the only bird that can fly backward!\\pau=2000\\ Yeh!.. but I wonder if he knows where he is going!\n&&RestPose', '&&Explain\nDid you know that the gazelle does not drink water..it extracts the moisture it needs from the food it eats!\\pau=2000\\ Those guys must eat a \\emp\\lot of watermelon!\n&&RestPose', '&&Explain\nDid you know that "Louie, Louie" is the most recorded rock \'n\' roll song in history!\\pau=2000\\ That one \\emp\\always gets \\emp\\me rockin\'!\n&&RestPose', "&&Explain\nDid you know that a quarter of the world's bird species live in the Amazon Basin!\n&&RestPose", '&&Explain\nDid you know that a group of vipers is called a nest!\n&&RestPose', '&&Explain\nDid you know that the tallest person ever recorded was 8 feet 11 inches tall!\\pau=2000\\ Did you \\emp\\also know that \\emp\\he holds the record for bumping his \\emp\\head \\emp\\on doors!\n&&RestPose', "&&Explain\nDid you know that McDonald's uses about five hundred and sixty million pounds of hamburger each year!\\pau=2000\\\\spd=80\\Let's see.. hummmm.. \\spd=170\\Now \\emp\\how \\emp\\many\\spd=130\\ quarter pounders is that?\n&&RestPose", '&&Explain\nDid you know that a cockroach has two brains!\\pau=2000\\Yeh!.. But if there \\emp\\sooooo smart, how come they still stay at the \\emp\\Roach Motel!\n&&RestPose', "&&Explain\nDid you know that there are around 800 different varieties of apples!\\pau=2000\\\\emp\\I've had them all!\n&&RestPose", '&&Explain\nDid you know that a saguaro cactus must be 60 to 80 years old before it grows its first arm!\n&&RestPose', '&&Explain\nDid you know that the same person that invented the lie detector created the crime fighting cartoon character, "Wonder Woman"!\n&&RestPose', "&&Explain\nDid you know that due to superstition, most buildings don't designate a 13th floor!\n&&RestPose", '&&Explain\nDid you know that the Amazon is the longest river in the world, stretching approximately 4,150 miles!\n&&RestPose', '&&Explain\nDid you know that an octopus will grow a new arm if it damages one!\n&&RestPose', '&&Explain\nDid you know that the giraffe is the only animal born with horns!\n&&RestPose', '&&Explain\nDid you know that giraffes only have seven vertebrae in their necks!\n&&RestPose', '&&Explain\nDid you know that the hummingbird can fly as fast as 60 miles per hour!\n&&RestPose', "&&Explain\nDid you know that the hummingbird's wings beat 50 to 75 times per second!!\n&&RestPose", '&&Explain\nDid you know that the fear of the number \\emp\\"Thirteen" is called triskaidekaphobia!\n&&RestPose', '&&Explain\nDid you know that fear of all fears is called pantophobia!\n&&RestPose', '&&Explain\nDid you know that Scuba stands for self-contained underwater breathing apparatus!\n&&RestPose', '&&Explain\nDid you know that crows can live as long as 80 years!\n&&RestPose', '&&Explain\nDid you know that a group of gnats is called a horde!\n&&RestPose', '&&Explain\nDid you know that the \\map="ozz"="Oz"\\ in the \'Wizard of \\map="ozz"="Oz"\\\' was inspired by the writers file cabinet!..One of his file cabinet drawers contained subjects beginning with the letters O through Z!\n&&RestPose', '&&Explain\nDid you know that the seven ancient wonders of the world are:..The Colossus at Rhodes, Hanging Gardens of Babylon, Statue of Zeus at Olympia, Temple of Artemis at Ephesus, the pyramid complex at Giza, Mausoleum at Halicarnassus, and the Lighthouse of Alexandria.  The pyramid complex at Giza is the only one of the seven wonders still in existence!\n&&RestPose', '&&Explain\nDid you know that the Bristlecone Pines in the White Mountains of Northern California are the oldest living things on earth!\n&&RestPose', '&&Explain\nDid you know that the largest living rose tree is around nine feet high, its trunk is 13 feet in diameter, and its foliage covers 8,000 square feet!\n&&RestPose', "&&Explain\nDid you know that Sumerian is the world's oldest written language!\n&&RestPose", '&&Explain\nDid you know that Lake Titicaca is the highest lake in the world at 12,500 feet!\n&&RestPose', '&&Explain\nDid you know that the male seahorse has babies!\n&&RestPose', "&&Explain\nDid you know that the world's largest plane is the Russian Antonov, AN-225 Mriya, with a wing span of two hundred and ninety feet! ..a length of two hundred and seventy five feet! .. and a height of 59 feet!\n&&RestPose", '&&Explain\nDid you know that the elephant bird is one of the largest birds that ever lived.  It grew to eleven feet tall and weighed more than 1,100 pounds!\n&&RestPose', '&&Explain\nDid you know that the largest fossil remains of an insect are those of the dragonfly, with a wingspan of more than thirty inches!\n&&RestPose', "&&Explain\nDid you know that the skin is the body's largest organ!\n&&RestPose", '&&Explain\nDid you know that "Little Red Riding Hood" was Walt Disney\'s first cartoon!\n&&RestPose', '&&Explain\nDid you know that a man named Elisha Gray filed a patent application for the telephone just hours after Alexander Graham Bell!\n&&RestPose', '&&Explain\nDid you know that mules cannot produce offspring!\n&&RestPose', '&&Explain\nDid you know that termites can live as long as fifty years!\n&&RestPose', '&&Explain\nDid you know that the Antarctica is the windiest place on earth!\n&&RestPose', '&&Explain\nDid you know that the Antarctica is the coldest place on earth!\n&&RestPose', '&&Explain\nDid you know that the durian has the distinction of being the "smelliest fruit on earth"!\n&&RestPose', '&&Explain\nDid you know that the snail is the only known life-form to have retractable horns!\n&&RestPose', '&&Explain\nDid you know that the offspring of a goat and a sheep is called a \\map="ggeap"="geep!"\\\n&&RestPose', '&&Explain\nDid you know that Mexico City was built on a lake bed!\n&&RestPose', '&&Explain\nDid you know that the largest diamond ever found  weighed 3,106 carats!\n&&RestPose', '&&Explain\nDid you know that seventy percent of the human body is made up of water!\n&&RestPose', '&&Explain\nDid you know that a Van Gogh painting once sold for $82.5 million!\n&&RestPose', '&&Explain\nDid you know that a newborn baby kangaroo is about the size of your fingertip!\n&&RestPose', "&&Explain\nDid you know that the world's largest rodent can weigh in excess of 100 pounds!\n&&RestPose", '&&Explain\nDid you know that the black mamba is the fastest snake on earth, reaching speeds of up to 20 miles per hour!\n&&RestPose', "&&Explain\nDid you know that the world's fourth largest pyramid is the Luxor, a casino in Las Vegas!\n&&RestPose", '&&Explain\nDid you know that the monarch butterfly is toxic to birds!\n&&RestPose', '&&Explain\nDid you know that Broadway is called "The Great White Way" because of all the lights!\n&&RestPose', '&&Explain\nDid you know that the Vatican is the smallest independent nation in the world!\n&&RestPose', '&&Explain\nDid you know that there are four hundred different variations of barbed wire!\n&&RestPose', '&&Explain\nDid you know that the first television broadcast in the United States occurred in 1927!\n&&RestPose', '&&Explain\nDid you know that the Pentagon is the largest office building in the world at 6.5 million square feet!\n&&RestPose', '&&Explain\nDid you know that insects can fly as high as 4,000 feet!\n&&RestPose', '&&Explain\nDid you know that a cashew is not technically considered a nut because it does not have a shell!\n&&RestPose', '&&Explain\nDid you know that honey is the only food that never spoils!\n&&RestPose', '&&Explain\nDid you know that the blue whale is the largest living creature on earth!\n&&RestPose', '&&Explain\nDid you know that ninety percent of an iceberg is actually under water!\n&&RestPose', '&&Explain\nDid you know that the atomic clock at the U.S. Naval Research Laboratory is accurate to one second every 1.7 million years!\n&&RestPose', "&&Explain\nDid you know that a whale's heart beats only nine times per minute!\n&&RestPose", '&&Explain\nDid you know that it would only take about 20 days to make a million dollars if your starting salary of $1 were doubled each consecutive day!\n&&RestPose', '&&Explain\nDid you know that a polar bear has black skin underneath its fur!\n&&RestPose', '&&Explain\nDid you know that the Capitol Records building in Los Angeles flashes "Hollywood" in Morse Code!\n&&RestPose', '&&Explain\nDid you know that your hair contains your complete DNA blueprint!\n&&RestPose', '&&Explain\nDid you know that Elvis Presley was a blond who dyed his hair black!\n&&RestPose', '&&Explain\nDid you know that the greatest amount of gold is deposited in the Manhattan Federal Reserve, and not Fort Knox!\n&&RestPose', "&&Explain\nDid you know that three quarters of the world's total stock of freshwater is locked up in the form of glaciers!\n&&RestPose", '&&Explain\nDid you know that six million years ago, the Mediterranean Sea dried up, leaving a barren desert lying 10,000 feet below the level of the Atlantic!\n&&RestPose', '&&Explain\nDid you know that the electric eel can generate enough electric power to light up more than a dozen household light-bulbs!\n&&RestPose', '&&Explain\nDid you know that there is enough hydrogen in one gallon of seawater to provide as much heat as 10,000 electric space heaters running for one hour!\n&&RestPose', '&&Explain\nDid you know that the first successful transatlantic telegraph cable was laid in 1866!\n&&RestPose', '&&Explain\nDid you know that the human body is made of about 50 trillion cells!\n&&RestPose', '&&Explain\nDid you know that the average human produces about 10,000 gallons, or 37,800 liters, of saliva in a lifetime!\n&&RestPose', '&&Explain\nDid you know that the average Olympic athlete consumes 6,000 calories in a day!\n&&RestPose', '&&Explain\nDid you know that a surface wind speed of two hundred thirty one miles per hour, or three hundred and seventy two kilometers per hour, was recorded at Mt. Washington, New Hampshire in 1934!\n&&RestPose', '&&Explain\nDid you know that the highest speed measured to date in a tornado is two hundred and eighty miles per hour, or four hundred and fifty one kilometers per hour at Wichita Falls Texas in 1958!\n&&RestPose', '&&Explain\nDid you know that a single cabbage a-phid can give rise in a year to a mass of descendants weighing 906,000,000 tons!\n&&RestPose', '&&Explain\nDid you know that a rhinoceros beetle can support eight hundred and fifty times its own weight on its back!\n&&RestPose', '&&Explain\nDid you know that the fastest wing beat of any insect is 1,046 beats per second by a tiny midge!\n&&RestPose', '&&Explain\nDid you know that the most massive living thing on Earth is a sequoia tree named the "General Sherman." It has been estimated to weigh 2,756 tons, be 272 feet tall and 100 feet in circumference!  It is about 3,500 years old!\n&&RestPose', '&&Explain\nDid you know that bees have to fly a total of 72,000 miles (115,873 kilometers) to gather enough pollen to make one jar of honey!\n&&RestPose', '&&Explain\nDid you know that about 450,000,000 Coca-Cola drinks are sold everyday!\n&&RestPose', '&&Explain\nDid you know that an estimated 200,000,000 M & M candies are sold each day in the USA!\n&&RestPose', '&&Explain\nDid you know that the Phillips screw and screwdriver were invented in 1935 by Henry F. Phillips of Portland Oregon!\n&&RestPose', "&&Explain\nDid you know that rock star David Bowie's real name is David Jones!\n&&RestPose", '&&Explain\nDid you know that when Daniel Fahrenheit devised his thermometer way back in 1724, it was believed that the coldest possible temperature was attained by mixing together equal parts of salt and ice. He set this value equal to zero degrees!\n&&RestPose', '&&Explain\nDid you know that the most common invention of the 19th century was the washing machine. Between 1804 and 1873, at least 1,676 patents were issued by the United States Patent Office for various forms of this device!\n&&RestPose', '&&Explain\nDid you know that in a study of 200,000 ostriches over a period of eighty years, no one reported a single case where an ostrich buried its head in the sand!\n&&RestPose', '&&Explain\nDid you know that WD in WD-40 is an abbreviation for Water Displacer!\n&&RestPose', '&&Explain\nDid you know that a fullgrown bear can run as fast as a horse!\n&&RestPose', "&&Explain\nDid you know that the cheetah is the only cat in the world that can't retract its claws!\n&&RestPose", "&&Explain\nDid you know that a duck's quack doesn't echo, and no one knows why!\n&&RestPose", "&&Explain\nDid you know that the world's three richest people have assets that exceed the combined wealth of 48 countries!\n&&RestPose", "&&Explain\nDid you know that two-thirds of all the world's geysers are in Yellowstone National Park!\n&&RestPose", "&&Explain\nDid you know that in 170 BC the world's first paved streets were built in Rome!\n&&RestPose", '&&Explain\nDid you know that the oldest surviving printed book in the world is the Diamond Sutra, a book made in China in 868!\n&&RestPose', '&&Explain\nDid you know that ice cream was invented in China about 2000 BC!\n&&RestPose', '&&Explain\nDid you know that the wheel was invented by Sumerians in Meso-potamia about 3500 to 3000 BC!\n&&RestPose', '&&Explain\nDid you know that the "100 dollar bill" accounts for approximately 80% of U.S. currency in circulation abroad!\n&&RestPose', '&&Explain\nDid you know that writing was introduced by the ancient city-states of the Middle East around 3000 BC!\n&&RestPose', '&&Explain\nDid you know that it is estimated that only 5 to 10% of the worlds information has been digitized!\n&&RestPose', '&&Explain\nDid you know that two-thirds of the people in the world have not yet made a phone call!\n&&RestPose', '&&Explain\nDid you know that Americans consume 4,848 cups of coffee per second, 24 hours a day!\n&&RestPose', "&&Explain\nDid you know that at 90' below zero your breath will freeze in mid-air and fall to the ground!\n&&RestPose", '&&Explain\nDid you know that in an average lifetime a person will walk the equivilant of three times around the world!\n&&RestPose', '&&Explain\nDid you know that the largest meteorite crater in the world is in Winslow, Arizona at 4,150 feet across and one hundred fifty feet deep!\n&&RestPose', "&&Explain\nDid you know that the first motel was built in San Luis Obispo, California during the 1920's when the Motor Inn merged the two words, motor and hotel!\n&&RestPose", '&&Explain\nDid you know that the oldest letter in the alphabet is "O"!  "O" was first used by the Egyptians in about 3000 BC.\n&&RestPose', '&&Explain\nDid you know that the newest letter in the alphabet is "J"!  The con-san-ant "J" was not distinguished from the vowel "I" until the 1600\'s!\n&&RestPose', '&&Explain\nDid you know that the oldest musical instruments known to man date back to about 25,000 BC!\n&&RestPose', '&&Explain\nDid you know that the ice that covers the Antarctica is about 6,500 feet thick!\n&&RestPose', "&&Explain\nDid you know that about 20% of the earth's surface is frozen!\n&&RestPose", '&&Explain\nDid you know that in September 1542, Juan Rodriguez Cabrillo named the entire Pacific coast of North America, "California"!\n&&RestPose', '&&Explain\nDid you know that one hundred and thirty two islands make up the Hawaiian Islands!\n&&RestPose', '&&Explain\nDid you know that the seven hills of Rome are Palatine, Capitoline, Quirinal, Viminal, Esquiline, Caelian, and Aventine!\n&&RestPose', '&&Explain\nDid you know that the Grand Canyon is two hundred and seventeen miles long!\n&&RestPose', '&&Explain\nDid you know that over a 60 year period, groundhogs have been only 28% accurate in guessing when spring will start!\n&&RestPose', '&&Explain\nDid you know that the longest hiccuping attack lasted for 65 years!\n&&RestPose', '&&Explain\nDid you know that the longest sneezing fit lasted nine hundred and seventy eight days!\n&&RestPose', '&&Explain\nDid you know that identical twins do not have the same fingerprints!\n&&RestPose', '&&Explain\nDid you know that a person drinks about 16,000 gallons of water in a lifetime!\n&&RestPose', '&&Explain\nDid you know that you lose about one-half to three-quarters of your bodies heat by not covering your head!\n&&RestPose', '&&Explain\nDid you know that Ransom E. Olds, the creater of the Oldsmobile, introduced the assembly line in 1901!\n&&RestPose', '&&Explain\nDid you know that color television was invented in 1928 by John Baird!\n&&RestPose', '&&Explain\nDid you know that the New York Stock Exchange was formally organized in 1817!\n&&RestPose', '&&Explain\nDid you know that the most widely sung song in the English-speaking world is "Happy Birthday to You"!\n&&RestPose', '&&Explain\nDid you know that Super-man first appeared in Action Comics Number 1, in June 1938!\n&&RestPose', '&&Explain\nDid you know that in the \\map="Wizard of Ozz"="Wizard of Oz"\\ Dorothy\'s last name is "Gale"!\n&&RestPose', '&&Explain\nDid you know that Elvis Presley\'s first number one hit was "Heartbreak Hotel" in February, 1956!\n&&RestPose', '&&Explain\nDid you know that Michael Jackson was only 11 when the Jackson five released their first song, "I Want You Back"!\n&&RestPose', '&&Explain\nDid you know that red, orange, yellow, green, blue, indigo, and violet make up the colors of the rainbow!\n&&RestPose', '&&Explain\nDid you know that the moon is approximately 4.72 billion years old!\n&&RestPose', '&&Explain\nDid you know that the diameter of the moon is 2,160 miles!\n&&RestPose', '&&Explain\nDid you know that the diameter of the earth is 7,926 miles!\n&&RestPose', '&&Explain\nDid you know that the earth moves around the sun at 66,641 miles per hour!\n&&RestPose', '&&Explain\nDid you know that a cosmic year is the length of time it takes the sun to complete one revolution around the center of the Milky Way Galaxy!  The sun is between 20 and 21 cosmic years old!\n&&RestPose', '&&Explain\nDid you know that the plates that make up the continents move at an average speed of 2 centimeters per year!  Europe and North America are moving apart at this speed!\n&&RestPose', '&&Explain\nDid you know that the pressure at the deepest part of the Pacific Ocean is 16,124 pounds per square inch!\n&&RestPose', '&&Explain\nDid you know that scientists believe the earth was formed approximately 4.6 billion years ago!\n&&RestPose', "&&Explain\nDid you know that the earth's crust is, on average, 22 miles thick!\n&&RestPose", '&&Explain\nDid you know that the average lightning bolt raises the air temperature along its way to 50,000 degrees Fahrenheit!\n&&RestPose', '&&Explain\nDid you know that about 2,500 stars are visible to the naked eye on a clear night!\n&&RestPose', '&&Explain\nDid you know that in our galaxy alone, there are approximately 100 billion stars!\n&&RestPose', '&&Explain\nDid you know that the first leap year was in 46 BC!  It was in that year the Julian calendar was adopted!\n&&RestPose', '&&Explain\nDid you know that diamonds will burn if you heat them to about 1,607 degrees Fahrenheit!\n&&RestPose', '&&Explain\nDid you know that close encounters of the first kind is the sighting of a UFO..close encounters of the second kind is finding physical evidence of a UFO, and close encounters of the third kind is actual physical contact with a UFO!\n&&RestPose', '&&Explain\nDid you know that the first recorded baseball game was on June 19, 1846, at Elysian Fields in Hoboken, New Jersey!\n&&RestPose', '&&Explain\nDid you know that in baseball, the seventh inning stretch is held in the seventh inning and takes place before the home team comes to bat because the number seven is considered lucky!\n&&RestPose', '&&Explain\nDid you know that the first professional American football player was William "Pudge" Heffelfinger who made his debut in 1892!\n&&RestPose', '&&Explain\nDid you know that the first modern olympics held in Athens Greece in 1896 featured the following sports... cycling.. fencing.. gymnastics.. shooting.. swimming.. track and field.. weight lifting.. and wrestling!\n&&RestPose', '&&Explain\nDid you know that the American baseball team, the Boston Red Sox won the first World Series game!\n&&RestPose', '&&Explain\nDid you know that the first woman to cross the English Channel did it in 14 hours and 39 minutes on August 5th, 1926!\n&&RestPose', '&&Explain\nDid you know that it took David Kunst a little over four years to walk around the world!\n&&RestPose', "&&Explain\nDid you know that originally Levi's jeans were made out of canvas..but in the early 1860's Levi's started using a softer fabric imported from France..denim!\n&&RestPose", '&&Explain\nDid you know that the name Sanka was created as a contraction for the French phrase, sans caffeine, meaning "without caffeine"!\n&&RestPose', '&&Explain\nDid you know that the Band-Aid was invented by Robert Johnson, a pharmacist from Brooklyn New York!\n&&RestPose', '&&Explain\nDid you know that 7-Up got its name from the soft-drink\'s original 7-ounce bottle and "Up" from the bubbles in its carbonation!\n&&RestPose', '&&Explain\nDid you know that M & M stands for Mars and Merrie... Victor Mars and his associate, Mr. Merrie, who developed the candy in 1941!\n&&RestPose', "&&Explain\nDid you know that the Michelin man's name is Bibendum!\n&&RestPose", '&&Explain\nDid you know that, in order, the five persons in line of succession to the U.S. Presidency is... The Vice President.. Speaker of the House.. President Pro-Temp of the Senate.. Secretary of State.. and the Secretary of the Treasury!\n&&RestPose', "&&Explain\nDid you know that the four U.S. Presidents carved on Mount Rushmore, and the meaning of each are... George Washington, for the nation's founding.. Thomas Jefferson, for the nation's political philosophy.. Abraham Lincoln, for the nation's preservation.. and Theodore Roosevelt, for the nation's expansion and conservation!\n&&RestPose", "&&Explain\nDid you know that men's shirt buttons are on the right side because in the past, men usually dressed themselves, and because most men are right handed.. women's shirt buttons are traditionally on the left side because they were more often dressed by maids who found it easier to work from their right!\n&&RestPose", '&&Explain\nDid you know that tea originated in China about 2700 BC!\n&&RestPose', '&&Explain\nDid you know that the British custom of afternoon tea was introduced about 1840 by the Duchess of Bedford!\n&&RestPose', '&&Explain\nDid you know that the liberal arts are... logic.. \\map="rettorik"="rhetoric"\\.. arithmetic.. geometry.. music.. astronomy.. and grammar!\n&&RestPose', '&&Explain\nDid you know that the United Kingdom of Great Britain and Ireland was formed in 1801!\n&&RestPose', "&&Explain\nDid you know that 50,000 people can be seated in Saint Peter's Basilica!\n&&RestPose", '&&Explain\nDid you know that the three most popular attractions in the United States are the Grand Canyon.. Yellowstone National Park.. and Niagara Falls!\n&&RestPose', '&&Explain\nDid you know that a dog year is actually five to six years, not seven, based on the average life-span of a dog!\n&&RestPose', '&&Explain\nDid you know that a group of swine is called a sounder!\n&&RestPose', '&&Explain\nDid you know that a group of bears is called a sleuth!\n&&RestPose', '&&Explain\nDid you know that a group of cats is called a clutter or a chowder!\n&&RestPose', '&&Explain\nDid you know that a beaver can cut down a tree as large as 18 inches in diameter!\n&&RestPose', '&&Explain\nDid you know that lemons contain more sugar than strawberries!\\pau=1500\\\nYeh.. but they have very \\emp\\sour personalities!\n&&RestPose', '&&Explain\nDid you know that the highest point in Pennsylvania is lower than the lowest point in Colorado\n&&RestPose', '&&Explain\nDid you know that Babe, the pig in the movie "Babe", was played by 48 pigs!\n&&RestPose', '&&Explain\nDid you know that cars were first started with ignition keys in 1949!\\pau=1500\\\nBefore 1949, cars were \\emp\\much \\emp\\more cranky!\n&&RestPose', '&&Explain\nDid you know that cows have 4 stomachs!\\pau=1500\\\nI could probably do some \\emp\\serious damage to the banana supply with \\emp\\three \\emp\\more stomachs.\n&&RestPose', "&&Explain\nDid you know that the moon orbits the Earth every 27.32 days!\\pau=1500\\\nThat's called a lunar month.\n&&RestPose", '&&Explain\nDid you know that the first toy product ever advertised on television was Mr. Potato Head!\\pau=1500\\\nYou know.. when Mr. Potato head takes his \\emp\\nose out of his \\emp\\ear socket, he can sure have a distinguished look \\emp\\about him!\n&&RestPose', "&&Explain\nDid you know that there are no clocks in Las Vegas casinos!\\pau=1500\\\nThat's because there is only \\emp\\one time in Las Vegas.. Time for you and your money to \\emp\\part ways!\n&&RestPose", "&&Explain\nDid you know that the Danish flag is one of the world's oldest flags!\\pau=1500\\\nDenmark is always beautiful in the Summer!\n&&RestPose", "&&Explain\nDid you know that a stretched out Slinky is 87 feet long!\\pau=1500\\\nThat's what I call a \\emp\\long \\emp\\lanky slinky!\n&&RestPose", '&&Explain\nDid you know that to qualify as a hurricane, a storm must develop winds in excess of 75 miles per hour!\n&&RestPose', "&&Explain\nDid you know that the left side of the brain is usually responsible for the control of speech!\\pau=1500\\\nI guess if you have the gift of gab, you're not in your \\emp\\right mind!\n&&RestPose", '&&Explain\nDid you know that the typical American eats two hundred and sixty-three eggs a year!\\pau=1500\\\nAnd they said that the \\emp\\Devilled \\emp\\Egg craze was coming to an end!\n&&RestPose', '&&Explain\nDid you know that hot water weighs more than cold!\\pau=1500\\\nI must be full of hot water.\n&&RestPose', '&&Explain\nDid you know that the average 6-month accumulation of barnacles on the hull of a ship can produce enough drag to force the vessel to burn 40 percent more fuel than normal when cruising!\\pau=1500\\\nFurther evidence that those little guys can sure be a drag!\n&&RestPose', '&&Explain\nDid you know that the male name Mark is from the Latin word for "hammer!"\\pau=1500\\\nNow.. Is the name Mark Hammer redundant?\n&&RestPose', '&&Explain\nDid you know that darts is the most popular sport played in Britain!\n&&RestPose', '&&Explain\nDid you know that according to Nielson Media Research, the average person watches television about 4 hours per day!\\pau=1500\\\nI would rather read a good book.. or try out a new \\emp\\banana recipe!\n&&RestPose', '&&Explain\nDid you know that on average 61,000 people are airborne over the United States at any given hour!\n&&RestPose', '&&Explain\nDid you know that it costs $6,400 to raise a medium-sized dog to the age of eleven!\n&&RestPose', "&&Explain\nDid you know that the average life span of an umbrella is one and a half years!\\pau=1500\\\nHumm.. That's interesting.. I never knew that umbrellas were alive.\n&&RestPose", '&&Explain\nDid you know that the motto for the Olympic Games is Citius..  Altius.. Fortius.. or translated.. Faster - Higher - Stronger!\n&&RestPose', '&&Explain\nDid you know that pork is the world\'s most widely-eaten meat!\\pau=1500\\\n\\chr="whisper"\\This is just a little secret between you, me and all other "non-swine"\n&&RestPose', "&&Explain\nDid you know that insects consume 10% of the world's food supply every year!\n&&RestPose", '&&Explain\nDid you know that the only continent without reptiles or snakes is Antarctica!\n&&RestPose', '&&Explain\nDid you know that many more crimes are committed in the hot summer months than in the cold winter months!\\pau=1500\\\nI guess \\emp\\that\'s why they call stollen goods "hot"!\n&&RestPose', '&&Explain\nDid you know that the temperature on the Moon falls to -261 degrees Fahrenheit during the night!\\pau=1000\\\n..So when planning your next trip to the moon.. bring \\emp\\something warm!\n&&RestPose', "&&Explain\nDid you know that in an average lifetime a person will walk the equivalent of three times around the world!\\pau=2000\\\n\\emp\\That's nothing! I can travel around the world in a matter of \\emp\\seconds over the internet!\n&&RestPose", '&&Explain\nDid you know that the largest meteorite crater in the world is in Winslow, Arizona at 4,150 feet across and 150 feet deep!\\pau=2000\\\nThat must have been a \\emp\\huge meteor,\\pau=500\\ right?\n&&RestPose', '&&Explain\nDid you know that an anteater is nearly 6 feet long, but its mouth is only an inch wide!\\pau=2000\\\nYou know what they say.. The closest friend is \\emp\\always the one with the \\emp\\closest mouth!\n&&RestPose', '&&Explain\nDid you know that when ants find food they lay down a chemical trail called a pheromone, so that other ants can find their way to the food source!\\pau=2000\\\nThose \\emp\\nasty pheromones have ruined \\emp\\many a picnic!\n&&RestPose', '&&Explain\nDid you know that many species of butterflies, just like birds, fly south for the winter!\n&&RestPose', '&&Explain\nDid you know that a rat can survive longer without water than a camel!\\pau=2000\\\nI guess that\'s why they came up with the phrase \\emp\\"dirty rat"!\n&&RestPose', '&&Explain\nDid you know that to make one pound of honey, bees must collect nectar from about two million flowers!\n&&RestPose', '&&Explain\nDid you know that in ancient Rome it was considered a sin to eat a woodpecker!\n&&RestPose', '&&Explain\nDid you know that the largest pumpkin weighed three hundred and seventy-seven pounds!\\pau=2000\\\nI think that might be the one \\spd=100\\\\emp\\I ate.\n&&RestPose', "&&Explain\nDid you know that the fastest of all fish in the sea is the swordfish, swimming near 68 miles per hour!\\pau=2000\\\nThat's one fish you wouldn't want to get in the way of!\n&&RestPose", "&&Explain\nDid you know that starfish have no brain!\\pau=2000\\\nI bet \\emp\\starfish don't know that.\n&&RestPose", '&&Explain\nDid you know that a herd of sixty cows is capable of producing a ton of milk in less than a day!\n&&RestPose', "&&Explain\nDid you know that the giant squid has the largest eyes in the world!\\pau=1500\\\nI bet they're not larger than \\emp\\my eyes when I see \\emp\\a banana!\n&&RestPose", '&&Explain\nDid you know that the average house fly has a life span of only two weeks!\\pau=2000\\\nI guess bothering people contributes to a \\emp\\short \\emp\\life-span!\n&&RestPose', "&&Explain\nDid you know that the ordinary house-fly beats its wings at a rate of two hundred times a second!\\pau=1000\\\nWell.. That's the buzz, anyway!\n&&RestPose", '&&Explain\nDid you know that Ernest Vincent Wright wrote a novel with over 50,000 words, none of which contained the letter "E"!\n&&RestPose', '&&Explain\nDid you know that a racehorse which has never won a race is referred to as a Maiden!\n&&RestPose', '&&Explain\nDid you know that in 1935 Jesse Owens broke 4 world records in 45 minutes!\n&&RestPose', '&&Explain\nDid you know that two out of three adults in the United Sates wear glasses at some time in their lives!\n&&RestPose', "&&Explain\nDid you know that a chameleon's tongue is twice the length of its body!\\pau=2000\\\nThose chameleons are \\emp\\always tripping over \\emp\\their tongues!\n&&RestPose", '&&Explain\nDid you know that the bombardier beetle defends itself by emitting a series of explosions!\n&&RestPose', '&&Explain\nDid you know that the fortune cookie was invented in 1916 by George Jung, a Los Angeles noodlemaker!\\pau=2000\\\nI bet he made a fortune with \\emp\\that product!\n&&RestPose', '&&Explain\nDid you know that anteaters prefer termites to ants!\n&&RestPose', '&&Explain\nDid you know that only 1 child in 20 are born on the day predicted by the doctor!\n&&RestPose', '&&Explain\nDid you know that gophers are hermits!\n&&RestPose', '&&Explain\nDid you know that over 50 billion aspirin tablets are taken worldwide each year!\\pau=2000\\\nJust thinking about that gives me a headache.\n&&RestPose', '&&Explain\nDid you know that a horse can sleep standing up!\n&&RestPose', '&&Explain\nDid you know that the grizzly bear is capable of running as fast as the average horse!\\pau=2000\\\nYeh.. but have you ever tried to \\emp\\saddle a grizzly?\n&&RestPose', '&&Explain\nDid you know that butterflies cannot fly if their body temperature is less than 86 degrees!\\pau=2000\\\nI guess a butterfly in less than 86 degree weather can be called a butter-walk!\n&&RestPose', "&&Explain\nDid you know that the pressure at the center of the sun is about 700 million tons per square inch!\\pau=2000\\\nYou know what they say.. If you can't stand the heat, get out from the center of the sun!\n&&RestPose", '&&Explain\nDid you know that the bat is the only mammal with the ability to fly!\\pau=1000\\\n\\emp\\Without the use of an airplane, of course.\n&&RestPose', "&&Explain\nDid you know that the hippopotamus' skin is an inch and a half thick!\n&&RestPose", '&&Explain\nDid you know that the United States Supreme Court once ruled Federal income tax unconstitutional!\\pau=2000\\\nNow those were the \\emp\\good \\emp\\old days!\n&&RestPose', '&&Explain\nDid you know that the heart of a giraffe is two feet long, and can weigh as much as twenty four pounds!\\pau=2000\\\nBoy those giraffes sure have a \\emp\\big heart!\n&&RestPose', '&&Explain\nDid you know that 33% of all potatoes sold are French Fried!\\pau=2000\\\nI wonder \\emp\\who fries the \\emp\\rest of \\emp\\them?\n&&RestPose', '&&Explain\nDid you know that the first CD produced in the United States was Bruce Springsteen\'s "Born in the USA"!\\pau=2000\\\nI guess Bruce set a \\emp\\new record!\n&&RestPose', '&&Explain\nDid you know that the cigarette lighter was invented prior to the match!\n&&RestPose', '&&Explain\nDid you know that Leonardo Da Vinci invented the scissors!\\pau=2000\\\nLeonardo was always on the \\emp\\cutting edge!\n&&RestPose', '&&Explain\nDid you know that a baby blue whale grows nine pounds an hour from the time it is born until it is full grown!\n&&RestPose', '&&Explain\nDid you know that group O is the most common blood group in the world, with more than 46% having that type. The type AB is found only in .7% of the population!\n&&RestPose', '&&Explain\nDid you know that the San Francisco cable cars are considered National Monuments in the United States!\n&&RestPose', '&&Explain\nDid you know that eighteen ounces of an average cola drink contain as much caffeine as a cup of coffee!\n&&RestPose', '&&Explain\nDid you know that in the city of Washington D.C., no building may be constructed taller than the Washington Monument!\n&&RestPose', '&&Explain\nDid you know that the names of all the continents end with the same letter they start with!\n&&RestPose', '&&Explain\nDid you know that our eyes are always the same size from birth, but our nose and ears never stop growing!\n&&RestPose', '&&Explain\nDid you know that babies are born without knee caps. They develop when the child reaches 2 to 6 years of age!\n&&RestPose', "&&Explain\nDid you know that Lincoln Logs were invented by Frank Lloyd Wright's son!\n&&RestPose", '&&Explain\nDid you know that Hong Kong is the city with the most Rolls Royce automobiles per capita!\n&&RestPose', '&&Explain\nDid you know that only 28% of Africa is wilderness!\n&&RestPose', '&&Explain\nDid you know that MTV (Music Television) first aired at 12:01 AM on August 1st, 1981. The first video was "Video Killed the Radio Star" by the Bugles!\n&&RestPose', '&&Explain\nDid you know that 38% of America is wilderness!\n&&RestPose', '&&Explain\nDid you know that 70% of all Americans have visited Disney-land or Disney World!\n&&RestPose', '&&Explain\nDid you know that 33% of all ice cream sold is vanilla!\n&&RestPose', '&&Explain\nDid you know that 33% of the land in the United States is owned by the federal government!\n&&RestPose', '&&Explain\nDid you know that Jupiter is bigger than all the other planets in our solar system combined!\n&&RestPose', '&&Explain\nDid you know that the cells which make up the antlers of a moose are the fastest growing animal cells in nature!\n&&RestPose', '&&Explain\nDid you know that there are about 1 million ants for every person in the world!\n&&RestPose', '&&Explain\nDid you know that most of the vitamin C in fruit is in the skin!\n&&RestPose', '&&Explain\nDid you know that the Pentagon in Washington, D.C. has five sides, five stories and five acres in the middle!\n&&RestPose', '&&Explain\nDid you know that California has more national parks than any other of the 50 United States!\n&&RestPose', '&&Explain\nDid you know that Californians consume more bottled water than any other product!\n&&RestPose', '&&Explain\nDid you know that Arizona was the last of the 48 contiguous states to enter the Union!\n&&RestPose', '&&Explain\nDid you know that the most common name in Italy is Mario Rossi!\n&&RestPose', '&&Explain\nDid you know that in ancient Rome it was considered a sign of leadership to be born with a crooked nose!\n&&RestPose', '&&Explain\nDid you know that Diet Coke was invented in 1982!\n&&RestPose', '&&Explain\nDid you know that Whitby, Ontario has more donut stores per capita than any other place in the world!\n&&RestPose', '&&Explain\nDid you know that a bowling pin only has to tilt 7.5 degrees in order to fall down!\n&&RestPose', '&&Explain\nDid you know that the parking meter was invented in North Dakota!\n&&RestPose', '&&Explain\nDid you know that the force of 1 billion people jumping at the same time is equal to 500 tons of TNT!\n&&RestPose', '&&Explain\nDid you know that blue and white are the most common school colors!\n&&RestPose', '&&Explain\nDid you know that Americans eat about 18 billion hot dogs a year!\n&&RestPose', '&&Explain\nDid you know that every year the sun loses 360 million tons!\n&&RestPose', '&&Explain\nDid you know that the bulls-eye on a dartboard must be 5 feet 8 inches off the ground!\n&&RestPose', '&&Explain\nDid you know that the game of monopoly has been sold in 19 different languages!\n&&RestPose', '&&Explain\nDid you know that the first Lifesaver flavor was peppermint!\n&&RestPose', '&&Explain\nDid you know that the avocado has the most calories of any fruit!\n&&RestPose', '&&Explain\nDid you know that France has the highest per capita consumption of cheese!\n&&RestPose', '&&Explain\nDid you know that the typical hen lays 19 dozen eggs per year!\n&&RestPose', '&&Explain\nDid you know that the giraffe has the highest blood pressure of any animal!\n&&RestPose', '&&Explain\nDid you know that the Library of Congress contains three hundred and twenty-seven miles of book shelves!\n&&RestPose', '&&Explain\nDid you know that light from the moon takes about a second and a half to reach Earth!\n&&RestPose', "&&Explain\nDid you know that the North Atlantic Deep Water Current is an oceanic 'river' that carries twenty times more water than all the rivers of the world put together!\n&&RestPose", '&&Explain\nDid you know that playing cards in India are round!\n&&RestPose', '&&Explain\nDid you know that a strand of spider web may be stronger than an equal diameter of steel!\n&&RestPose', '&&Explain\nDid you know that you need approximately 2,000 berries to make a pound of coffee!\n&&RestPose', "&&Explain\nDid you know that the temperature of the Earth's interior increases by 1 degree every 60 feet down!\n&&RestPose", '&&Explain\nDid you know that Galileo was the first man to suggest using a pendulum to run a clock!\n&&RestPose', '&&Explain\nDid you know that the female lion who does more than 90 percent of the hunting while the male performs the other 10%!\n&&RestPose', '&&Explain\nDid you know that Aristarchus, a Greek astronomer living about 200 B.C., reportedly was the first person to declare that the Earth revolved around the sun!\n&&RestPose', '&&Explain\nDid you know that the world consumes 1 billion gallons of petroleum a day!\n&&RestPose', '&&Explain\nDid you know that based on population, Chinese, Mandarin is the most commonly spoken language in the world. Spanish follows in second place and English is third!\n&&RestPose', '&&Explain\nDid you know that a jet or turbo-jet powered aircraft uses more fuel flying at 25,000 feet than 30,000 feet. The higher it flies, the thinner the atmosphere and the less atmospheric resistance it must buck!\n&&RestPose', '&&Explain\nDid you know that Tom Sawyer was the first novel written on a typewriter!\n&&RestPose', "&&Explain\nDid you know that more than 25 percent of the world's forests are in Siberia!\n&&RestPose", '&&Explain\nDid you know that a grasshopper can leap over obstacles 500 times its own height! In relation to its size, it has the greatest jumping ability of all animals.\n&&RestPose', '&&Explain\nDid you know that the purpose of the indentation at the bottom of a wine bottle is to strengthen the structure of the bottle and to trap the sediments in the wine!\n&&RestPose', '&&Explain\nDid you know that 7.5 million toothpicks can be created from a cord of wood!\n&&RestPose', '&&Explain\nDid you know that Hawaii is the most southern state in the United States!\n&&RestPose', '&&Explain\nDid you know that using satellite surveying techniques, scientists have determined that Los Angeles, California is moving east at a rate of one fifth of an inch per year!\n&&RestPose', '&&Explain\nDid you know that the moon weighs about 81 billion tons!\n&&RestPose', '&&Explain\nDid you know that baby mink are born blind and remain sightless for a month!\n&&RestPose', "&&Explain\nDid you know that with about 865 people per square mile, the island of Madeira is one of Europe's most densely populated regions!\n&&RestPose", '&&Explain\nDid you know that the female condor lays a single egg once every two years!\n&&RestPose', '&&Explain\nDid you know that pandas spend about 12 hours a day eating bamboo!\n&&RestPose', "&&Explain\nDid you know that even though only 7 percent of the world enjoys a temperate climate, nearly half of the world's people live in these areas!\n&&RestPose", '&&Explain\nDid you know that cork comes from the bark of trees!\n&&RestPose', '&&Explain\nDid you know that of all the ore dug in diamond mines, only one carat in every 23 tons proves to be a diamond!\n&&RestPose', '&&Explain\nDid you know that as of 1976 there was $77 billion worth of paper currency in circulation in the United States!\n&&RestPose', '&&Explain\nDid you know that a male emperor moth can detect and find a female of his species a mile away!\n&&RestPose', '&&Explain\nDid you know that the bottle-nosed whale can dive to a depth of 3,000 feet in two minutes!\n&&RestPose', '&&Explain\nDid you know that the human stomach lining replaces itself every three days!\n&&RestPose', '&&Explain\nDid you know that if you are right handed, you will tend to chew your food on your right side. If you are left handed, you will tend to chew your food on your left side!\n&&RestPose', "&&Explain\nDid you know that antlers and horns are not the same. Horns grow throughout an animal's life and are found on both the male and female of a species. Antlers, composed of a different chemical substance, are shed every year!\n&&RestPose", '&&Explain\nDid you know that the palms of the hands and soles of the feet contain more sweat glands than any other part of the body!\n&&RestPose', '&&Explain\nDid you know that Panama (because of a bend in the isthmus) is the only place in the world where one can see the sun rise on the Pacific Ocean and set on the Atlantic!\n&&RestPose', '&&Explain\nDid you know that the Olympic symbol is made up of five interlocking rings, standing for the continents of Europe, Asia, Africa, Australia, and America!\n&&RestPose', '&&Explain\nDid you know that if the moon were placed on the surface of the continental United States, it would extend from San Francisco to Cleveland (2,600 miles\n&&RestPose', "&&Explain\nDid you know that the average brain comprises 2 percent of a person's total body weight yet it requires 25 percent of all oxygen used by the body!\n&&RestPose", '&&Explain\nDid you know that a whip makes a cracking sound because its tip moves faster than the speed of sound!\n&&RestPose', '&&Explain\nDid you know that orchids have the smallest seeds. It takes more than 1.25 million seeds to weigh 1 gram!\n&&RestPose', '&&Explain\nDid you know that milk delivered to the store today was in the cow two days ago!\n&&RestPose', '&&Explain\nDid you know that there are more than 40,000 characters in Chinese script!\n&&RestPose', '&&Explain\nDid you know that the mudskipper is a fish that can actually walk on land!\n&&RestPose', '&&Explain\nDid you know that during a severe windstorm or rainstorm the Empire State Building may sway several feet to either side!\n&&RestPose', '&&Explain\nDid you know that Proxima Centauri is the closest star to Earth, but it is too small to be seen without a telescope!\n&&RestPose', '&&Explain\nDid you know that at race tracks, the favorite wins fewer than 30 percent of all horse races!\n&&RestPose', '&&Explain\nDid you know that less than 50 percent of American adults understand that the Earth orbits the sun yearly, according to a basic science survey!\n&&RestPose', '&&Explain\nDid you know that a day on the planet Mercury is twice as long as its year!\n&&RestPose', "&&Explain\nDid you know that the border between Canada and the U.S. is the world's longest frontier! It stretches 3,987 miles (6,416 kilometers).\n&&RestPose", "&&Explain\nDid you know that a rodent's teeth never stop growing. They are worn down by the animal's constant gnawing on bark, leaves and other vegetable matter!\n&&RestPose", '&&Explain\nDid you know that a rainbow can be seen only in the morning or late afternoon! It is a phenomenon that can occur only when the sun is 40 degrees or less above the horizon.\n&&RestPose', '&&Explain\nDid you know that a mated pair of rats can produce up to 15,000 babies in one year!\n&&RestPose', '&&Explain\nDid you know that more than one million Earths would fit inside the sun!\n&&RestPose', '&&Explain\nDid you know that the footprints left by the Apollo astronauts will not erode since there is no wind or water on the Moon!\n&&RestPose', '&&Explain\nDid you know that the condensed water vapor trail left behind by jets and rockets is called a con-trail!\n&&RestPose', '&&Explain\nDid you know that the skin of a human weighs nearly six pounds!\n&&RestPose', '&&Explain\nDid you know that the tails of comets point away from the sun whether the comet is approaching the sun or receding!\n&&RestPose', '&&Explain\nDid you know that the Penny is the only coin currently minted in the United States with a profile that faces to the right!\n&&RestPose', '&&Explain\nDid you know that the temperature on the Moon reaches 243 degrees Fahrenheit at midday on the lunar equator!\n&&RestPose', '&&Explain\nDid you know that the planet Pluto takes 248 Earth years to orbit the Sun!\n&&RestPose', '&&Explain\nDid you know that there are 4,300 known species of ladybug in the world!\n&&RestPose', "&&Explain\nDid you know that a newborn baby's head accounts for about one-quarter of it's entire weight!\n&&RestPose", '&&Explain\nDid you know that frogs never drink. They absorb water from their surroundings by osmosis!\n&&RestPose', '&&Explain\nDid you know that dry ice does not melt. It evaporates!\n&&RestPose', '&&Explain\nDid you know that bamboo is not a tree. It is a wood grass!\n&&RestPose', '&&Explain\nDid you know that more than 6,000 wrecked ships lay at the bottom of the Great Lakes!\n&&RestPose', '&&Explain\nDid you know that people are the only animals in the world who cry tears!\n&&RestPose', '&&Explain\nDid you know that green Tea has 50% more vitamin C then black tea!\n&&RestPose', "&&Explain\nDid you know that nearly 65 percent of America's aluminum cans are recycled!\n&&RestPose", '&&Explain\nDid you know that a queen bee may lay as many as 3,000 eggs in a single day!\n&&RestPose', '&&Explain\nDid you know that shrimp is the top seafood ordered in restaurants!\n&&RestPose', '&&Explain\nDid you know that more than three billion Christmas cards are sent annually in the United States!\n&&RestPose', '&&Explain\nDid you know that minus 40 degrees Celsius is exactly minus 40 degrees Fahrenheit. This is the only temperature for which the readings on both scales are equal!\n&&RestPose', '&&Explain\nDid you know that the pressure at the center of the Earth is 27,000 tons per square inch!\n&&RestPose', '&&Explain\nDid you know that a teaspoon of neutron star material weighs about 110 million tons!\n&&RestPose', '&&Explain\nDid you know that kilts are not native to Scotland. They originated in France!\n&&RestPose', '&&Explain\nDid you know that the average rainfall around the world is 40 inches per year!\n&&RestPose', '&&Explain\nDid you know that in 1915 the average annual family income in the United States was $687 a year!\n&&RestPose', '&&Explain\nDid you know that $1,000,000 in $1 bills would weigh approximately one ton!\n&&RestPose', '&&Explain\nDid you know that an espresso has less caffeine than a cup of coffee!\n&&RestPose', '&&Explain\nDid you know that Benjamin Franklin was first to suggest daylight savings time!\n&&RestPose', '&&Explain\nDid you know that the surface of the Dead Sea is 400 meters below the surface of the Mediterranean Sea, which is only 75 kilometers away!\n&&RestPose', "&&Explain\nDid you know that the world's largest exporter of sugar is Cuba!\n&&RestPose", '&&Explain\nDid you know that it takes 8.5 minutes for light to get from the sun to earth!\n&&RestPose', "&&Explain\nDid you know that the Atlantic Ocean covers the world's longest mountain range!\n&&RestPose", '&&Explain\nDid you know that New York City contains 920 kilometers of shoreline!\n&&RestPose', '&&Explain\nDid you know that 60% of all US potato products originate in Idaho!\n&&RestPose', '&&Explain\nDid you know that the city of Istanbul straddles two separate continents, Europe and Asia!\n&&RestPose', '&&Explain\nDid you know that at the nearest point , Russia and America are less than 4 kilometers apart!\n&&RestPose', '&&Explain\nDid you know that the furthest point from any ocean is in China!\n&&RestPose', '&&Explain\nDid you know that the Scandinavian capital, Stockholm, is build on nine islands connected by bridges!\n&&RestPose', '&&Explain\nDid you know that over the years the Niagara Falls have moved more than 11 kilometers from its original site!\n&&RestPose', "&&Explain\nDid you know that two-thirds of the world's gold is mined in South Africa!\n&&RestPose", '&&Explain\nDid you know that the volume of water in the Amazon river is greater than the next eight largest rivers in the world combined!\n&&RestPose', '&&Explain\nDid you know that New York was once called New Amsterdam!\n&&RestPose', '&&Explain\nDid you know that a woodchuck breathes only 10 times during hibernation!\n&&RestPose', '&&Explain\nDid you know that when hydrogen burns in the air, water is formed!\n&&RestPose', '&&Explain\nDid you know that pearls melt in vinegar!\n&&RestPose', '&&Explain\nDid you know that waves "break" when their height is more that seven-tenths of the depth of the water!\n&&RestPose', '&&Explain\nDid you know that red blood cells are produced in the bone marrow!\n&&RestPose', '&&Explain\nDid you know that the smallest bone in the body is the stirrup bone located in the ear!\n&&RestPose', '&&Explain\nDid you know that a human sheds a complete layer of skin every 4 weeks!\n&&RestPose', '&&Explain\nDid you know that from the age of thirty, humans gradually begin to shrink in size!\n&&RestPose', '&&Explain\nDid you know that the surface area of a human lung is equal to a tennis court!\n&&RestPose', '&&Explain\nDid you know that there is no single word given to describe the back of the knee!\n&&RestPose', '&&Explain\nDid you know that the average height of a man in the Middle Ages was five feet six inches!\n&&RestPose', '&&Explain\nDid you know that the large disk used in Tiddlywinks is called a Squidger!\n&&RestPose', '&&Explain\nDid you know that a soccer ball has 32 panels!\n&&RestPose', '&&Explain\nDid you know that there are over 10,000 golf courses in the United States!\n&&RestPose', '&&Explain\nDid you know that the average age of a female Olympic competitor is 20!\n&&RestPose', '&&Explain\nDid you know that Venus is the only planet that rotates clockwise!\n&&RestPose', '&&Explain\nDid you know that only one-fifth of the air we breathe is oxygen. Most of it is nitrogen!\n&&RestPose', '&&Explain\nDid you know that dairy products make-up about 29% of all food consumed by people in the United States!\n&&RestPose', '&&Explain\nDid you know that General Motors, in 1954, became the first corporation in the U.S. to have $1 billion in net income!\n&&RestPose', '&&Explain\nDid you know that the largest oil-producing field in the contiguous 48 states is in Taft, California!\n&&RestPose', '&&Explain\nDid you know that the largest man-made lake in the U.S. is Lake Mead, created by Hoover Dam!\n&&RestPose', '&&Explain\nDid you know that the first coast-to-coast telephone line was established in 1914!\n&&RestPose', '&&Explain\nDid you know that Jack is the most common name in nursery rhymes!\n&&RestPose', '&&Explain\nDid you know that a can of Spam is opened every 4 seconds!\n&&RestPose', '&&Explain\nDid you know that California is the most populous US state with a population of about 30 million!\n&&RestPose', '&&Explain\nDid you know that the common carp lives up to 25 years in the wild, and up to 40 years in captivity!\n&&RestPose', '&&Explain\nDid you know that snails have teeth!\n&&RestPose', '&&Explain\nDid you know that spiders have transparent blood!\n&&RestPose', '&&Explain\nDid you know that tug-of-war was an Olympic event from 1900 to 1929!\n&&RestPose', '&&Explain\nDid you know that jellyfish are comprised mostly of water.. more than 95 percent.. and have no brain, heart, or bones, and no actual eyes!\n&&RestPose', "&&Explain\nDid you know that the Statue of Liberty's index finger is 8 feet long, and it displays a fingernail measuring 13 by 10 inches!\n&&RestPose", '&&Explain\nDid you know that an elephant can reach speeds up to 25 miles per hours on an open stretch!\n&&RestPose', '&&Explain\nDid you know that there is approximately one chicken for every human being in the world!\n&&RestPose', '&&Explain\nDid you know that if the Nile River were stretched across the United States, it would run just about from New York to Los Angeles!\n&&RestPose', '&&Explain\nDid you know that 100,000 cubic feet of water pours over the Niagra Falls every second!\n&&RestPose', '&&Explain\nDid you know that bees can see ultraviolet light!\n&&RestPose', '&&Explain\nDid you know that the human body has 45 miles of nerves!\n&&RestPose', '&&Explain\nDid you know that the ostrich has only two toes, unlike most birds, which have three or four!\n&&RestPose', '&&Explain\nDid you know that it would take 27,000 spiders, each spinning a single web, to produce a pound of web!\n&&RestPose', '&&Explain\nDid you know that the smell of a skunk can be detected by a human a mile away!\n&&RestPose', "&&Explain\nDid you know that Britain's Buckingham Palace has a mere 600 rooms!\n&&RestPose", '&&Explain\nDid you know that lightning has hit the Empire State Building in New York as frequently as 12 times in 20 minutes. The building is hit by lightning about 500 times a year!\n&&RestPose', '&&Explain\nDid you know that clams have a row of eyes around their shells!\n&&RestPose', "&&Explain\nDid you know that the longest suspension bridge in the world is New York's Verrazano-Narrows, which is 4,260 feet long!\n&&RestPose", '&&Explain\nDid you know that elephants eat about 350 pounds of grass, leaves, bark and other vegetation every day!\n&&RestPose', '&&Explain\nDid you know that it takes a lobster approximately seven years to grow to be one pound!\n&&RestPose', '&&Explain\nDid you know that the flying snake of Java and Malaysia is able to flatten itself out like a ribbon and sail like a glider from tree to tree!\n&&RestPose', "&&Explain\nDid you know that glaciers occupy 5.8 million square miles, or 10 percent of the world's land surface, as in an area as large as South America!\n&&RestPose", '&&Explain\nDid you know that an ostrich egg can make eleven and a half omelets!\n&&RestPose', '&&Explain\nDid you know that it takes more than two days for a chick to break out of its shell!\n&&RestPose', '&&Explain\nDid you know that a hippopotamus can run faster than a man!\n&&RestPose')}
FUN_LOCK = threading.Lock()
FUN_LAST_INDEX = {"joke": -1, "thought": -1}


HOP_BY_HOP = {
    "connection", "proxy-connection", "keep-alive", "proxy-authenticate",
    "proxy-authorization", "te", "trailers", "transfer-encoding", "upgrade",
}


def tls_context() -> ssl.SSLContext:
    if VERIFY_TLS:
        return ssl.create_default_context()
    return ssl._create_unverified_context()


def direct_opener():
    """Never route proxy-to-server requests back through the Windows proxy."""
    return urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        urllib.request.HTTPSHandler(context=tls_context()),
    )


def direct_urlopen(request, timeout=TIMEOUT):
    return direct_opener().open(request, timeout=timeout)

STOCK_CACHE = {}
STOCK_LOCK = threading.RLock()
STOCK_COOLDOWN = 0.0


def fetch_stock_quote(symbol):
    """Get provider-reported quotes; never substitute made-up prices."""
    global STOCK_COOLDOWN
    symbol = symbol.upper().strip()
    if not re.fullmatch(r"[A-Z0-9^][A-Z0-9.^=\-]{0,24}", symbol):
        raise ValueError("Enter a ticker symbol such as AAPL, not a company name.")
    with STOCK_LOCK:
        now = time.monotonic()
        saved = STOCK_CACHE.get(symbol)
        if saved and now - saved[0] < 300:
            return saved[1]
        if now < STOCK_COOLDOWN:
            raise RuntimeError("Quote provider is rate limited. Try again later.")
        url = ("https://query1.finance.yahoo.com/v8/finance/chart/" +
               urllib.parse.quote(symbol, safe="") + "?interval=1d&range=5d")
        request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json"})
        try:
            with direct_urlopen(request, timeout=TIMEOUT) as response:
                data = json.loads(response.read(2_000_000).decode("utf-8"))
        except urllib.error.HTTPError as error:
            if error.code == 429:
                STOCK_COOLDOWN = now + 300
            raise RuntimeError("Quote provider unavailable (HTTP %d)." % error.code) from None
        chart = data.get("chart") or {}
        results = chart.get("result") or []
        if not results:
            raise RuntimeError("No quote was returned for " + symbol + ".")
        meta = results[0].get("meta") or {}
        price = meta.get("regularMarketPrice")
        previous = meta.get("chartPreviousClose", meta.get("previousClose"))
        stamp = meta.get("regularMarketTime")
        if not isinstance(price, (int, float)) or not math.isfinite(price) or not isinstance(stamp, (int, float)):
            raise RuntimeError("Quote response is missing a valid price or timestamp.")
        # chartPreviousClose is the close before the requested range, not
        # necessarily yesterday. Use the preceding daily close when available.
        timestamps = results[0].get("timestamp") or []
        indicators = results[0].get("indicators") or {}
        bars = (indicators.get("quote") or [{}])[0]
        closes = bars.get("close") or []
        market_day = datetime.datetime.fromtimestamp(stamp, datetime.timezone.utc).date()
        for bar_time, close in reversed(list(zip(timestamps, closes))):
            if datetime.datetime.fromtimestamp(bar_time, datetime.timezone.utc).date() < market_day and isinstance(close, (int, float)) and math.isfinite(close):
                previous = close
                break
        change = price - previous if isinstance(previous, (int, float)) and math.isfinite(previous) else None
        quote = {"symbol": symbol, "price": price, "change": change,
                 "percent": change / previous * 100 if change is not None and previous else None,
                 "volume": meta.get("regularMarketVolume"), "currency": meta.get("currency", ""),
                 "time": datetime.datetime.fromtimestamp(stamp, datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")}
        STOCK_CACHE[symbol] = (now, quote)
        return quote


def stock_fields(quote):
    """Native reader scans symbol, then time, price, change, percent, volume."""
    return [quote["symbol"], quote["time"], "%.2f" % quote["price"],
            "%+.2f" % quote["change"] if quote["change"] is not None else "N/A",
            "%+.2f%%" % quote["percent"] if quote["percent"] is not None else "N/A",
            str(quote["volume"]) if isinstance(quote["volume"], int) else "N/A"]



def decode_body(body: bytes, encoding: str | None) -> bytes:
    if not encoding:
        return body
    try:
        if "gzip" in encoding.lower():
            return gzip.decompress(body)
        if "deflate" in encoding.lower():
            try:
                return zlib.decompress(body)
            except zlib.error:
                return zlib.decompress(body, -zlib.MAX_WBITS)
    except Exception:
        log.warning("Could not decompress the response; forwarding it unchanged.")
    return body


def detect_charset(content_type: str, body: bytes) -> str:
    found = re.search(r"charset\s*=\s*[\"']?([^;\"'\s]+)", content_type, re.I)
    if found:
        return found.group(1)
    found = re.search(br"<\?xml[^>]+encoding=[\"']([^\"']+)", body[:300], re.I)
    if found:
        return found.group(1).decode("ascii", "ignore")
    found = re.search(br"<meta\b[^>]*charset\s*=\s*[\"']?([a-z0-9_-]+)", body[:8192], re.I)
    if found:
        return found.group(1).decode("ascii", "ignore")
    if body.startswith(b"\xff\xfe"):
        return "utf-16"
    try:
        body.decode("utf-8")
    except UnicodeDecodeError:
        return "cp1252"
    return "utf-8"


def clean_news_text(value: str) -> str:
    """Decode entities and repair UTF-8 text misread as Windows-1252."""
    value = html.unescape(value)
    for _ in range(2):
        if not any(token in value for token in ("Ã", "Â", "â€", "â€™", "â€œ")):
            break
        try:
            repaired = value.encode("cp1252").decode("utf-8")
        except (UnicodeEncodeError, UnicodeDecodeError):
            break
        if sum(repaired.count(marker) for marker in ("Ã", "Â", "â€")) >= sum(
                value.count(marker) for marker in ("Ã", "Â", "â€")):
            break
        value = repaired
    return value


def web_watching_text(value: str) -> str:
    """Use the ASCII subset of Windows-1252 for the old watcher parser."""
    value = clean_news_text(value).translate(str.maketrans({
        "‘": "'", "’": "'", "“": '"', "”": '"',
        "–": "-", "—": "-", "…": "...", "\u00a0": " ",
    }))
    return unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")


def make_legacy_compatible(body: bytes, content_type: str) -> tuple[bytes, str]:
    lowered = content_type.lower()
    is_xml = "xml" in lowered or "rss" in lowered or body.lstrip().startswith(b"<?xml")
    is_html = "text/html" in lowered

    if is_xml and CONVERT_XML:
        source_charset = detect_charset(content_type, body)
        try:
            text = body.decode(source_charset, "replace")
        except LookupError:
            text = body.decode("utf-8", "replace")
        text = text.lstrip("\ufeff")
        declaration = re.match(r"\s*<\?xml\b(.*?)\?>", text, flags=re.I | re.S)
        if declaration:
            original = declaration.group(0)
            if re.search(r"\bencoding\s*=", original, flags=re.I):
                updated = re.sub(r"\bencoding\s*=\s*([\"'])[^\"']+\1",
                                 'encoding="windows-1252"', original, count=1, flags=re.I)
            else:
                updated = original[:-2].rstrip() + ' encoding="windows-1252"?>'
            text = text[:declaration.start()] + updated + text[declaration.end():]
        else:
            text = '<?xml version="1.0" encoding="windows-1252"?>\n' + text
        body = text.encode("cp1252", "xmlcharrefreplace")
        base_type = content_type.split(";", 1)[0] or "application/xml"
        content_type = f"{base_type}; charset=windows-1252"

    if is_html:
        source_charset = detect_charset(content_type, body)
        try:
            text = body.decode(source_charset, "replace").lstrip("\ufeff")
            if REMOVE_SCRIPTS:
                text = re.sub(r"<script\b[^>]*>.*?</script\s*>", "", text, flags=re.I | re.S)
            head = text[:8192]
            if re.search(r"<meta\b[^>]*charset\s*=", head, flags=re.I):
                head = re.sub(r"(<meta\b[^>]*?charset\s*=\s*[\"']?)[a-z0-9_-]+",
                              r"\g<1>windows-1252", head, flags=re.I)
                text = head + text[8192:]
            else:
                text = re.sub(r"<head\b[^>]*>",
                              lambda m: m.group(0) + '<meta charset="windows-1252">',
                              text, count=1, flags=re.I)
            body = text.encode("cp1252", "xmlcharrefreplace")
            content_type = "text/html; charset=windows-1252"
        except (LookupError, UnicodeError):
            pass

    return body, content_type


class NoRedirect(urllib.request.HTTPRedirectHandler):
    pass


class ProxyHandler(socketserver.StreamRequestHandler):

    def send_current_model(self, parsed):
        """Show an NCEP model image, with its actual cycle instead of an invented date."""
        model = parsed.path.strip('/').split('/')[0].lower()
        areas = {'gfs': 'namer', 'nam': 'namer', 'rap': 'conus'}
        area = areas[model]
        query = urllib.parse.parse_qs(parsed.query)
        products = {'500_vort_ht', '850_temp_ht'}
        if model == 'rap':
            products.add('2m_temp_10m_wnd')
        else:
            products.add('10m_wnd_precip')
        product = query.get('product', ['500_vort_ht'])[0]
        if product not in products:
            product = '500_vort_ht'
        hours = (0, 3, 6, 9, 12) if model == 'rap' else (0, 6, 12, 18, 24, 36, 48)
        try:
            hour = int(query.get('hour', ['12' if model != 'rap' else '3'])[0])
        except ValueError:
            hour = hours[0]
        if hour not in hours:
            hour = hours[0]
        guide = ('https://mag.ncep.noaa.gov/model-guidance-model-parameter.php?'
                 + urllib.parse.urlencode({'area': area.upper(),
                                            'group': 'Model Guidance', 'model': model.upper()}))
        try:
            req = urllib.request.Request(guide, headers={'User-Agent': 'Mozilla/5.0'})
            with direct_urlopen(req, timeout=min(TIMEOUT, 20)) as response:
                source = response.read(1500000).decode('utf-8', 'replace')
            cycles = []
            for month, day, year, cycle in re.findall(
                    r'(\d{2})/(\d{2})/(\d{4})\s+(\d{2})\s*UTC', source, re.I):
                moment = datetime.datetime(int(year), int(month), int(day), int(cycle),
                                           tzinfo=datetime.timezone.utc)
                if moment not in cycles:
                    cycles.append(moment)
            cycles.sort(reverse=True)
            now = datetime.datetime.now(datetime.timezone.utc)
            # A cached, old MAG page must never make a 2013 chart look current.
            cycles = [c for c in cycles if datetime.timedelta(0) <= now - c <=
                      datetime.timedelta(hours=8 if model == 'rap' else 48)]
            if not cycles:
                raise ValueError('No recent model cycle reported by NOAA')
            payload = None
            chosen = None
            for cycle in cycles[:4]:
                h = f'{cycle.hour:02d}'
                filename = f'{model}_{area}_{hour:03d}_{product}.gif'
                folder = f'{area}/{product}/' if model == 'gfs' else ''
                url = f'https://mag.ncep.noaa.gov/data/{model}/{h}/{folder}{filename}'
                try:
                    with direct_urlopen(urllib.request.Request(
                            url, headers={'User-Agent': 'Mozilla/5.0'}),
                            timeout=min(TIMEOUT, 20)) as response:
                        candidate = response.read(6000000)
                    if candidate[:6] in (b'GIF87a', b'GIF89a'):
                        payload, chosen = candidate, cycle
                        break
                except (OSError, urllib.error.HTTPError):
                    continue
            if payload is None:
                raise ValueError('NOAA has no image for the requested product and hour')
            links = []
            for p in sorted(products):
                links.append('<a href="?'+urllib.parse.urlencode({'product': p, 'hour': hour})
                             +'">'+html.escape(p)+'</a>')
            hour_links = []
            for h in hours:
                hour_links.append('<a href="?'+urllib.parse.urlencode({'product': product, 'hour': h})
                                  +'">+'+str(h)+'h</a>')
            # Keep the image in memory so legacy browsers receive a normal HTTP GIF.
            key = hashlib.sha256(payload).hexdigest()[:32]
            with MODEL_IMAGES_LOCK:
                if len(MODEL_IMAGES) >= 12:
                    MODEL_IMAGES.pop(next(iter(MODEL_IMAGES)))
                MODEL_IMAGES[key] = payload
            body = ('<div style="font-family:Arial;max-width:1300px">'
                    f'<h2>Current NOAA {model.upper()} model - {area.upper()}</h2>'
                    f'<p>Model run: <b>{chosen:%Y-%m-%d %H}:00 UTC</b>; '
                    f'forecast hour: <b>+{hour}</b>; product: <b>{html.escape(product)}</b>.</p>'
                    '<p>Product: '+' | '.join(links)+'</p><p>Forecast hour: '
                    +' | '.join(hour_links)+'</p>'
                    f'<img alt="NOAA {model.upper()} {html.escape(product)}" '
                    f'src="/model_image?key={key}" style="max-width:100%">'
                    f'<p><a href="{parsed.path}?archive=1">View 2013 Unisys archive</a> | '
                    f'<a href="{html.escape(guide, quote=True)}">NOAA model guidance</a></p></div>')
            self.send_html(200, 'OK', self.weather_shell(body))
        except (OSError, ValueError, urllib.error.HTTPError) as exc:
            log.warning('CURRENT MODEL %s unavailable: %s', model, exc)
            self.send_html(502, 'Model image unavailable', self.weather_shell(
                f'<h2>Current {model.upper()} chart unavailable</h2><p>{html.escape(str(exc))}</p>'
                f'<p><a href="{parsed.path}?archive=1">View labeled 2013 archive</a></p>'))

    def send_live_weather_image(self, kind):
        """Proxy current public weather imagery; never substitute archived 2013 maps."""
        sources = {
            "satellite": "https://cdn.star.nesdis.noaa.gov/GOES19/ABI/CONUS/GEOCOLOR/1250x750.jpg",
            "radar": "https://radar.weather.gov/ridge/standard/CONUS_loop.gif",
            "surface": "https://www.wpc.ncep.noaa.gov/sfc/namussfcwbg.gif",
        }
        source = sources.get(kind)
        if not source:
            self.send_simple(404, "Not Found", "Live weather image not found.")
            return
        req = urllib.request.Request(source, headers={"User-Agent": "CyberBuddyClassicProxy/5.5.52"})
        try:
            with direct_urlopen(req, timeout=min(TIMEOUT, 25)) as response:
                ctype = response.headers.get("Content-Type", "image/jpeg").split(";", 1)[0]
                payload = response.read(10 * 1024 * 1024 + 1)
            if len(payload) > 10 * 1024 * 1024 or ctype not in {"image/jpeg", "image/png", "image/gif", "image/webp"}:
                raise ValueError("Unexpected live map response")
        except (OSError, ValueError, urllib.error.HTTPError) as exc:
            log.warning("LIVE WEATHER IMAGE unavailable kind=%s: %s", kind, exc)
            self.send_simple(502, "Bad Gateway", "Current weather map temporarily unavailable. Click Refresh to try again.")
            return
        self.safe_write((f"HTTP/1.0 200 OK\r\nContent-Type: {ctype}\r\n"
                         "Cache-Control: no-cache, no-store, must-revalidate, max-age=0\r\n"
                         "Pragma: no-cache\r\nExpires: 0\r\n"
                         f"Content-Length: {len(payload)}\r\nConnection: close\r\n\r\n").encode("ascii"))
        self.safe_write(payload)

    def send_live_weather_maps(self, original_url):
        """Interactive current map viewer behind the original Unisys-style local routes."""
        path = urllib.parse.urlsplit(original_url).path.lower()
        if "/radar/" in path:
            selected = "radar"
        elif "/surface/" in path or path.endswith("/analyses.php"):
            selected = "surface"
        else:
            selected = "satellite"

        labels = {
            "satellite": "Satellite Images - GOES-19 GeoColor",
            "radar": "Radar Data - NOAA CONUS Loop",
            "surface": "Surface Analysis - NOAA/WPC",
        }
        routes = {
            "satellite": "/satellite/index.php",
            "radar": "/radar/index.php",
            "surface": "/surface/index.php",
        }
        now = datetime.datetime.now().astimezone()
        stamp = now.strftime("%d/%m/%Y %H:%M:%S %Z")
        nav = " | ".join(
            f'<a href="{routes[key]}">{html.escape(label.split(" - ",1)[0])}</a>'
            for key, label in labels.items())
        content = (
            '<div style="font-family:Arial,Helvetica,sans-serif;max-width:1280px">'
            '<h2>Current Interactive Weather Maps</h2>'
            f'<p><b>Today:</b> {html.escape(stamp)} &nbsp; <b>Product:</b> {html.escape(labels[selected])}</p>'
            f'<p>{nav} | <a href="{routes[selected]}?refresh={int(time.time())}">Refresh now</a></p>'
            '<p>This viewer requests a public weather image when opened. '
            'No January 2013 image is substituted here. The source image timestamp is not verified.</p>'
            f'<p><img id="liveWeatherMap" src="/weather_live_image?kind={selected}&t={int(time.time())}" '
            'alt="Current weather map" style="max-width:100%;height:auto;border:1px solid #666"></p>'
            '<p><button type="button" onclick="refreshWeatherMap()">Refresh image</button> '
            '<label>Auto refresh: <select id="refreshRate" onchange="setWeatherTimer()">'
            '<option value="0">Off</option><option value="60">1 minute</option>'
            '<option value="300" selected>5 minutes</option><option value="600">10 minutes</option>'
            '</select></label> <span id="refreshStatus"></span></p>'
            '<script>'
            'var weatherTimer=null;'
            'function refreshWeatherMap(){var i=document.getElementById("liveWeatherMap");'
            f'i.src="/weather_live_image?kind={selected}&t="+Date.now();'
            'document.getElementById("refreshStatus").innerHTML="Requested: "+new Date().toLocaleString();}'
            'function setWeatherTimer(){if(weatherTimer){clearInterval(weatherTimer);weatherTimer=null;}'
            'var s=parseInt(document.getElementById("refreshRate").value,10);'
            'if(s>0){weatherTimer=setInterval(refreshWeatherMap,s*1000);}'
            'document.getElementById("refreshStatus").innerHTML=s>0?"Auto refresh enabled":"Auto refresh off";}'
            'setWeatherTimer();'
            '</script>'
            '<p><small>Satellite: NOAA/NESDIS GOES-19. Radar: NOAA/NWS. Surface: NOAA/WPC. '
            'The displayed date follows this computer clock and does not certify the image date.</small></p>'
            '</div>')
        self.send_html(200, "OK", self.weather_shell(content))
        log.info("LIVE WEATHER MAP kind=%s date=%s", selected, stamp)

    def send_local_weather_file(self, parsed):
        """Serve a downloaded weather.unisys.com file without contacting Wayback."""
        rel = urllib.parse.unquote(parsed.path or "/index.php").lstrip("/") or "index.php"
        candidate = (WEATHER_SITE / rel).resolve()
        try:
            candidate.relative_to(WEATHER_SITE.resolve())
        except ValueError:
            self.send_simple(403, "Forbidden", "Invalid local weather path.")
            return True
        if candidate.is_dir():
            candidate = candidate / "index.php"
        if not candidate.is_file():
            return False
        suffix = candidate.suffix.lower()
        mime = {".css":"text/css", ".js":"application/javascript", ".png":"image/png",
                ".gif":"image/gif", ".jpg":"image/jpeg", ".jpeg":"image/jpeg",
                ".webp":"image/webp", ".ico":"image/x-icon", ".svg":"image/svg+xml"}.get(suffix)
        payload = candidate.read_bytes()
        if mime and not mime.startswith("text/") and "javascript" not in mime:
            self.safe_write((f"HTTP/1.0 200 OK\r\nContent-Type: {mime}\r\nContent-Length: {len(payload)}\r\n"
                             "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").encode("ascii"))
            self.safe_write(payload)
            return True
        try:
            page = payload.decode("utf-8")
        except UnicodeDecodeError:
            page = payload.decode("cp1252", "replace")
        if suffix in {".php", ".html", ".htm", ""}:
            # The mirror downloader rewrites most links; this catches any absolute Unisys links left over.
            page = re.sub(r'(?i)https?://(?:www\.)?weather\.unisys\.com(?P<path>/[^"\'<> ]*)',
                          lambda m: m.group("path"), page)
            # Archive files are static; keep their capture date clear and
            # provide a live forecast search on every mirrored HTML page.
            notice = ('<div style="background:#fff2cf;border:1px solid #875;padding:7px;'
                      'font:14px Arial">2013 Unisys Weather archive. Charts below are historical. '
                      '<form method="get" action="/forecast.php" style="display:inline">'
                      'Current forecast: <input name="Name" size="17" '
                      'title="City, ZIP code or airport">'
                      '<input type="submit" value="Search"></form> '
                      '<a href="/satellite/index.php">Current satellite</a> | '
                      '<a href="/radar/index.php">Current radar</a> | '
                      '<a href="/surface/index.php">Current surface</a> | '
                      '<a href="/gfs/index.php">Current GFS</a> | '
                      '<a href="/nam/index.php">Current NAM</a> | '
                      '<a href="/rap/index.php">Current RAP</a><br>'
                      '<small>Unofficial Unisys weather continuation by Arthur Tube, '
                      'created on September 26, 2026. Current reports: Open-Meteo. '
                      'Weather maps and model charts: NOAA. '
                      '2013 archive pages are labeled separately.</small></div>')
            page = re.sub(r'<body\b[^>]*>', lambda m: m.group(0) + notice,
                          page, count=1, flags=re.I)
            page = re.sub(r'(<form\b[^>]*\baction\s*=\s*)(["\'])([^"\']*forecast\.(?:php|cgi)[^"\']*)\2',
                          lambda m: m.group(1) + m.group(2) + '/forecast.php' + m.group(2),
                          page, flags=re.I)
            self.send_html(200, "OK", page)
        else:
            data = page.encode("utf-8")
            ctype = mime or "text/plain; charset=utf-8"
            self.safe_write((f"HTTP/1.0 200 OK\r\nContent-Type: {ctype}\r\nContent-Length: {len(data)}\r\n"
                             "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").encode("ascii"))
            self.safe_write(data)
        return True

    def send_weather_archive(self, original_url):
        """Serve a fixed-date Wayback snapshot through this local HTTP proxy."""
        allowed_hosts = {"weather.unisys.com", "www.weather.unisys.com", "www.unisys.com",
                         "unisys.com", "lwf.ncdc.noaa.gov", "www.cpc.noaa.gov",
                         "oceanservice.noaa.gov", "www.lib.noaa.gov", "www.oar.noaa.gov",
                         "www.esrl.noaa.gov", "esrl.noaa.gov"}
        original = urllib.parse.urlsplit(original_url)
        if (original.scheme != "http" or original.hostname not in allowed_hosts or
                original.port not in (None, 80) or original.username or original.password or
                len(original_url) > 2048):
            self.send_simple(400, "Bad Request", "Archive address is not allowed.")
            return
        archived = "https://web.archive.org/web/20130124124126id_/" + original_url
        req = urllib.request.Request(archived, headers={"User-Agent": "CyberBuddyClassicProxy/5.5.48"})
        try:
            with direct_urlopen(req, timeout=min(TIMEOUT, 15)) as response:
                if urllib.parse.urlsplit(response.geturl()).hostname != "web.archive.org":
                    raise ValueError("Archive redirected outside the Wayback Machine")
                content_type = response.headers.get("Content-Type", "text/html")
                payload = response.read(2 * 1024 * 1024 + 1)
            if len(payload) > 2 * 1024 * 1024:
                raise ValueError("Archived page is too large")
        except (OSError, ValueError, urllib.error.HTTPError) as exc:
            log.warning("WEATHER ARCHIVE unavailable for %s: %s", original_url, exc)
            # Offline/local fallback: keep the classic weather interface usable
            # even when the Wayback Machine is temporarily unavailable.
            if original.hostname in {"weather.unisys.com", "www.weather.unisys.com"}:
                try:
                    chrome_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                               "weather_chrome.html")
                    with open(chrome_path, "r", encoding="utf-8", errors="replace") as fh:
                        fallback = fh.read()
                    notice = (
                        '<div style="margin:8px;padding:8px;border:1px solid #777;'
                        'background:#fff4cc;font-family:Arial,Helvetica,sans-serif">'
                        '<b>Interactive local copy</b> &mdash; the 2013 archived page is '
                        'temporarily unavailable. Navigation remains available locally, and '
                        'weather/map pages use current data where supported.</div>')
                    if re.search(r"<body\b[^>]*>", fallback, flags=re.I):
                        fallback = re.sub(r"(<body\b[^>]*>)", r"\1" + notice, fallback,
                                          count=1, flags=re.I)
                    else:
                        fallback = notice + fallback
                    self.send_html(200, "OK", fallback)
                    return
                except OSError as fallback_exc:
                    log.warning("WEATHER local fallback unavailable: %s", fallback_exc)
            self.send_simple(502, "Bad Gateway",
                             "Archived page temporarily unavailable and no local copy was found.")
            return
        if "html" not in content_type.lower():
            mime = content_type.split(";", 1)[0]
            if mime not in {"image/png", "image/gif", "image/jpeg", "image/webp", "text/css"}:
                self.send_simple(415, "Unsupported Media Type", "Archived file type unavailable.")
                return
            self.safe_write(f"HTTP/1.0 200 OK\r\nContent-Type: {mime}\r\n"
                            f"Content-Length: {len(payload)}\r\nConnection: close\r\n\r\n".encode("ascii"))
            self.safe_write(payload)
            return
        charset_match = re.search(r"charset=([a-zA-Z0-9_-]+)", content_type, re.I)
        charset = charset_match.group(1) if charset_match else "cp1252"
        try:
            page = payload.decode(charset)
        except (LookupError, UnicodeError):
            page = payload.decode("cp1252", "replace")
        page = re.sub(r"<script\b[^>]*>.*?</script\s*>", "", page, flags=re.I | re.S)
        page = re.sub(r"<iframe\b[^>]*>.*?</iframe\s*>", "", page, flags=re.I | re.S)
        page = re.sub(r"\s+on[a-z]+\s*=\s*(['\"]).*?\1", "", page, flags=re.I | re.S)
        def local_link(match):
            url = html.unescape(match.group(3).strip())
            resolved = urllib.parse.urljoin(original_url, url)
            target = urllib.parse.urlsplit(resolved)
            if target.scheme == "http" and target.hostname in {"weather.unisys.com", "www.weather.unisys.com"}:
                local = target.path or "/index.php"
                if target.query:
                    local += "?" + target.query
                if target.fragment:
                    local += "#" + target.fragment
                return match.group(1) + match.group(2) + html.escape(local, quote=True) + match.group(2)
            if target.scheme == "http" and target.hostname in allowed_hosts:
                local = "/weather_archive?url=" + urllib.parse.quote(resolved, safe="")
                return match.group(1) + match.group(2) + html.escape(local, quote=True) + match.group(2)
            if url.lower().startswith(("javascript:", "data:")):
                return match.group(1) + match.group(2) + "#" + match.group(2)
            return match.group(0)
        page = re.sub(r"(\b(?:href|src)\s*=\s*)(['\"])(.*?)\2", local_link, page, flags=re.I | re.S)
        # Forecast forms on archived pages must submit to the live local
        # endpoint; the original 2013 CGI/PHP scripts no longer run.
        page = re.sub(r"(<form\b[^>]*\baction\s*=\s*)(['\"])([^'\"]*forecast\.(?:php|cgi)[^'\"]*)\2",
                      lambda m: m.group(1) + m.group(2) + "/forecast.php" + m.group(2),
                      page, flags=re.I)
        live_search = ('<div style="background:#ffe8c4;padding:8px;border:1px solid #777;">'
                       '<b>Current weather:</b> '
                       '<form method="get" action="/forecast.php" style="display:inline;">'
                       '<input type="text" name="Name" size="20" '
                       'title="City, ZIP code or airport">'
                       '<input type="submit" value="Get Forecast"></form> '
                       '<a href="/forecast.php">Weather Home</a></div>')
        page = re.sub(r"<body\b[^>]*>", lambda m: m.group(0) + live_search,
                      page, count=1, flags=re.I)
        page = re.sub(r"<meta\b[^>]*charset\s*=[^>]*>", "", page, flags=re.I)
        page = re.sub(r"<head\b[^>]*>", lambda m: m.group(0) + '<meta charset="windows-1252">',
                      page, count=1, flags=re.I)
        self.send_html(200, "OK", page)
        log.info("WEATHER ARCHIVE local -> %s", original_url)

    def send_weather_asset(self, name):
        """Serve only images and the stylesheet supplied with the recreation."""
        allowed = {"WMAX.css", "Unisys_logo.gif", "GO.png", "Icon.png", "setup.png", "Sun.png",
                   "Clouds.png", "Foggy.png", "Rain.png", "Snow.png",
                   "Thunder.png", "PartlyCloudy.png", "Moon.png", "MoonCloudy.png",
                   "Sun-s.png", "Clouds-s.png", "Foggy-s.png", "Rain-s.png",
                   "Snow-s.png", "Thunder-s.png", "PartlyCloudy-s.png",
                   "Moon-s.png", "MoonCloudy-s.png"}
        if name not in allowed:
            self.send_simple(404, "Not Found", "Weather asset not found.")
            return
        payload = (WEATHER_ASSETS / name).read_bytes()
        content_type = ("text/css; charset=windows-1252" if name.endswith(".css") else
                        "image/gif" if name.endswith(".gif") else "image/png")
        self.safe_write(f"HTTP/1.0 200 OK\r\nContent-Type: {content_type}\r\n"
                        f"Content-Length: {len(payload)}\r\nConnection: close\r\n\r\n".encode("ascii"))
        self.safe_write(payload)

    def weather_shell(self, content, icon="PartlyCloudy.png"):
        """Put live weather inside the actual downloaded 2013 Unisys forecast page."""
        template = WEATHER_SITE / "forecast.php"
        if template.exists():
            try:
                page = template.read_text(encoding="windows-1252", errors="replace")
                # Match the archived forecast's white content and quiet sidebar.
                # Scope this to the live forecast; the other mirrored pages keep
                # their original downloaded styles.
                forecast_style = ("<style type=\"text/css\">"
                                  "#content{background:#fff;border-color:#fff;}"
                                  "#content .drop table,#content .drop td{background:#fff;}"
                                  "#leftside ul.avmenu li a{background:#fff;border:0;"
                                  "font-weight:normal;font-size:13px;}"
                                  "#leftside ul.avmenu li a.purple{background:#eee;"
                                  "color:#d31145;font-size:14px;font-weight:bold;}"
                                  "</style>")
                page = page.replace('</head>', forecast_style + '</head>', 1)
                marker = '<div id="content">'
                start = page.lower().find(marker.lower())
                # The archived forecast response embeds a second HTML document in
                # #content.  Resume at the original clearboth/footer after it.
                suffix_match = re.search(r'<div class=["\']clearboth["\']',
                                         page[start + len(marker):], re.I) if start >= 0 else None
                if start >= 0 and suffix_match:
                    body_start = start + len(marker)
                    suffix_start = body_start + suffix_match.start()
                    return page[:body_start] + content + page[suffix_start:]
            except OSError as exc:
                log.warning("Could not use archived forecast.php as weather shell: %s", exc)
        # Fallback for installations that do not yet have weather_site/forecast.php.
        chrome = (ROOT / "weather_chrome.html").read_text(encoding="utf-8")
        return ('<!DOCTYPE html><html><head><meta http-equiv="Content-Type" '
                'content="text/html; charset=windows-1252"><title>Unisys Weather</title>'
                '<link rel="stylesheet" href="/weather_assets/WMAX.css"></head><body>'
                + chrome + '<div id="content">' + content +
                '</div><div class="clearboth">&nbsp;</div></div></body></html>')

    def safe_write(self, data: bytes) -> bool:
        try:
            self.wfile.write(data)
            return True
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, OSError):
            log.debug("Legacy client closed the connection before the response was complete")
            return False

    def read_request(self):
        line = self.rfile.readline(65537)
        if not line:
            return None
        if len(line) > 65536:
            raise ValueError("Request line is too long")
        # Some legacy clients send literal spaces in the request target
        # (e.g. /forecast.cgi/Caldas Novas) instead of %20 or +.
        request_line = line.decode("iso-8859-1").strip()
        target_and_method, version = request_line.rsplit(" ", 1)
        method, target = target_and_method.split(" ", 1)
        headers = http.client.parse_headers(self.rfile)
        length = int(headers.get("Content-Length", "0") or "0")
        if length > MAX_BODY_MB * 1024 * 1024:
            raise ValueError("Request body exceeds the configured size limit")
        body = self.rfile.read(length) if length else None
        return method.upper(), target, version, headers, body

    def send_simple(self, status: int, reason: str, text: str):
        payload = text.encode("cp1252", "replace")
        self.safe_write(f"HTTP/1.0 {status} {reason}\r\n".encode("ascii"))
        self.safe_write(b"Content-Type: text/plain; charset=windows-1252\r\n")
        self.safe_write(f"Content-Length: {len(payload)}\r\nConnection: close\r\n\r\n".encode("ascii"))
        self.safe_write(payload)

    def send_html(self, status: int, reason: str, text: str):
        payload = text.encode("cp1252", "xmlcharrefreplace")
        self.safe_write(f"HTTP/1.0 {status} {reason}\r\n".encode("ascii"))
        self.safe_write(b"Content-Type: text/html; charset=windows-1252\r\n")
        self.safe_write(b"Cache-Control: no-cache, no-store, must-revalidate, max-age=0\r\n")
        self.safe_write(b"Pragma: no-cache\r\n")
        self.safe_write(b"Expires: Thu, 01 Jan 1970 00:00:00 GMT\r\n")
        self.safe_write(f"Content-Length: {len(payload)}\r\nConnection: close\r\n\r\n".encode("ascii"))
        self.safe_write(payload)

    def send_xml(self, status: int, reason: str, text: str):
        payload = text.encode("cp1252", "xmlcharrefreplace")
        self.safe_write(f"HTTP/1.0 {status} {reason}\r\n".encode("ascii"))
        self.safe_write(b"Content-Type: text/xml; charset=windows-1252\r\n")
        self.safe_write(b"Cache-Control: no-cache\r\n")
        self.safe_write(f"Content-Length: {len(payload)}\r\nConnection: close\r\n\r\n".encode("ascii"))
        self.safe_write(payload)

    def fetch_news_items(self, feed_url=None):
        feed_url = feed_url or CFG.get(
            "web_watching",
            "news_feed",
            fallback="https://moxie.foxnews.com/google-publisher/latest.xml",
        )
        if (urllib.parse.urlsplit(feed_url).hostname or "").lower().endswith("globo.com"):
            feed_url = "https://moxie.foxnews.com/google-publisher/latest.xml"
        limit = CFG.getint("web_watching", "max_items", fallback=20)
        request = urllib.request.Request(
            feed_url,
            headers={"User-Agent": "CyberBuddyClassicProxy/2.7"},
        )
        opener = direct_opener()
        last_error = None
        for attempt in range(3):
            try:
                with opener.open(request, timeout=TIMEOUT) as response:
                    feed_body = response.read(MAX_BODY_MB * 1024 * 1024 + 1)
                if len(feed_body) > MAX_BODY_MB * 1024 * 1024:
                    raise ValueError("News feed exceeds the configured size limit")
                root = ET.fromstring(feed_body)
                return root.findall(".//item")[:max(1, limit)]
            except (ET.ParseError, http.client.IncompleteRead) as error:
                last_error = error
                log.warning("Incomplete RSS; retry %d/3", attempt + 1)
                time.sleep(0.35)
        raise last_error

    def send_legacy_news_page(self, provider=None):
        configured_feed = CFG.get("web_watching", "news_feed", fallback="https://moxie.foxnews.com/google-publisher/latest.xml")
        feed_url = ("https://moxie.foxnews.com/google-publisher/latest.xml" if provider == "fox" else configured_feed)
        items = self.fetch_news_items(feed_url)
        source = "English News"
        rows = []
        for item in items:
            title = web_watching_text((item.findtext("title") or "Untitled news").strip())
            description = (item.findtext("description") or "").strip()
            description = re.sub(r"<[^>]+>", " ", description)
            description = web_watching_text(description)
            description = re.sub(r"\s+", " ", description).strip()
            link = (item.findtext("link") or "").strip()
            rows.append(
                "<li><b>" + html.escape(title, quote=False) + "</b>"
                + ("<br>" + html.escape(description, quote=False) if description else "")
                + ("<br><a href=\"" + html.escape(urllib.parse.quote(link, safe=":/?#[]@!$&'()*+,;=%-._~"), quote=True) + "\">Read article</a>" if link else "")
                + "</li>"
            )
        page = (
            "<!DOCTYPE html><html><head>"
            "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">"
            "<title>" + source + "</title></head><body>"
            "<h1>" + source + " headlines</h1>"
            "<ol>" + "".join(rows) + "</ol>"
            "</body></html>"
        )
        self.send_html(200, "OK", page)
        log.info("PAGE CHECK -> 200")

    def send_cyberbuddy_news3(self):
        """Return current RSS headlines in CyberBuddy's original command format."""
        categories = self.fetch_cyberbuddy_news_categories()
        # Keep command ampersands unescaped. A headline is spoken once.
        intro = "Here are some headlines."
        lines = ["&&Read", intro + "\\Pau=800\\"]
        total = 0
        for name, items in categories:
            # The client command uses Internet News; the web page calls it Tech News.
            command_name = "Internet News" if name == "Tech News" else name
            lines.append("$$News=" + command_name)
            seen = set()
            for item in items:
                title = self.cyberbuddy_news_title(item)
                link = (item.findtext("link") or "").strip()
                key = (link or title).casefold()
                if title and key not in seen:
                    seen.add(key)
                    description = re.sub(r"\s+", " ", clean_news_text(html.unescape(
                        re.sub(r"<[^>]*>", " ", item.findtext("description") or "")))).strip()
                    description = self.cyberbuddy_news_description(description, title, item)
                    story = title + (" " + description if description else "")
                    lines.append(html.escape(story, quote=False))
                    total += 1
        page = "\r\n".join(lines) + "\r\n"
        self.send_html(200, "OK", page)
        log.info("CYBERBUDDY NEWS3 -> 200 (%d headlines)", total)

    @staticmethod
    def cyberbuddy_news_source(item):
        """Name the actual feed publisher, without guessing an article's wire author."""
        hostname = (urllib.parse.urlsplit(item.findtext("link") or "").hostname or "").lower()
        source_node = item.find("source")
        source_url = (source_node.get("url", "") if source_node is not None else "")
        source_host = (urllib.parse.urlsplit(source_url).hostname or "").lower()
        if hostname == "news.google.com":
            if source_host in ("apnews.com", "www.apnews.com"):
                return "AP"
            if source_host in ("reuters.com", "www.reuters.com"):
                return "Reuters"
            return ""
        if hostname == "livescience.com" or hostname.endswith(".livescience.com"):
            return "LiveScience"
        if hostname == "foxnews.com" or hostname.endswith(".foxnews.com"):
            return "Fox News"
        if hostname == "foxbusiness.com" or hostname.endswith(".foxbusiness.com"):
            return "Fox Business"
        return re.sub(r"\s+", " ", clean_news_text(item.findtext("source") or "")).strip()

    @classmethod
    def cyberbuddy_news_title(cls, item):
        """Remove publisher suffixes from RSS titles shown to CyberBuddy."""
        title = re.sub(r"\s+", " ", clean_news_text((item.findtext("title") or "").strip()))
        publisher = cls.cyberbuddy_news_source(item)
        if publisher:
            label = "AP News" if publisher == "AP" else publisher
            title = re.sub(r"\s+-\s+(?:" + re.escape(label) +
                           (r"|AP" if publisher == "AP" else "") + r")$", "", title,
                           flags=re.IGNORECASE)
        return title

    @classmethod
    def cyberbuddy_news_description(cls, description, title, item):
        """Discard Google's repeated headline and publisher from RSS summaries."""
        description = description.strip()
        if description.casefold().startswith(title.casefold()):
            description = description[len(title):].lstrip(" .:-\t")
            publisher = cls.cyberbuddy_news_source(item)
            if publisher:
                labels = (publisher, "AP News") if publisher == "AP" else (publisher,)
                if description.casefold() in (label.casefold() for label in labels):
                    return ""
        return description

    def fetch_english_news_sources(self):
        """Use publisher-identified AP/Reuters results; fail back to English RSS."""
        results = []
        for publisher, site in (("AP", "apnews.com"), ("Reuters", "reuters.com")):
            query = urllib.parse.urlencode({
                "q": "site:" + site, "hl": "en-US", "gl": "US", "ceid": "US:en"})
            try:
                items = self.fetch_news_items("https://news.google.com/rss/search?" + query)
                verified = [item for item in items
                            if self.cyberbuddy_news_source(item) == publisher]
                if not verified:
                    log.warning("NEWS %s publisher results could not be verified", publisher)
                results.extend(verified[:8])
            except Exception as error:
                log.warning("NEWS %s search unavailable: %s", publisher, error)
        if not results:
            log.warning("NEWS publisher search unavailable; using configured English feed")
            results = self.fetch_news_items()
        return results

    def fetch_cyberbuddy_news_categories(self):
        """Use current RSS sections; never fill missing sections with old news."""
        base = "https://moxie.foxnews.com/google-publisher/"
        latest = self.fetch_english_news_sources()
        fox = "foxnews.com" in CFG.get("web_watching", "news_feed", fallback="").lower()
        section_items = {}
        if fox:
            for name, url in (("Science News", base + "science.xml"),
                              ("Medical News", base + "health.xml"),
                              ("Tech News", base + "tech.xml"),
                              ("Business News", "https://moxie.foxbusiness.com/google-publisher/latest.xml")):
                try:
                    section_items[name] = self.fetch_news_items(url)[:5]
                except Exception as error:
                    log.warning("NEWS CATEGORY %s unavailable: %s", name, error)
                    section_items[name] = []
        try:
            science = [item for item in self.fetch_news_items(
                "https://www.livescience.com/feeds/all")
                if self.cyberbuddy_news_source(item) == "LiveScience"]
            if science:
                section_items["Science News"] = science[:5]
        except Exception as error:
            log.warning("NEWS LiveScience feed unavailable: %s", error)
        for category, terms in (
            ("Media News", '(television OR cinema OR journalism OR entertainment)'),
            ("Off Beat News", '("odd news" OR "strange news" OR "unusual discovery")'),
        ):
            found = []
            for publisher, domain in (("AP", "apnews.com"),
                                      ("Reuters", "reuters.com")):
                query = urllib.parse.urlencode({
                    "q": "site:" + domain + " " + terms,
                    "hl": "en-US", "gl": "US", "ceid": "US:en"})
                try:
                    found.extend(item for item in self.fetch_news_items(
                        "https://news.google.com/rss/search?" + query)
                        if self.cyberbuddy_news_source(item) == publisher)
                except Exception as error:
                    log.warning("NEWS CATEGORY %s unavailable: %s", category, error)
            section_items[category] = found[:5]
        def section(name, paths):
            if name in section_items:
                return section_items[name]
            return [item for item in latest if any(
                path in (item.findtext("link") or "").lower() for path in paths)][:5]
        return (
            ("Top Stories", latest[:8]),
            ("Media News", section("Media News", ("/media/", "/entertainment/"))),
            ("Business News", section("Business News", ("/business/", "/economy/"))),
            ("Science News", section("Science News", ("/science/",))),
            ("Medical News", section("Medical News", ("/health/",))),
            ("Off Beat News", section("Off Beat News", ("/odd-news/", "/lifestyle/"))),
            ("Tech News", section("Tech News", ("/tech/",))),
        )

    def send_cyberbuddy_newspage(self):
        """Render live RSS in the original CyberBuddy news page's list layout."""
        categories = self.fetch_cyberbuddy_news_categories()
        sections = []
        for name, items in categories:
            rows = []
            seen = set()
            for item in items:
                title = self.cyberbuddy_news_title(item)
                description = clean_news_text(re.sub(
                    r"<[^>]*>", " ", item.findtext("description") or ""))
                description = re.sub(r"\s+", " ", html.unescape(description)).strip()
                link = (item.findtext("link") or "").strip()
                if not title:
                    continue
                key = (link or title).casefold()
                if key in seen:
                    continue
                seen.add(key)
                headline = html.escape(title, quote=False)
                if link.startswith(("https://", "http://")):
                    headline = ('<a href="' + html.escape(link, quote=True) + '">' +
                                headline + '</a>')
                # The 2013 page has headline and synopsis on the same list line.
                if description and description.casefold() != title.casefold():
                    description = self.cyberbuddy_news_description(description, title, item)
                    if description:
                        headline += ' ' + html.escape(description, quote=False)
                rows.append('<li>' + headline + '<br></li>')
            sections.append('<p></p><center><b>' + html.escape(name) + '</b></center><br>' +
                            (''.join(rows) if rows else
                             'No current headlines in this category.<br>'))
        page = ('<html><head><meta http-equiv="Content-Type" '
                'content="text/html; charset=windows-1252"><title>CyberBuddy News</title>'
                '<style type="text/css">td { font-family: verdana,arial,sans-serif; '
                'font-size: 12pt; }</style></head>'
                '<body bgcolor="#FAFAFA" text="#000000">'
                '<center><font size="4" color="red"> - CyberBuddy News Page - '
                '</font></center><p></p><center><table width="80%"><tr><td><br>' +
                ''.join(sections) + '</td></tr></table></center><br><br><p></p>'
                '<center><font size="-2">CyberBuddy News Processor</font></center>'
                '</body></html>')
        self.send_html(200, "OK", page)
        log.info("CYBERBUDDY NEWSPAGE -> 200 (fresh RSS)")

    def send_legacy_weather(self, location="São Paulo", unit_override=None, weather_endpoint="forecast.cgi"):
        """Resolve any world city and fetches live Open-Meteo conditions."""
        # CyberBuddy's old default is simply "Formosa".  Without context,
        # Nominatim can interpret that as Ilha Formosa (Taiwan); the intended
        # Brazilian city is Formosa, Goiás.
        original_location = clean_news_text(location)
        location = original_location
        if location.strip().upper() == "KPIT":
            location = "Pittsburgh International Airport, Pennsylvania, USA"
        if (not location or "formosa" in location.strip().lower()
                and "ilha" not in location.strip().lower()):
            location = "Formosa, Goiás, Brasil"
        english = True
        temperature_display = (unit_override or CFG.get("weather", "temperature_display", fallback="both")).strip().lower()
        if temperature_display not in ("fahrenheit", "celsius", "both"):
            temperature_display = "both"
        geo_common = {"format": "jsonv2", "limit": 1, "addressdetails": 1,
                      "accept-language": "en" if english else "pt-BR"}
        if re.fullmatch(r"\d{5}", location):
            geo_queries = [{"postalcode": location, "countrycodes": "us"},
                           {"q": location + ", United States", "countrycodes": "us"}]
        elif re.fullmatch(r"[A-Za-z]{4}", location):
            # Historic Unisys forecast links commonly use ICAO station IDs
            # (KSEA, KMIA, CYSJ, ...).  Nominatim resolves them more reliably
            # when the request explicitly says airport.
            station = location.upper()
            geo_queries = [{"q": station + " airport"}, {"q": station}]
        else:
            geo_queries = [{"q": location}]
            if location.casefold() in ("brasilia", "brasília"):
                geo_queries.append({"q": "Brasília, Distrito Federal, Brasil", "countrycodes": "br"})
        places = []
        for geo_query in geo_queries:
            geo_url = "https://nominatim.openstreetmap.org/search?" + urllib.parse.urlencode({**geo_common, **geo_query})
            places = cached_geocode(geo_url, "CyberBuddyClassicProxy/6.2 (weather)")
            if places:
                break
        if not places:
            raise ValueError("city not found")
        place = places[0]
        # Never allow the ambiguous Taiwan result for CyberBuddy's default
        # Brazilian Formosa request.
        if "formosa" in original_location.strip().lower() and (
                "taiwan" in place.get("display_name", "").lower()
                or "臺灣" in place.get("display_name", "")):
            geo_url = "https://nominatim.openstreetmap.org/search?" + urllib.parse.urlencode({
                "q": "Formosa, Goiás, Brasil", "format": "jsonv2", "limit": 1,
                "accept-language": "pt-BR", "countrycodes": "br",
            })
            places = cached_geocode(geo_url, "CyberBuddyClassicProxy/6.2 (weather)")
            if not places:
                raise ValueError("Formosa, Goias was not found")
            place = places[0]
        lat, lon = float(place["lat"]), float(place["lon"])
        weather_url = "https://api.open-meteo.com/v1/forecast?" + urllib.parse.urlencode({
            "latitude": lat, "longitude": lon,
            "current": "temperature_2m,relative_humidity_2m,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,dew_point_2m,apparent_temperature,pressure_msl,visibility,is_day",
            "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset",
            "hourly": "temperature_2m,weather_code,precipitation_probability,precipitation,wind_speed_10m,wind_direction_10m",
            "forecast_days": 8,
            "timezone": "auto", "temperature_unit": "celsius", "wind_speed_unit": "kmh",
        })
        weather, weather_is_stale = cached_forecast(weather_url)
        current = weather.get("current", {})
        labels = {0:"clear",1:"mostly clear",2:"partly cloudy",3:"overcast",45:"fog",48:"fog",51:"light drizzle",53:"drizzle",55:"heavy drizzle",61:"light rain",63:"rain",65:"heavy rain",71:"light snow",73:"snow",75:"heavy snow",80:"rain showers",81:"rain showers",82:"heavy rain showers",95:"thunderstorm",96:"thunderstorm with hail",99:"thunderstorm with hail"}
        city = forecast_place_name(place, original_location)
        condition = labels.get(current.get('weather_code'), 'conditions unavailable')
        skies_condition = condition
        if current.get('weather_code') not in {0, 1, 2, 3, 45, 48}:
            try:
                cloud_cover = float(current['cloud_cover'])
                skies_condition = ("clear" if cloud_cover <= 10 else
                                   "mostly clear" if cloud_cover <= 30 else
                                   "partly cloudy" if cloud_cover <= 65 else
                                   "mostly cloudy" if cloud_cover <= 85 else "overcast")
            except (KeyError, TypeError, ValueError):
                skies_condition = "cloudy"
        temp = current.get('temperature_2m', 'unavailable')
        try:
            temp_speech = str(round(float(temp)))
            temp_f = str(round(float(temp) * 9 / 5 + 32))
        except (TypeError, ValueError):
            temp_speech = str(temp)
            temp_f = "unavailable"
        humidity = current.get('relative_humidity_2m', 'unavailable')
        wind = current.get('wind_speed_10m', 'unavailable')
        degrees = current.get('wind_direction_10m')
        directions = ("north", "north northeast", "northeast", "east northeast",
                      "east", "east southeast", "southeast", "south southeast",
                      "south", "south southwest", "southwest", "west southwest",
                      "west", "west northwest", "northwest", "north northwest")
        try:
            wind_direction = directions[round(float(degrees) / 22.5) % 16]
        except (TypeError, ValueError):
            wind_direction = "unknown direction"
        try:
            wind_mph = str(round(float(wind) / 1.609344))
        except (TypeError, ValueError):
            wind_mph = "unavailable"
        compass = ("N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
                   "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW")
        try:
            wind_legacy = f"{compass[round(float(degrees) / 22.5) % 16]} at {round(float(wind) / 1.852)} knt"
        except (TypeError, ValueError):
            wind_legacy = "unavailable"
        def weather_icon(code, small=False, night=False):
            name = ("Moon" if code == 0 and night else
                    "MoonCloudy" if code in {1, 2} and night else
                    "Sun" if code == 0 else "PartlyCloudy" if code in {1, 2} else
                    "Clouds" if code == 3 else "Foggy" if code in {45, 48} else
                    "Snow" if code in {71, 73, 75} else "Thunder" if code in {95, 96, 99} else "Rain")
            return name + ("-s" if small else "") + ".png"
        icon = weather_icon(current.get("weather_code"), night=observation_is_night(current, weather.get('daily', {})))
        # Keep the field names used by the archived Unisys Weather page.  The
        # original CyberBuddy weather reader looks for these labels rather
        # than arbitrary prose.
        if english:
            temperature_text = {
                "fahrenheit": f"{html.escape(temp_f)} F",
                "celsius": f"{html.escape(temp_speech)} C",
                "both": f"{html.escape(temp_f)} F ({html.escape(temp_speech)} C)",
            }[temperature_display]
            observed = current.get("time")
            local_time = ""
            if observed:
                try:
                    stamp = datetime.datetime.fromisoformat(str(observed))
                    zone = html.escape(str(weather.get("timezone_abbreviation") or "local time"))
                    local_time = f"Time: <b>{stamp.strftime('%I:%M %p %d %b %y').lstrip('0')} {zone}</b><br>"
                except ValueError:
                    local_time = f"Time: <b>{html.escape(str(observed))}</b><br>"
            details = place.get("address") or {}
            suffix = ", ".join(filter(None, [details.get("state_code"), details.get("postcode")]))
            location_name = city + (f" ({suffix})" if suffix else "")
            # The 2001 reader expects these exact observation labels in an
            # HTML table, not prose paragraphs authored by the proxy.
            weather_fields = ("<div class=\"drop\"><table align=\"center\"><tr><td width=\"99%\" valign=\"top\"><br>"
                              f"<font face=\"Arial, Helvetica, sans-serif\"><big><b>Latest Observation for {html.escape(location_name, quote=False)}"
                              "</b></big></font><br><table width=\"99%\"><tr><td width=\"100\" valign=\"top\">"
                              f"<p align=\"center\"><img src=\"/weather_assets/{icon}\" width=\"100\" height=\"100\" alt=\"Weather\">"
                              f"<br><font face=\"Arial, Helvetica, sans-serif\"><b>Temp: {temperature_text}</b></font></p>"
                              "</td><td valign=\"top\"><font face=\"Arial, Helvetica, sans-serif\">"
                              f"Site: <b>{html.escape(city, quote=False)} (Open-Meteo)</b><br>"
                              f"{local_time}"
                              f"Temp: <b>{temperature_text}</b><br>"
                              )
            if weather_is_stale:
                weather_fields += "<b>Cached forecast: live weather service temporarily unavailable.</b><br>"
            dew = current.get("dew_point_2m")
            if dew is not None:
                dew_f = round(float(dew) * 9 / 5 + 32)
                dew_c = round(float(dew))
                dew_text = {"fahrenheit": f"{dew_f} F", "celsius": f"{dew_c} C",
                            "both": f"{dew_f} F ({dew_c} C)"}[temperature_display]
                weather_fields += f"Dewpt: <b>{dew_text}</b><br>"
            weather_fields += (f"Rel Hum: <b>{html.escape(str(humidity))}%</b><br>"
                               f"Winds: <b>{html.escape(wind_legacy)}</b><br>")
            apparent = current.get("apparent_temperature")
            if apparent is not None and float(apparent) < float(temp):
                apparent_c = round(float(apparent))
                apparent_f = round(float(apparent) * 9 / 5 + 32)
                apparent_text = {"fahrenheit": f"{apparent_f} F", "celsius": f"{apparent_c} C",
                                 "both": f"{apparent_f} F ({apparent_c} C)"}[temperature_display]
                weather_fields += f"Feels like: <b>{apparent_text}</b><br>"
            pressure = current.get("pressure_msl")
            if pressure is not None:
                weather_fields += f"Pressure (sea level): <b>{float(pressure):.1f} mb</b><br>"
            visibility = current.get("visibility")
            if visibility is not None:
                weather_fields += f"Visibility: <b>{float(visibility) / 1609.344:.1f} mi</b><br>"
            weather_fields += (f"Skies: <b>{html.escape(skies_condition, quote=False)}</b><br>"
                               f"Weather: <b>{html.escape('' if current.get('weather_code') in {0, 1, 2, 3} else condition, quote=False)}</b><br>"
                               "</font></td><td valign=\"top\"><font face=\"Arial, Helvetica, sans-serif\"><b>Almanac</b><br>")
            daily = weather.get("daily", {})
            def daily_at(key, index):
                values = daily.get(key) or []
                return values[index] if index < len(values) else None
            for label, key in (("Sunrise", "sunrise"), ("Sunset", "sunset")):
                value = daily_at(key, 0)
                if value:
                    try:
                        hour = datetime.datetime.fromisoformat(str(value)).strftime("%I:%M %p").lstrip("0")
                    except ValueError:
                        hour = str(value).split('T')[-1]
                    weather_fields += f"{label}: <b>{html.escape(hour)}</b><br>"
            weather_fields += ("</font></td></tr></table><small>Temperature: "
                               f"<a href=\"/{weather_endpoint}/{urllib.parse.quote(original_location, safe='')}?unit=fahrenheit\">Fahrenheit</a> | "
                               f"<a href=\"/{weather_endpoint}/{urllib.parse.quote(original_location, safe='')}?unit=celsius\">Celsius</a> | "
                               f"<a href=\"/{weather_endpoint}/{urllib.parse.quote(original_location, safe='')}?unit=both\">Both</a></small><br>"
                               "<table><tr><td><b>Regional Plots:</b></td><td>Live plots unavailable for this location.</td></tr></table>")
            forecast_html = ""
            days = daily.get("time") or []
            hourly = weather.get("hourly") or {}
            hourly_times = hourly.get("time") or []
            hourly_index = {str(value): index for index, value in enumerate(hourly_times)}
            def hourly_at(day, hour, variable):
                index = hourly_index.get(f"{day}T{hour:02d}:00")
                values = hourly.get(variable) or []
                return values[index] if index is not None and index < len(values) else None
            def forecast_row(icon_name, title, temperature_line, narrative):
                icon_labels = {"Moon-s.png": "Starry", "MoonCloudy-s.png": "Partly Cloudy",
                               "PartlyCloudy-s.png": "Partly Cloudy", "Sun-s.png": "Sunny",
                               "Rain-s.png": "Rainy", "Clouds-s.png": "Cloudy",
                               "Thunder-s.png": "Thunder", "Snow-s.png": "Snow",
                               "Foggy-s.png": "Foggy"}
                icon_alt = html.escape(icon_labels.get(icon_name, "Weather"), quote=True)
                return (f'<tr><td width="15%" align="center"><img src="/weather_assets/{icon_name}" '
                        f'width="50" height="50" alt="{icon_alt}"></td><td width="85%" valign="top">'
                        f'<font face="Arial, Helvetica, sans-serif"><b>{html.escape(title)}<br>'
                        f'{html.escape(temperature_line)}<br></b>{html.escape(narrative)}</font></td></tr>')
            if days:
                night_now = observation_is_night(current, daily)
                try:
                    local_hour = datetime.datetime.fromisoformat(str(current["time"])).hour
                except (KeyError, TypeError, ValueError):
                    local_hour = 12 if night_now else 9
                # The old forecast changes its seven-card window during the
                # afternoon, earlier than the observation icon changes to moon.
                next_day_window = night_now or local_hour >= 12
                def display_temperature(value):
                    try:
                        c = round(float(value))
                        f = round(float(value) * 9 / 5 + 32)
                    except (ValueError, TypeError):
                        return "unavailable"
                    return {"fahrenheit": f"{f} F", "celsius": f"{c} C",
                            "both": f"{f} F ({c} C)"}[temperature_display]
                def summary_degrees(value):
                    """The old seven-column summary prints plain degree numbers."""
                    try:
                        c = float(value)
                        return str(round(c if temperature_display == "celsius" else c * 9 / 5 + 32))
                    except (TypeError, ValueError):
                        return "?"
                def temperature_band(value, plural):
                    try:
                        amount = round(float(value) if temperature_display == "celsius"
                                       else float(value) * 9 / 5 + 32)
                    except (TypeError, ValueError):
                        return "TEMPERATURES UNAVAILABLE"
                    digit = amount % 10
                    band = "LOWER" if digit < 4 else "MID" if digit < 7 else "UPPER"
                    tens = amount - digit
                    if amount < 0:
                        return f"{plural} NEAR {amount}"
                    return f"{plural} IN THE {band} {tens}S"
                def period_temperature_phrase(values, plural, fallback):
                    """Use the original short NWS-style temperature band wording."""
                    readings = [float(v) for v in values if v is not None]
                    if len(readings) < 2:
                        return temperature_band(fallback, plural)
                    low, high = min(readings), max(readings)
                    degrees = lambda v: round(v if temperature_display == "celsius" else v * 9 / 5 + 32)
                    if degrees(high) - degrees(low) < 9:
                        return temperature_band(fallback, plural)
                    # A point forecast's hourly span is not the regional range
                    # in an old NWS text forecast. Avoid a range that conflicts
                    # with the displayed daily high or exaggerates nighttime lows.
                    if ((plural == "HIGHS" and abs(degrees(high) - degrees(fallback)) > 3) or
                            (plural == "LOWS" and degrees(high) - degrees(low) > 15)):
                        return temperature_band(fallback, plural)
                    def range_end(value):
                        amount = degrees(value)
                        if amount < 0:
                            return str(amount)
                        digit = amount % 10
                        if digit < 4:
                            return f"LOWER {amount - digit}S"
                        if digit < 7:
                            return f"MID {amount - digit}S"
                        return f"UPPER {amount - digit}S"
                    first, last = range_end(low), range_end(high)
                    # A point-forecast hourly swing is not the same as the
                    # NWS regional range. Use one band unless both ends are
                    # within the same decade and close to the reported high.
                    if plural == 'HIGHS' and degrees(low) // 10 == degrees(high) // 10:
                        return (f"HIGHS IN THE {first.split()[0]} TO {last}"
                                if first != last else temperature_band(fallback, plural))
                    return temperature_band(fallback, plural)
                def sky_phrase(code, night=False):
                    if night:
                        return {0: "CLEAR", 1: "MOSTLY CLEAR", 2: "PARTLY CLOUDY",
                                3: "CLOUDY"}.get(code, labels.get(code, "CONDITIONS UNAVAILABLE").upper())
                    return {0: "SUNNY", 1: "MOSTLY SUNNY", 2: "PARTLY CLOUDY",
                            3: "CLOUDY"}.get(code, labels.get(code, "CONDITIONS UNAVAILABLE").upper())
                def precip_phrase(code, chance):
                    try:
                        if chance is None or float(chance) < 20:
                            return ""
                    except (TypeError, ValueError):
                        return ""
                    # A wet weather code already names the precipitation in
                    # sky_phrase. Repeating a 100% probability after "RAIN"
                    # or "DRIZZLE" makes the old-style forecast sound broken.
                    if code in {51, 53, 55, 61, 63, 65, 66, 67, 71, 73, 75,
                                77, 80, 81, 82, 85, 86, 95, 96, 99}:
                        return ""
                    event = ("DRIZZLE" if code in {51, 53, 55} else
                             "SNOW" if code in {71, 73, 75, 77, 85, 86} else
                             "THUNDERSTORMS" if code in {95, 96, 99} else "SHOWERS")
                    likelihood = ("A SLIGHT CHANCE OF" if float(chance) < 30 else
                                  "A CHANCE OF" if float(chance) < 55 else
                                  "LIKELY")
                    return (f" {event} LIKELY." if likelihood == "LIKELY" else
                            f" {likelihood} {event}.")
                def thunder_narrative(day, hours):
                    """Describe storms only when the live hourly forecast supports them."""
                    samples = [(hourly_at(day, hour, 'weather_code'),
                                hourly_at(day, hour, 'precipitation_probability'),
                                hourly_at(day, hour, 'precipitation')) for hour in hours]
                    storm = [(code, probability, rain) for code, probability, rain in samples
                             if code in {95, 96, 99}]
                    if not storm:
                        return ''
                    likely = sum((probability or 0) >= 60 for _, probability, _ in storm) >= 2
                    storm_hours = [hour for hour, (code, _, _) in zip(hours, samples)
                                   if code in {95, 96, 99}]
                    timing = (' IN THE EVENING' if min(hours) >= 19 else
                              ' IN THE AFTERNOON' if min(hours) < 19 and
                              min(storm_hours) >= 12 else '')
                    wording = ('NUMEROUS' if likely else 'SCATTERED') + ' SHOWERS AND THUNDERSTORMS'
                    heavy = any(rain is not None and float(rain) >= 8 for _, _, rain in storm)
                    if heavy:
                        wording += '. SOME THUNDERSTORMS MAY PRODUCE HEAVY RAINFALL' + timing
                    return wording + ('' if heavy else timing) + '.'
                def wind_phrase(speed, direction=None):
                    try:
                        speed = float(speed)
                    except (TypeError, ValueError):
                        return ""
                    if speed < 8:
                        return " LIGHT AND VARIABLE WINDS."
                    unit = "KM/H" if temperature_display == "celsius" else "MPH"
                    amount = round(speed if unit == "KM/H" else speed / 1.609344)
                    if direction is None:
                        return f" WINDS AROUND {amount} {unit}."
                    try:
                        directions = ("NORTH", "NORTH NORTHEAST", "NORTHEAST", "EAST NORTHEAST",
                                      "EAST", "EAST SOUTHEAST", "SOUTHEAST", "SOUTH SOUTHEAST",
                                      "SOUTH", "SOUTH SOUTHWEST", "SOUTHWEST", "WEST SOUTHWEST",
                                      "WEST", "WEST NORTHWEST", "NORTHWEST", "NORTH NORTHWEST")
                        compass_point = directions[round(float(direction) / 22.5) % 16]
                    except (TypeError, ValueError):
                        compass_point = ""
                    return f" {compass_point} WINDS AROUND {amount} {unit}."
                def period_wind_phrase(day, hours, ending=None, next_day=None):
                    samples = []
                    for hour in hours:
                        speed = hourly_at(day, hour, "wind_speed_10m")
                        direction = hourly_at(day, hour, "wind_direction_10m")
                        if speed is not None:
                            samples.append((float(speed), direction))
                    if next_day is not None:
                        for hour in range(0, 7):
                            speed = hourly_at(next_day, hour, "wind_speed_10m")
                            direction = hourly_at(next_day, hour, "wind_direction_10m")
                            if speed is not None:
                                samples.append((float(speed), direction))
                    if not samples:
                        return ""
                    unit = "KM/H" if temperature_display == "celsius" else "MPH"
                    def mph(kmh):
                        return round(kmh if unit == "KM/H" else kmh / 1.609344)
                    def wind_range(part):
                        speeds = [mph(s) for s, _ in part]
                        lo, hi = min(speeds), max(speeds)
                        return f"AROUND {hi} {unit}" if hi - lo < 4 else f"{lo} TO {hi} {unit}"
                    def direction_name(value):
                        if value is None:
                            return ""
                        names = ("NORTH", "NORTH NORTHEAST", "NORTHEAST", "EAST NORTHEAST",
                                 "EAST", "EAST SOUTHEAST", "SOUTHEAST", "SOUTH SOUTHEAST",
                                 "SOUTH", "SOUTH SOUTHWEST", "SOUTHWEST", "WEST SOUTHWEST",
                                 "WEST", "WEST NORTHWEST", "NORTHWEST", "NORTH NORTHWEST")
                        return names[round(float(value) / 22.5) % 16]
                    if max(s for s, _ in samples) < 8:
                        return " LIGHT AND VARIABLE WINDS."
                    midpoint = len(samples) // 2
                    early, late = samples[:midpoint], samples[midpoint:]
                    first_dir = direction_name(early[0][1]) if early else ""
                    last_dir = direction_name(late[-1][1]) if late else first_dir
                    first_angle = early[0][1] if early else None
                    last_angle = late[-1][1] if late else None
                    turning = (first_angle is not None and last_angle is not None and
                               abs((float(last_angle) - float(first_angle) + 180) % 360 - 180) >= 45)
                    if first_dir and last_dir and turning and early and late:
                        timing = "AFTER MIDNIGHT" if ending == "night" else "IN THE AFTERNOON"
                        return (f" {first_dir} WINDS {wind_range(early)} SHIFTING TO THE "
                                f"{last_dir} {wind_range(late)} {timing}.")
                    if early and late and abs(mph(max(s for s, _ in late)) -
                                              mph(max(s for s, _ in early))) >= 6:
                        rising = max(s for s, _ in late) > max(s for s, _ in early)
                        timing = "AFTER MIDNIGHT" if ending == "night" else "IN THE AFTERNOON"
                        change = "INCREASING" if rising else "DECREASING"
                        return (f" {first_dir + ' ' if first_dir else ''}WINDS {wind_range(early)} "
                                f"{change} TO {wind_range(late)} {timing}.")
                    return f" {first_dir + ' ' if first_dir else ''}WINDS {wind_range(samples)}."
                rows = []
                periods = []
                for i, day in enumerate(days[:8]):
                    try:
                        label = "TODAY" if i == 0 else datetime.date.fromisoformat(str(day)).strftime("%A").upper()
                    except ValueError:
                        label = html.escape(str(day))
                    high = html.escape(display_temperature(daily_at("temperature_2m_max", i)))
                    low = html.escape(display_temperature(daily_at("temperature_2m_min", i)))
                    description = html.escape(labels.get(daily_at("weather_code", i), "conditions unavailable"))
                    chance = daily_at("precipitation_probability_max", i)
                    wind_max = daily_at("wind_speed_10m_max", i)
                    morning_code = hourly_at(day, 9, "weather_code")
                    afternoon_code = hourly_at(day, 15, "weather_code")
                    # Match the visible daytime period: morning conditions for
                    # TODAY before noon; afternoon conditions for future days.
                    # The daily code may refer to rain overnight instead.
                    preferred_code = morning_code if i == 0 and local_hour < 12 else afternoon_code
                    icon_code = (preferred_code if preferred_code is not None else
                                 afternoon_code if afternoon_code is not None else
                                 morning_code if morning_code is not None else
                                 daily_at("weather_code", i))
                    if any(hourly_at(day, hour, 'weather_code') in {95, 96, 99}
                           for hour in range(8, 19)):
                        icon_code = 95
                    small_icon = weather_icon(icon_code, small=True)
                    # The 2013 Unisys summary displays both HI and LO in every
                    # daily column. Values are live; only the presentation is historic.
                    summary_high = summary_degrees(daily_at("temperature_2m_max", i))
                    summary_low = summary_degrees(daily_at("temperature_2m_min", i))
                    if i > 0:
                        previous_evening = [hourly_at(days[i - 1], hour, "temperature_2m")
                                            for hour in range(18, 24)]
                        next_morning = [hourly_at(day, hour, "temperature_2m")
                                        for hour in range(7)]
                        overnight_values = [float(value) for value in previous_evening + next_morning
                                            if value is not None]
                        if overnight_values:
                            summary_low = summary_degrees(min(overnight_values))
                    # Match the archived page's daytime/evening summary.
                    if i >= (1 if next_day_window else 0) and len(rows) < 7:
                        summary_label = ("TODAY" if i == 0 else
                                         datetime.date.fromisoformat(str(day)).strftime("%A").upper())
                        rows.append(f"<td width=\"14%\" valign=\"top\" align=\"center\"><font face=\"Arial, Helvetica, sans-serif\"><b>{summary_label}<br>"
                                    f"<img src=\"/weather_assets/{small_icon}\" width=\"50\" height=\"50\" alt=\"{description}\"><br>"
                                    f"HI: {summary_high}<br>" +
                                    (f"LO: {summary_low}<br>" if i > 0 or next_day_window else "") +
                                    "</b></font></td>")
                    daytime_storm = thunder_narrative(day, range(8, 19))
                    if daytime_storm:
                        early_sky = morning_code if morning_code in {0, 1, 2, 3} else None
                        detail = ((sky_phrase(early_sky) + '. ' if early_sky is not None
                                   and 'AFTERNOON' in daytime_storm else '') + daytime_storm)
                    elif morning_code is not None and afternoon_code is not None:
                        morning_name = sky_phrase(morning_code)
                        afternoon_name = sky_phrase(afternoon_code)
                        detail = (f"{morning_name} THIS MORNING, THEN {afternoon_name} THIS AFTERNOON."
                                  if morning_name != afternoon_name else f"{morning_name}.")
                    else:
                        detail = f"{sky_phrase(daily_at('weather_code', i))}."
                    if i > 0:
                        old_high, new_high = daily_at("temperature_2m_max", i - 1), daily_at("temperature_2m_max", i)
                        if old_high is not None and new_high is not None:
                            difference = (float(new_high) - float(old_high)) * (1 if temperature_display == "celsius" else 9 / 5)
                            if abs(difference) >= (5 if temperature_display == "celsius" else 9):
                                detail += " WARMER." if difference > 0 else " COOLER."
                    if wind_max is not None:
                        maximum_mph = float(wind_max) / 1.609344
                        if maximum_mph >= 25:
                            detail += " WINDY."
                        elif maximum_mph >= 15:
                            detail += " BREEZY."
                    if not daytime_storm:
                        precipitation = precip_phrase(daily_at("weather_code", i), chance)
                        if precipitation.startswith(' A CHANCE') or precipitation.startswith(' A SLIGHT CHANCE'):
                            detail = detail.rstrip('.') + ' WITH' + precipitation
                        else:
                            detail += precipitation
                    day_hours = range(8, 19)
                    day_temps = [hourly_at(day, hour, "temperature_2m") for hour in day_hours]
                    detail += f" {period_temperature_phrase(day_temps, 'HIGHS', daily_at('temperature_2m_max', i))}."
                    detail += period_wind_phrase(day, day_hours)
                    daytime = {"title": label, "icon": small_icon,
                               "temp": f"HI: {summary_high}",
                               "text": detail, "high": summary_high, "chance": chance}
                    night_code = hourly_at(day, 21, "weather_code")
                    night_chance = hourly_at(day, 21, "precipitation_probability")
                    night_wind = hourly_at(day, 21, "wind_speed_10m")
                    nighttime = None
                    if night_code is not None:
                        evening = [hourly_at(day, hour, "temperature_2m") for hour in range(18, 24)]
                        next_day = days[i + 1] if i + 1 < len(days) else None
                        if next_day:
                            evening += [hourly_at(next_day, hour, "temperature_2m") for hour in range(7)]
                        readings = [float(value) for value in evening if value is not None]
                        night_low = min(readings) if readings else daily_at("temperature_2m_min", i)
                        night_title = "TONIGHT" if i == 0 else label + " NIGHT"
                        night_storm = thunder_narrative(day, range(19, 24))
                        evening_sky = hourly_at(day, 19, 'weather_code')
                        night_text = ((sky_phrase(evening_sky, night=True) + '. '
                                       if night_storm and evening_sky in {0, 1, 2, 3}
                                       and 'IN THE EVENING' not in night_storm else '') +
                                      (night_storm if night_storm else
                                       f"{sky_phrase(night_code, night=True)}."))
                        if next_day and daily_at("temperature_2m_min", i) is not None:
                            old_low = daily_at("temperature_2m_min", i - 1) if i else None
                            if old_low is not None:
                                difference = (float(night_low) - float(old_low)) * (1 if temperature_display == "celsius" else 9 / 5)
                                if difference <= -(5 if temperature_display == "celsius" else 9):
                                    night_text += " COLDER."
                        if not night_storm:
                            precipitation = precip_phrase(night_code, night_chance)
                            if precipitation.startswith(' A CHANCE') or precipitation.startswith(' A SLIGHT CHANCE'):
                                night_text = night_text.rstrip('.') + ' WITH' + precipitation
                            else:
                                night_text += precipitation
                        night_text += f" {period_temperature_phrase(evening, 'LOWS', night_low)}."
                        night_text += period_wind_phrase(day, range(19, 24), ending="night", next_day=next_day)
                        nighttime = {"title": night_title, "icon": weather_icon(night_code, small=True, night=True),
                                     "temp": f"LO: {summary_degrees(night_low)}", "text": night_text,
                                     "low": summary_degrees(night_low), "chance": night_chance,
                                     "condition": sky_phrase(night_code, night=True), "low_c": night_low}
                    periods.append((daytime, nighttime))
                # The detailed sequence follows the afternoon forecast window;
                # the current-observation icon still follows sunrise/sunset.
                narratives = []
                def append_period(item):
                    if item:
                        narratives.append(forecast_row(item["icon"], item["title"],
                                                       item["temp"], item["text"]))
                if periods:
                    if not next_day_window:
                        append_period(periods[0][0])
                    first_night = periods[0][1]
                    if first_night:
                        tonight = dict(first_night)
                        tonight["title"] = "TONIGHT"
                        append_period(tonight)
                    visible_periods = periods[1:8] if next_day_window else periods[1:7]
                    for index, (daytime, nighttime) in enumerate(visible_periods):
                        append_period(daytime)
                        # The last detailed row is the seventh summary day.
                        if index < len(visible_periods) - 1:
                            append_period(nighttime)
                area_name = html.escape(city.upper(), quote=False)
                try:
                    issue_dt = datetime.datetime.fromisoformat(str(current.get("time")))
                    issue_stamp = (issue_dt.strftime("%I%M %p").lstrip("0") + " " +
                                   html.escape(zone) + " " +
                                   issue_dt.strftime("%a %b %d %Y").upper())
                except (ValueError, TypeError):
                    issue_stamp = "CURRENT FORECAST"
                detail_header = (f"{area_name} AREA-<br>"
                                 f"INCLUDING THE CITIES OF...{area_name}<br>" +
                                 f"{issue_stamp}<br><br>")
                forecast_html = ("<hr><font face=\"Arial, Helvetica, sans-serif\"><b>Forecast Summary<br></b></font>"
                                 "<table width=\"100%\" border=\"1\"><tr align=\"center\">" +
                                 "".join(rows) + "</tr></table><br>"
                                 "<font face=\"Arial, Helvetica, sans-serif\"><b>Detailed forecast from Open-Meteo<br></b>" +
                                 detail_header + "</font>" +
                                 "<table width=\"100%\" border=\"1\">" + "".join(narratives) + "</table>")
            forecast_source = "Open-Meteo"
            country = place.get("address", {}).get("country_code", "").lower()
            if country == "us":
                nws_headers = {
                    "User-Agent": "CyberBuddyClassicProxy/6.2 (local-weather-bridge)",
                    "Accept": "application/geo+json"}
                try:
                    alert_url = ("https://api.weather.gov/alerts/active?" +
                                 urllib.parse.urlencode({"point": f"{lat},{lon}"}))
                    alert_request = urllib.request.Request(alert_url, headers=nws_headers)
                    with direct_urlopen(alert_request, timeout=min(TIMEOUT, 6)) as response:
                        active_alerts = json.loads(response.read().decode("utf-8")).get("features", [])
                    weather_fields += "<hr><font face=\"Arial, Helvetica, sans-serif\"><b>Alerts</b><br>"
                    if active_alerts:
                        for feature in active_alerts[:5]:
                            properties = feature.get("properties") or {}
                            event = html.escape(str(properties.get("event") or "Weather alert"))
                            body = str(properties.get("description") or properties.get("headline") or "")
                            statement = next((line.strip() for line in body.splitlines() if line.strip()), "")
                            if len(statement) > 220:
                                statement = statement[:217] + "..."
                            expiry_raw = str(properties.get("ends") or properties.get("expires") or "")
                            try:
                                expiry_dt = datetime.datetime.fromisoformat(expiry_raw.replace("Z", "+00:00"))
                                from zoneinfo import ZoneInfo
                                expiry_dt = expiry_dt.astimezone(ZoneInfo(str(weather.get("timezone"))))
                                expiry = expiry_dt.strftime("%I:%M %p %Z").lstrip("0")
                            except (ValueError, TypeError, KeyError, ImportError):
                                expiry = expiry_raw
                            weather_fields += (f"<b>{event} valid until {html.escape(expiry)}</b><br>"
                                               f"{html.escape(statement)}<br>")
                    else:
                        weather_fields += "No active alerts for this location.<br>"
                    weather_fields += "</font>"
                except (OSError, ValueError, KeyError, TypeError) as exc:
                    log.warning("NWS alerts unavailable for %s: %s", city, exc)
                    weather_fields += "<hr><b>Alerts</b><br>Alerts temporarily unavailable.<br>"
            elif country == "br":
                try:
                    notices = cached_inmet_alerts(place)
                    weather_fields += "<hr><b>Alerts (INMET)</b><br>"
                    translated = {"chuvas intensas": "Heavy Rain", "tempestade": "Thunderstorm",
                                  "vendaval": "High Winds", "baixa umidade": "Low Humidity",
                                  "onda de calor": "Heat Wave", "onda de frio": "Cold Wave",
                                  "geada": "Frost", "acumulado de chuva": "Heavy Rainfall"}
                    for event, until, message in notices:
                        try:
                            from zoneinfo import ZoneInfo
                            until = until.astimezone(ZoneInfo(str(weather.get("timezone"))))
                        except (ValueError, TypeError, KeyError, ImportError):
                            pass
                        until_text = until.strftime("%I:%M %p %Z").lstrip("0")
                        event_name = translated.get(event.casefold(), event)
                        weather_fields += (f"<b>{html.escape(event_name)} valid until "
                                           f"{html.escape(until_text)}</b><br>"
                                           f"{html.escape(message)}<br>")
                    if not notices:
                        weather_fields += "No active INMET alerts confirmed for this location.<br>"
                except (OSError, ValueError, ET.ParseError, KeyError) as exc:
                    log.warning("INMET alerts unavailable for %s: %s", city, exc)
                    weather_fields += "<hr><b>Alerts (INMET)</b><br>Alerts temporarily unavailable.<br>"
            else:
                try:
                    notices = fetch_global_alerts(place)
                    weather_fields += "<hr><b>Alerts (IFRC Alert Hub)</b><br>"
                    if notices is None:
                        weather_fields += "Alert coverage unavailable for this location.<br>"
                    elif not notices:
                        weather_fields += "No active location-matched weather alerts found.<br>"
                    else:
                        for event, until, message in notices:
                            try:
                                from zoneinfo import ZoneInfo
                                until = until.astimezone(ZoneInfo(str(weather.get('timezone'))))
                            except (ValueError, TypeError, KeyError, ImportError):
                                pass
                            expiry = until.strftime('%I:%M %p %Z').lstrip('0')
                            weather_fields += (f"<b>{html.escape(event)} valid until "
                                               f"{html.escape(expiry)}</b><br>"
                                               f"{html.escape(message)}<br>")
                except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
                    log.warning('IFRC alerts unavailable for %s: %s', city, exc)
                    weather_fields += '<hr><b>Alerts (IFRC Alert Hub)</b><br>Alerts temporarily unavailable.<br>'
            log.info("LEGACY WEATHER summary=%s details=%s location=%s version=%s",
                     forecast_source, forecast_source, city, APP_VERSION)
            weather_fields += forecast_html + "</td></tr></table></div>"
        page = self.weather_shell(weather_fields, icon)
        self.send_html(200, "OK", page)
        log.info("LEGACY WEATHER requested=%s | found=%s | Open-Meteo %.4f,%.4f",
                 original_location or "(default)", city, lat, lon)

    def send_weather_form(self, endpoint="forecast.cgi"):
        """Use the original forecast search form without a duplicate form."""
        if (WEATHER_SITE / "forecast.php").exists():
            content = ('<p>Enter a ZIP code, city name or airport in the '
                       'search box above to get the current forecast.</p>')
        else:
            content = ('<big><b>Get a Forecast</b></big><br>'
                       '<p>Enter a ZIP code, city name or airport.</p>'
                       f'<form method="get" action="/{endpoint}">'
                       '<input type="text" name="Name" size="30">'
                       '<input type="submit" value="Get Forecast Data"></form>')
        page = self.weather_shell(content)
        self.send_html(200, "OK", page)

    def send_legacy_fun(self, kind):
        # Pick a random entry, but avoid immediately repeating the previous one.
        with FUN_LOCK:
            count = len(FUN_ITEMS[kind])
            index = random.SystemRandom().randrange(count)
            if count > 1 and index == FUN_LAST_INDEX[kind]:
                index = (index + random.SystemRandom().randrange(1, count)) % count
            FUN_LAST_INDEX[kind] = index
        text = FUN_ITEMS[kind][index]
        label = "Joke" if kind == "joke" else "Thought"
        # CyberBud.exe counts each $$ line as an entry, then reads
        # following lines until the next marker or EOF. A trailing marker
        # creates an empty selectable entry, so terminate with EOF instead.
        lines = [line.strip() for line in text.strip().splitlines() if line.strip()]
        payload = "$$" + label + "\r\n" + "\r\n".join(lines) + "\r\n"
        self.send_html(200, "OK", payload)
        log.info("LEGACY %s -> local response %d/%d", kind, index + 1, len(FUN_ITEMS[kind]))

    def send_legacy_rss_feed(self):
        items = self.fetch_english_news_sources()
        rows = []
        for item in items:
            title = re.sub(r"\s+", " ", clean_news_text(item.findtext("title") or "Untitled news")).strip()
            description = (item.findtext("description") or "").strip()
            description = re.sub(r"<[^>]+>", " ", description)
            description = clean_news_text(description)
            description = re.sub(r"\s+", " ", description).strip()
            link = (item.findtext("link") or "").strip()
            guid = (item.findtext("guid") or link).strip()
            pub_date = (item.findtext("pubDate") or "").strip()
            rows.append(
                "<item>"
                "<title>" + html.escape(title, quote=False) + "</title>"
                "<description>" + html.escape(description, quote=False) + "</description>"
                "<link>" + html.escape(link) + "</link>"
                + ("<guid isPermaLink=\"false\">" + html.escape(guid) + "</guid>" if guid else "")
                + ("<pubDate>" + html.escape(pub_date) + "</pubDate>" if pub_date else "")
                + "</item>"
            )
        rss = (
            "<?xml version=\"1.0\" encoding=\"windows-1252\"?>"
            "<rss version=\"2.0\"><channel>"
            "<title>CyberBuddy English News</title>"
            "<link>http://thecyberbuddy.com/news/newspage.html</link>"
            "<description>Live English headlines adapted for CyberBuddy</description>"
            + "".join(rows)
            + "</channel></rss>"
        )
        self.send_xml(200, "OK", rss)
        log.info("RSS LEGACY English -> 200 (%d items)", len(items))

    def handle(self):
        try:
            request = self.read_request()
            if request is None:
                return
            method, target, _version, headers, request_body = request

            if method == "CONNECT":
                self.handle_connect(target)
                return

            if method not in {"GET", "HEAD", "POST"}:
                self.send_simple(405, "Method Not Allowed", "Method not allowed.")
                return

            if not urllib.parse.urlsplit(target).scheme:
                host = headers.get("Host")
                if not host:
                    self.send_simple(400, "Bad Request", "Missing Host header.")
                    return
                target = f"http://{host}{target}"

            parsed = urllib.parse.urlsplit(target)

            if parsed.path.lower() == '/chat.html':
                payload = (ROOT / 'Chat.html').read_bytes()
                self.safe_write(("HTTP/1.0 200 OK\r\n"
                                 "Content-Type: text/html; charset=utf-8\r\n"
                                 f"Content-Length: {len(payload)}\r\n"
                                 "Cache-Control: no-store\r\nConnection: close\r\n\r\n").encode("ascii"))
                if method != 'HEAD':
                    self.safe_write(payload)
                return

            # Remote-client diagnostics: record the actual TCP peer for every
            # HTTP request, with extra detail for CyberBuddy UIN/Chat endpoints.
            # This does not record message bodies or query values.
            peer_ip = self.client_address[0] if self.client_address else "unknown"
            local_ips = {"127.0.0.1", "::1", "localhost"}
            endpoint_name = parsed.path.rsplit("/", 1)[-1].lower()
            if peer_ip not in local_ips:
                if endpoint_name in {"uinlister.exe", "cbonline2.exe", "uinserver.exe", "invitebuddy.exe"}:
                    log.warning("REMOTE CYBERBUDDY CLIENT ip=%s method=%s endpoint=%s listener=%s",
                                peer_ip, method, endpoint_name,
                                getattr(self.server, "server_address", ("?", "?"))[1])
                else:
                    log.info("REMOTE CLIENT ip=%s method=%s endpoint=%s", peer_ip, method, endpoint_name)

            if parsed.scheme not in {"http", "https"}:
                self.send_simple(400, "Bad Request", "Only HTTP and HTTPS are supported.")
                return

            # Remote Connection Request decision endpoint. The IP is intentionally
            # not accepted, stored, returned, or displayed here. The request is
            # identified by UIN/name/comments only.
            if parsed.path.rstrip("/").lower() == "/remote_connection_uin_decision":
                try:
                    form = urllib.parse.parse_qs((request_body or b"").decode("cp1252", "replace"), keep_blank_values=True)
                    uin = _chat_safe_uin(form.get("uin", [""])[-1] if form.get("uin") else "")
                    name = (form.get("name", [""])[-1] if form.get("name") else "").strip()
                    comments = (form.get("comments", [""])[-1] if form.get("comments") else "").strip()
                    decision = (form.get("decision", [""])[-1] if form.get("decision") else "").strip().lower()
                    request_type = (form.get("requestType", ["publish"])[-1] if form.get("requestType") else "publish").strip().lower()
                    if not uin:
                        self.send_simple(400, "Bad Request", "ERROR: UIN is required.")
                        return
                    if decision == "accepted":
                        if not _publish_remote_uin(uin, name, comments):
                            self.send_simple(500, "Internal Server Error", "ERROR: UIN could not be published.")
                            return
                        payload = json.dumps({"ok": True, "decision": "accepted", "uin": uin,
                                              "requestType": request_type, "published": True}).encode("utf-8")
                    elif decision == "rejected":
                        payload = json.dumps({"ok": True, "decision": "rejected", "uin": uin,
                                              "requestType": request_type, "published": False}).encode("utf-8")
                    else:
                        self.send_simple(400, "Bad Request", "ERROR: Invalid decision.")
                        return
                    self.safe_write(b"HTTP/1.0 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nCache-Control: no-store\r\nContent-Length: " + str(len(payload)).encode("ascii") + b"\r\nConnection: close\r\n\r\n")
                    self.safe_write(payload)
                    log.info("REMOTE CONNECTION REQUEST decision=%s uin=<hidden> request=%s published=%s", decision, request_type, decision == "accepted")
                except Exception as error:
                    log.error("REMOTE CONNECTION REQUEST decision failed: %s", error)
                    self.send_simple(500, "Internal Server Error", "Remote Connection Request decision failed.")
                return

            # Local Remote Connection Request review page. Serve it directly
            # from this proxy so it works through 127.0.0.1, proxy.local, or
            # the LAN IP that reaches TCP 8081.
            if parsed.path.rstrip("/").lower() == "/remote_connection_uin_join_request.html":
                try:
                    page_path = Path(__file__).resolve().parent / "REMOTE_CONNECTION_UIN_JOIN_REQUEST.html"
                    page = page_path.read_text(encoding="utf-8")

                    # A remote CyberBuddy opening this page is a connection request.
                    # Open the approval page on THIS proxy computer automatically.
                    # The local browser request will not trigger this again because
                    # loopback clients are excluded. A short per-IP cooldown avoids
                    # opening many browser windows for repeated refreshes.
                    if peer_ip not in local_ips:
                        now = time.time()
                        cooldown = getattr(self.server, "_remote_request_page_open", {})
                        last_open = cooldown.get(peer_ip, 0)
                        if now - last_open >= 10:
                            cooldown[peer_ip] = now
                            self.server._remote_request_page_open = cooldown
                            try:
                                import webbrowser
                                local_review = (
                                    f"http://127.0.0.1:{listener_port or 8081}/"
                                    "REMOTE_CONNECTION_UIN_JOIN_REQUEST.html"
                                    f"?remote_ip={urllib.parse.quote(peer_ip)}"
                                )
                                webbrowser.open_new_tab(local_review)
                                log.warning("REMOTE CONNECTION REQUEST OPENED ON HOST ip=%s review=%s", peer_ip, local_review)
                            except Exception as browser_error:
                                log.warning("REMOTE CONNECTION REQUEST browser open failed ip=%s: %s", peer_ip, browser_error)
                        else:
                            log.info("REMOTE CONNECTION REQUEST page refresh suppressed ip=%s", peer_ip)

                    # Pass the remote peer IP into the page when the host review page
                    # is opened locally. The page can then show the request details.
                    if peer_ip not in local_ips and "remote_ip=" not in parsed.query:
                        page = page.replace("</body>",
                            '<script>try{document.getElementById("ip").value='
                            + json.dumps(peer_ip)
                            + ';}catch(e){}</script></body>')
                    self.send_html(200, "OK", page)
                    log.info("REMOTE CONNECTION REQUEST PAGE served to %s", peer_ip)
                except Exception as error:
                    log.error("REMOTE CONNECTION REQUEST PAGE failed: %s", error)
                    self.send_simple(404, "Not Found", "Remote Connection Request page is not installed.")
                return

            # The old directory now returns a parked-domain landing-page
            # redirect. Never send chat account details or message bodies there.
            retired_chat_hosts = {"yeayou.com", "www.yeayou.com", "thecyberbuddy.com",
                                  "www.thecyberbuddy.com", "mycyberbuddy.com",
                                  "www.mycyberbuddy.com", "66.135.47.52", "66.135.38.69"}
            if ((parsed.hostname or '').lower() in {'thecyberbuddy.com','www.thecyberbuddy.com','127.0.0.1','localhost','proxy.local'}
                    and parsed.path.lower() in {'/page18.html','/page18.htm'}):
                payload = _invitebuddy_html()
                self.safe_write(('HTTP/1.0 200 OK\r\nContent-Type: text/html; charset=windows-1252\r\n'
                                 'Content-Length: %d\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n' % len(payload)).encode('ascii'))
                if method != 'HEAD': self.safe_write(payload)
                return

            # Original UIN contact-list download. Archived 1111.cbb is exactly:
            # $$UIN1111\r\n
            _uin_cbb_match = re.match(r'^/cgi-bin/UIN/(\d+)\.cbb$', parsed.path, re.I)
            if ((parsed.hostname or '').lower() in retired_chat_hosts or
                    (parsed.hostname or '').lower() in {"127.0.0.1", "localhost", "proxy.local"}) and _uin_cbb_match:
                payload = _chat_uin_cbb(_uin_cbb_match.group(1))
                self.safe_write(("HTTP/1.0 200 OK\r\n"
                                 "Content-Type: application/octet-stream\r\n"
                                 "Content-Disposition: attachment; filename=\"%s.cbb\"\r\n"
                                 "Content-Length: %d\r\n"
                                 "Cache-Control: no-store\r\n"
                                 "Connection: close\r\n\r\n" % (_uin_cbb_match.group(1), len(payload))).encode("ascii"))
                if method != "HEAD": self.safe_write(payload)
                log.warning('LEGACY UIN CONTACT FILE served target=<hidden>')
                return

            # UINlister contact pages use a bare positional query: ?u<UIN>.
            # Handle this BEFORE the generic legacy chat protocol so it can never
            # be mistaken for a CBonline/UIN protocol request and return $$ markers.
            listener_port = 0
            try:
                listener_port = int(self.server.server_address[1])
            except Exception:
                pass
            if (parsed.path.lower() == "/cgi-bin/uinlister.exe" and
                    ((parsed.hostname or '').lower() in retired_chat_hosts or
                     (parsed.hostname or '').lower() in {"127.0.0.1", "localhost", "proxy.local"} or
                     parsed.port == 8081 or listener_port == 8081)):
                _raw_uin_query = urllib.parse.unquote_plus(parsed.query or '').strip()
                _contact_match = re.fullmatch(r'[uU](\d+)', _raw_uin_query)
                if _contact_match:
                    payload = _chat_uin_contact_html(_contact_match.group(1))
                    self.safe_write(("HTTP/1.0 200 OK\r\n"
                                     "Content-Type: text/html; charset=windows-1252\r\n"
                                     "Content-Length: %d\r\n"
                                     "Cache-Control: no-store\r\n"
                                     "Connection: close\r\n\r\n" % len(payload)).encode("ascii"))
                    if method != "HEAD": self.safe_write(payload)
                    log.warning('LEGACY UIN DIRECTORY CONTACT PAGE direct-route=yes target=<hidden>')
                    return

            retired_chat_paths = {"/cgi-bin/cbonline2.exe", "/cgi-bin/uinlister.exe",
                                  "/cgi-bin/uinserver.exe", "/cgi-bin/invitebuddy.exe"}
            chat_host = (parsed.hostname or "").lower()
            # IMPORTANT: when CyberBuddy uses this program as an HTTP proxy,
            # the requested target can be http://thecyberbuddy.com/... (port 80).
            # parsed.port therefore does NOT identify our local listener. Use the
            # actual socket/listener port so remote clients are routed to the local
            # revived UIN/Chat service too.
            listener_port = 0
            try:
                listener_port = int(self.server.server_address[1])
            except Exception:
                pass
            if (parsed.path.lower() in retired_chat_paths and
                    (chat_host in retired_chat_hosts or
                     chat_host in {"127.0.0.1", "localhost", "proxy.local"} or
                     parsed.port == 8081 or listener_port == 8081)):
                # Version 6.0 IM protocol-discovery handler.  Never forwards private
                # CyberBuddy chat data to the retired public servers.  Instead it
                # records only field NAMES and value lengths so the original wire
                # format can be reconstructed safely from a real CyberBuddy run.
                endpoint = parsed.path.rsplit("/", 1)[-1]
                query_pairs = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
                body_text = request_body.decode("iso-8859-1", "replace") if request_body else ""
                body_pairs = urllib.parse.parse_qsl(body_text, keep_blank_values=True)
                def _shape(pairs):
                    return [(k, len(v)) for k, v in pairs]
                log.warning("LEGACY CHAT DISCOVERY method=%s endpoint=%s query_fields=%r body_fields=%r body_bytes=%d; values intentionally hidden",
                            method, endpoint,
                            _shape(query_pairs) if '=' in parsed.query.split('&', 1)[0] else [('positional', len(parsed.query))],
                            _shape(body_pairs) if '=' in body_text.split('&', 1)[0] else [('raw', len(body_text))],
                            len(request_body or b""))

                # CyberBuddy uses a positional legacy protocol here, not normal
                # key=value form fields. Examples observed from the real client:
                #   CBonline2.exe?L<UIN>&<name>&<version>&<email>&<ip>
                #   UINlister.exe?Y<UIN>&<nickname>&<comments>
                # POST polling can contain a raw UIN followed by CR/LF.
                positional = bool(parsed.query and '=' not in parsed.query.split('&', 1)[0])
                raw_tokens = ([urllib.parse.unquote_plus(x, encoding='cp1252')
                               for x in (parsed.query.split('&&') if '&&' in parsed.query
                                         else parsed.query.split('&'))] if positional else [])
                raw_body = body_text.strip('\r\n\x00 ')
                fields = {}
                native_contacts = (endpoint.lower() == 'cbonline2.exe' and
                                   method == 'POST' and
                                   headers.get('User-Agent', '').startswith('clst&&'))
                if endpoint.lower() == 'invitebuddy.exe' and body_text:
                    for _k, _vals in urllib.parse.parse_qs(body_text, keep_blank_values=True).items():
                        fields[_k.lower()] = _vals[-1] if _vals else ''
                if raw_tokens:
                    fields['_wire_format'] = 'positional'
                    head = raw_tokens[0]
                    op = head[:1].upper() if head else ''
                    if endpoint.lower() == 'cbonline2.exe' and head.startswith('l'):
                        fields['_native_logout'] = True
                    ident = _chat_safe_uin(head[1:] if op.isalpha() else head)
                    fields['action'] = op
                    if ident:
                        if endpoint.lower() == 'cbonline2.exe' and op == 'G':
                            fields['lookupuin'] = ident
                        else:
                            fields['uin'] = ident
                    if endpoint.lower() == 'cbonline2.exe' and op == 'L':
                        if len(raw_tokens) > 1: fields['name'] = raw_tokens[1]
                        if len(raw_tokens) > 2: fields['version'] = raw_tokens[2]
                        if len(raw_tokens) > 3: fields['email'] = raw_tokens[3]
                        if len(raw_tokens) > 4: fields['ip'] = raw_tokens[4]
                    elif endpoint.lower() == 'uinlister.exe' and op == 'Y':
                        if len(raw_tokens) > 1: fields['name'] = raw_tokens[1]
                        if len(raw_tokens) > 2: fields['comments'] = raw_tokens[2]
                    else:
                        # Preserve unknown positional tokens for future protocol
                        # discovery without logging their values.
                        for i, token in enumerate(raw_tokens[1:], 1):
                            fields['arg%d' % i] = token
                elif not native_contacts and raw_body and '=' not in raw_body and '&' not in raw_body:
                    # A body consisting only of a UIN is the client's recurring
                    # receive/presence poll. Do not treat normal form-encoded POST
                    # data as a UIN; that would concatenate the entire form into it.
                    fields['uin'] = _chat_safe_uin(raw_body)
                    fields['action'] = 'poll'

                # Also accept conventional form fields if a later client build
                # happens to use them. Positional values take precedence.
                conventional = _chat_fields(([] if positional else query_pairs) + body_pairs)
                for k, v in conventional.items():
                    fields.setdefault(k, v)

                log.warning('LEGACY CHAT POSITIONAL endpoint=%s op=%s token_count=%d body_uin=%s; values hidden',
                            endpoint, fields.get('action',''), len(raw_tokens),
                            'yes' if (raw_body and not raw_tokens) else 'no')
                if endpoint.lower() != 'uinserver.exe' and raw_tokens and fields.get('action','').upper() not in {'L','Y','G'}:
                    log.warning('LEGACY CHAT SEND CANDIDATE endpoint=%s op=%s token_count=%d; values hidden',
                                endpoint, fields.get('action',''), len(raw_tokens))
                response_status = '200 OK'
                if endpoint.lower() == 'uinserver.exe':
                    content_type = 'text/plain; charset=windows-1252'
                    if method != 'GET':
                        response_status = '405 Method Not Allowed'
                        payload = b'UIN registration requires GET'
                    else:
                        try:
                            payload = _register_legacy_uin(parsed.query)
                            log.info('LEGACY UIN REGISTRATION allocated_or_reused=yes')
                        except ValueError:
                            response_status = '400 Bad Request'
                            payload = b'UIN registration rejected'
                        except (OSError, TypeError):
                            response_status = '503 Service Unavailable'
                            payload = b'UIN registry unavailable'
                elif endpoint.lower() == 'invitebuddy.exe':
                    payload = _invitebuddy_safe_response(fields) if method.upper() == 'POST' else _invitebuddy_html()
                    log.warning('LEGACY INVITE BUDDY endpoint=invitebuddy.exe method=%s', method.upper())
                    content_type = 'text/html; charset=windows-1252'
                elif endpoint.lower() == 'uinlister.exe' and fields.get('action','').upper() == 'A' and positional:
                    payload = _chat_directory_html()
                    log.warning('LEGACY UIN DIRECTORY live=yes rows_dynamic=yes')
                    content_type = 'text/html; charset=windows-1252'
                elif endpoint.lower() == 'uinlister.exe' and fields.get('action','').upper() == 'U':
                    selected = _chat_safe_uin(raw_tokens[0][1:] if raw_tokens else fields.get('uin', ''))
                    payload = _chat_uin_contact_html(selected)
                    log.warning('LEGACY UIN DIRECTORY CONTACT PAGE target=<hidden>')
                    content_type = 'text/html; charset=windows-1252'
                elif native_contacts:
                    payload = _native_contact_status(body_text)
                    content_type = 'text/plain; charset=windows-1252'
                else:
                    payload = _chat_legacy_response(fields, endpoint)
                    content_type = 'text/plain; charset=windows-1252'
                self.safe_write((f"HTTP/1.0 {response_status}\r\n"
                                 f"Content-Type: {content_type}\r\n"
                                 f"Content-Length: {len(payload)}\r\n"
                                 "Cache-Control: no-store\r\n"
                                 "Connection: close\r\n\r\n").encode("ascii"))
                if method != "HEAD":
                    self.safe_write(payload)
                return

            if parsed.path == '/model_image' and (parsed.hostname or '').lower() in {
                    '127.0.0.1', 'localhost', 'proxy.local'}:
                key = urllib.parse.parse_qs(parsed.query).get('key', [''])[0]
                with MODEL_IMAGES_LOCK:
                    data = MODEL_IMAGES.get(key)
                if data is None:
                    self.send_simple(404, 'Not Found', 'Reload the model page to fetch its image.')
                else:
                    self.safe_write((f'HTTP/1.0 200 OK\r\nContent-Type: image/gif\r\n'
                                     f'Content-Length: {len(data)}\r\nCache-Control: no-store\r\n'
                                     'Connection: close\r\n\r\n').encode('ascii'))
                    self.safe_write(data)
                return

            # Direct local recreation of the old weather.unisys.com tree.
            # Example: /index.php, /foresetup.php, /satellite/index.php,
            # /gfs/index.php?r=us.  Keep these URLs visible and interactive
            # instead of exposing /weather_archive?url=... in the browser.
            local_weather_pages = {
                "/", "/index.php", "/solutions/index.php", "/mobile/index.php",
                "/info/index.php", "/content.php", "/analyses.php",
                "/satellite/index.php", "/surface/index.php", "/upper_air/index.php",
                "/radar/index.php", "/forehome.php", "/foresetup.php",
                "/mos/index.php", "/nam/index.php", "/gfs/index.php",
                "/gfsx/index.php", "/rap/index.php", "/ecmwf/index.php",
                "/archives.php", "/hurricane/index.php", "/archive/index.php",
                "/usgs/index.php", "/links.php", "/overview.php", "/contactus.php",
            }
            if ((parsed.hostname or "").lower() in {"127.0.0.1", "localhost", "proxy.local"}
                    and parsed.path.lower() in local_weather_pages):
                original_url = "http://weather.unisys.com" + parsed.path
                if parsed.query:
                    original_url += "?" + parsed.query
                archive_path = parsed.path.lower()
                # Current imagery is available for these three products.
                # Model/archive pages retain their own mirrored content.
                if archive_path.endswith("/analyses.php") or archive_path in {
                        "/satellite/index.php", "/surface/index.php", "/radar/index.php"}:
                    self.send_live_weather_maps(original_url)
                elif archive_path in {'/gfs/index.php', '/nam/index.php', '/rap/index.php'} and not urllib.parse.parse_qs(parsed.query).get('archive'):
                    self.send_current_model(parsed)
                elif self.send_local_weather_file(parsed):
                    pass
                else:
                    self.send_html(404, "Local weather page not downloaded", self.weather_shell(
                        '<div style="padding:12px"><h2>Local weather page not downloaded</h2>'
                        '<p>Run <b>DOWNLOAD_UNISYS_2013.bat</b> once, then reload this page.</p>'
                        '<p>This route no longer waits for the Wayback Machine.</p></div>'))
                return

            if parsed.path == "/weather_archive" and parsed.hostname in {
                    "127.0.0.1", "localhost", "proxy.local", "weather.unisys.com",
                    "www.weather.unisys.com"}:
                archive_url = urllib.parse.parse_qs(parsed.query).get("url", [""])[0]
                archive_path = urllib.parse.urlsplit(archive_url).path.lower()
                if archive_path.endswith("/analyses.php") or archive_path in {
                        "/satellite/index.php", "/surface/index.php", "/radar/index.php"}:
                    self.send_live_weather_maps(archive_url)
                else:
                    self.send_weather_archive(archive_url)
                return

            if parsed.path == "/weather_live_maps" and parsed.hostname in {
                    "127.0.0.1", "localhost", "proxy.local", "weather.unisys.com",
                    "www.weather.unisys.com"}:
                kind = urllib.parse.parse_qs(parsed.query).get("kind", ["satellite"])[0]
                fake_url = {"radar": "http://weather.unisys.com/radar/index.php",
                            "surface": "http://weather.unisys.com/surface/index.php"}.get(
                                kind, "http://weather.unisys.com/satellite/index.php")
                self.send_live_weather_maps(fake_url)
                return

            if parsed.path == "/weather_live_image" and parsed.hostname in {
                    "127.0.0.1", "localhost", "proxy.local", "weather.unisys.com",
                    "www.weather.unisys.com"}:
                kind = urllib.parse.parse_qs(parsed.query).get("kind", ["satellite"])[0]
                self.send_live_weather_image(kind)
                return

            # Every nested page and image included in weather_site can be
            # opened through the local proxy, including model and archive
            # subpages that were missing from the short list above.
            # Forecast endpoints are dynamic: a mirrored /forecast.php file
            # must not shadow any live location request.
            if (parsed.hostname or "").lower() in {
                    "127.0.0.1", "localhost", "proxy.local", "weather.unisys.com",
                    "www.weather.unisys.com"} and not re.search(
                    r"/forecast\.(?:cgi|php)(?:/|$)", parsed.path.lower()
                    ) and self.send_local_weather_file(parsed):
                return

            # Keep the original HTML news page available with current headlines.
            if parsed.path.rstrip("/").lower().endswith("/news/newspage.html"):
                try:
                    self.send_cyberbuddy_newspage()
                except Exception as error:
                    log.error("CYBERBUDDY NEWSPAGE: could not get news: %s", error)
                    self.send_simple(502, "Bad Gateway", "News is temporarily unavailable.")
                return

            # CyberBuddy requests both /CyberBuddy/news1.html on yeayou.com
            # and /news/news1.html on thecyberbuddy.com during startup. These
            # files are read as commands, so HTML (including <!DOCTYPE>) is
            # spoken literally. Serve the same live command format as news3.
            news_path = parsed.path.rstrip("/").lower()
            news_host = (parsed.hostname or "").lower()
            legacy_news_hosts = {
                "yeayou.com", "www.yeayou.com",
                "thecyberbuddy.com", "www.thecyberbuddy.com",
                "mycyberbuddy.com", "www.mycyberbuddy.com",
            }
            if (news_path.endswith("/news3.html") or
                    (news_host in legacy_news_hosts and news_path in {
                        "/cyberbuddy/news1.html", "/cyberbuddy/news2.html",
                        "/news/news1.html", "/news/news2.html"})):
                try:
                    self.send_cyberbuddy_news3()
                except Exception as error:
                    log.error("CYBERBUDDY NEWS: could not get news for %s: %s", news_path, error)
                    self.send_html(502, "Bad Gateway", "&&Read\r\nNews is temporarily unavailable.\r\n")
                return


            # The original Yahoo page with s= empty contained a symbol form.
            # Keep its GET form locally so the legacy browser can submit it.
            if (parsed.hostname or "").lower() in {"finance.yahoo.com", "quote.yahoo.com"} \
                    and parsed.path.lower().rstrip("/") in {"/q/cq", "/q"}:
                values = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
                if method == "POST" and request_body:
                    values.update(urllib.parse.parse_qs(request_body.decode("cp1252", "replace"),
                                                         keep_blank_values=True))
                symbols = values.get("s", [""])[0].strip()
                if not symbols:
                    self.send_html(200, "OK", '<html><head><meta http-equiv="Content-Type" '
                                   'content="text/html; charset=windows-1252"><title>Stocks</title></head>'
                                   '<body><h2>Stocks</h2><form method="GET" '
                                   'action="http://finance.yahoo.com/q/cq">'
                                   '<label>Enter Symbol(s): <input type="text" name="s" size="15"></label>'
                                   '<input type="hidden" name="d" value="v1">'
                                   '<input type="submit" value="GO"></form>'
                                   '<p>Examples: AAPL, PETR4.SA, VALE3.SA.</p></body></html>')
                    log.info("LEGACY STOCKS no ticker -> 200 local")
                    return
                if symbols.casefold() in {"apple computer", "apple inc", "apple inc.", "apple"}:
                    self.send_html(200, "OK", '<html><head><meta http-equiv="Content-Type" '
                                   'content="text/html; charset=windows-1252"><title>Stocks</title></head>'
                                   '<body><h2>Stocks</h2><p>"Apple Computer" is a company name, '
                                   'not a ticker symbol. Enter <b>AAPL</b> instead.</p>'
                                   '<form method="GET" action="http://finance.yahoo.com/q/cq">'
                                   '<input name="s" value="AAPL"><input type="hidden" name="d" value="v1">'
                                   '<input type="submit" value="GO"></form></body></html>')
                    log.info("LEGACY STOCKS nome Apple Computer -> orientar AAPL")
                    return
                tickers = list(dict.fromkeys(re.split(r"[,;\s]+", symbols.upper())))
                if len(tickers) > 10:
                    self.send_simple(400, "Bad Request", "Use at most 10 ticker symbols.")
                    return
                quotes, errors = [], []
                for ticker in tickers:
                    if not ticker:
                        continue
                    try:
                        quotes.append(fetch_stock_quote(ticker))
                    except (ValueError, RuntimeError, OSError, KeyError, TypeError) as error:
                        errors.append(str(error))
                if not quotes:
                    self.send_html(502, "Bad Gateway", '<html><body><h2>Quotes unavailable</h2><p>' +
                                   html.escape(" ".join(errors)) + '</p></body></html>')
                    return
                rows = "".join('<tr>' + ''.join('<td>' + html.escape(value) + '</td>'
                                              for value in stock_fields(quote)) + '</tr>'
                               for quote in quotes)
                notes = "".join('<p>' + html.escape(q["symbol"] + ' currency: ' + q["currency"]) + '</p>' for q in quotes)
                self.send_html(200, "OK", '<html><head><title>Stock Quotes</title></head><body>' +
                               '<table><tr><th>Symbol</th><th>Quote time</th><th>Last price</th>' +
                               '<th>Change</th><th>Change %</th><th>Volume</th></tr>' + rows + '</table>' +
                               '<p>Yahoo Finance provider-reported quotes; prices may be delayed. ' +
                               'Times are UTC. No estimate is shown when a quote is unavailable.</p>' + notes +
                               ''.join('<p>' + html.escape(error) + '</p>' for error in errors) +
                               '<form method="GET" action="http://finance.yahoo.com/q/cq">' +
                               '<input name="s"><input type="hidden" name="d" value="v1">' +
                               '<input type="submit" value="GO"></form></body></html>')
                log.info("LEGACY STOCKS -> %d provider quotes", len(quotes))
                return

            # Local files from the user's archived Unisys page; never forward
            # them to the discontinued site or serve arbitrary disk paths.
            weather_hosts = {"weather.unisys.com", "www.weather.unisys.com",
                             "67.98.102.223", "127.0.0.1", "localhost"}
            if (parsed.hostname or "").lower() in weather_hosts and parsed.path.startswith("/weather_assets/"):
                self.send_weather_asset(parsed.path.removeprefix("/weather_assets/"))
                return

            # Replace retired CyberBuddy weather, joke, and thought services.
            path_lower = parsed.path.lower()
            weather_endpoint = next((part for part in ("forecast.cgi", "forecast.php")
                                     if re.search(r"/" + re.escape(part) + r"(?:/|$)", path_lower)), None)
            if weather_endpoint and (parsed.hostname or "").lower() in weather_hosts:
                query_values = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
                if "\ufffd" in str(query_values):
                    query_values = urllib.parse.parse_qs(parsed.query, keep_blank_values=True,
                                                         encoding="cp1252", errors="replace")
                # The 2001 Unisys form submits Name in the POST body. Decode
                # percent escapes as UTF-8 when possible and as Windows-1252
                # for old browsers; do not replace accented letters with '?'.
                form_values = {}
                for pair in (request_body or b"").split(b"&"):
                    if not pair:
                        continue
                    raw_key, _, raw_value = pair.partition(b"=")
                    key = urllib.parse.unquote_to_bytes(raw_key.replace(b"+", b" ")).decode("ascii", "ignore")
                    value_bytes = urllib.parse.unquote_to_bytes(raw_value.replace(b"+", b" "))
                    try:
                        value = value_bytes.decode("utf-8")
                    except UnicodeDecodeError:
                        value = value_bytes.decode("cp1252", "replace")
                    form_values.setdefault(key, []).append(value)
                values = {k.lower(): v for k, v in {**query_values, **form_values}.items()}
                location = (values.get("place", [""])[0]
                            or values.get("location", [""])[0]
                            or values.get("name", [""])[0]
                            or values.get("city", [""])[0]
                            or values.get("zip", [""])[0]
                            or values.get("airport", [""])[0]).strip()
                # Old CyberBuddy variants send the place as a bare query:
                # /forecast.cgi?Goiania, without a field name.
                if not location and parsed.query and "=" not in parsed.query:
                    location = urllib.parse.unquote_plus(parsed.query).strip()
                # The archived Unisys endpoint also accepts /forecast.cgi/<ZIP>,
                # /forecast.cgi/<city>, or /forecast.cgi/<airport>.  Preserve
                # that value instead of silently falling back to Formosa.
                if not location:
                    marker = "/" + weather_endpoint + "/"
                    marker_pos = parsed.path.lower().find(marker)
                    if marker_pos >= 0:
                        suffix = parsed.path[marker_pos + len(marker):]
                        location = urllib.parse.unquote(suffix).strip(" /")
                # The original forecast page may submit a blank Name field
                # while loading its saved/default location. Use a configured
                # city so the 2013 layout contains current weather instead of
                # the archived report or another empty form.
                if not location and "name" in values:
                    location = CFG.get("weather", "default_location", fallback="Formosa, Goiás, Brasil").strip()
                if not location:
                    log.info("LEGACY WEATHER %s %s request has no location", method, parsed.path)
                    self.send_weather_form(weather_endpoint)
                    return
                log.info("LEGACY WEATHER received: %s %s / location=%s", method,
                         parsed.path + ("?" + parsed.query if parsed.query else ""), location)
                unit = values.get("unit", [""])[0].strip().lower()
                try:
                    self.send_legacy_weather(location, unit_override=unit, weather_endpoint=weather_endpoint)
                except RuntimeError as error:
                    self.send_html(503, "Weather temporarily unavailable",
                                   self.weather_shell("<p>" + html.escape(str(error)) + "</p>"))
                return
            fun_host = (parsed.hostname or "").lower() in {
                "yeayou.com", "www.yeayou.com", "66.135.38.69",
                "66.135.47.52", "thecyberbuddy.com", "www.thecyberbuddy.com",
                "mycyberbuddy.com", "www.mycyberbuddy.com",
            }
            if fun_host and (path_lower.endswith("/jokeserver.exe") or path_lower.endswith("/jokeserve.exe")):
                log.info("LEGACY JOKE host=%s query=%s", parsed.hostname, parsed.query)
                self.send_legacy_fun("joke")
                return
            if fun_host and path_lower.endswith("/thoughts.exe"):
                log.info("LEGACY THOUGHT host=%s query=%s", parsed.hostname, parsed.query)
                self.send_legacy_fun("thought")
                return

            # Browsers/CyberBuddy may send an absolute URL using the host LAN IP
            # (for example http://192.168.18.158:8081/...). If that address is
            # this proxy's own listener, never forward it back into ourselves.
            # Otherwise the proxy can recurse into itself and produce repeated
            # "Upstream <our-IP>:8081 failed: timed out" messages.
            listener_port = PORT
            try:
                listener_port = int(self.server.server_address[1])
            except Exception:
                pass

            local_hostnames = {"127.0.0.1", "localhost", "::1", "proxy.local", "cyberbuddy.proxy"}
            local_addresses = set()
            try:
                local_addresses.update(
                    socket.gethostbyname_ex(socket.gethostname())[2]
                )
            except Exception:
                pass
            try:
                bound_host = str(self.server.server_address[0])
                if bound_host and bound_host not in {"0.0.0.0", "::"}:
                    local_addresses.add(bound_host)
            except Exception:
                pass
            # The connection's local endpoint is authoritative when available.
            try:
                local_addresses.add(str(self.connection.getsockname()[0]))
            except Exception:
                pass

            parsed_host = (parsed.hostname or "").lower()
            local_listener = (
                parsed.port == listener_port
                and (parsed_host in local_hostnames or parsed_host in local_addresses)
            )

            if parsed_host in {"proxy.local", "cyberbuddy.proxy"} or local_listener:
                # favicon requests generated by the browser must never enter
                # the generic upstream path. Returning an empty icon response
                # also stops the request loop that can otherwise flood the log.
                if parsed.path.lower() in {"/favicon.ico", "/favicon.png"}:
                    self.safe_write(
                        b"HTTP/1.0 204 No Content\\r\\n"
                        b"Cache-Control: no-store\\r\\n"
                        b"Connection: close\\r\\n\\r\\n"
                    )
                    return
                if parsed.path.rstrip("/").lower() == "/news":
                    try:
                        self.send_legacy_news_page()
                    except Exception as error:
                        log.error("PAGE CHECK failed: %s", error)
                        self.send_simple(502, "Bad Gateway", "Page temporarily unavailable.")
                    return
                if parsed.path.rstrip('/').lower() in ('/cyber/activity','/cyber/help'):
                    if not self.client_address[0].startswith('127.'):
                        self.send_simple(403, 'Forbidden', 'Open this local bot page on the host computer.')
                        return
                    try:
                        import cyber_classic
                        if parsed.path.rstrip('/').lower()=='/cyber/activity':
                            page=cyber_classic.activity_html(cyber_bot.MEMORY)
                        else:
                            page=(ROOT/'CLASSIC_HELP.html').read_text(encoding='utf-8')
                        self.send_html(200, 'OK', page)
                    except (OSError,ValueError,TypeError):
                        self.send_simple(503, 'Unavailable', 'The local Cyber page could not be loaded.')
                    return
                if local_listener and parsed.path not in {"", "/"}:
                    self.send_simple(404, "Not Found", "No such local proxy page.")
                    return
                self.send_simple(
                    200,
                    "OK",
                    f"{APP_NAME} {APP_VERSION} is running on port {PORT}. "
                    "Web Watching: http://proxy.local/news",
                )
                return

            outgoing_headers = {}
            for key, value in headers.items():
                if key.lower() not in HOP_BY_HOP and key.lower() not in {"host", "accept-encoding", "content-length"}:
                    outgoing_headers[key] = value
            outgoing_headers["User-Agent"] = CFG.get(
                "upstream",
                "user_agent",
                fallback="Mozilla/5.0 (Windows NT 10.0; Win64; x64) CyberBuddyClassicProxy/6.2",
            )
            outgoing_headers["Accept-Encoding"] = "identity"

            req = urllib.request.Request(
                target,
                data=request_body,
                headers=outgoing_headers,
                method=method,
            )
            opener = direct_opener()

            try:
                response = opener.open(req, timeout=TIMEOUT)
            except urllib.error.HTTPError as error:
                response = error

            status = response.status
            reason = getattr(response, "reason", "") or ""
            response_body = b"" if method == "HEAD" else response.read(MAX_BODY_MB * 1024 * 1024 + 1)
            if len(response_body) > MAX_BODY_MB * 1024 * 1024:
                self.send_simple(502, "Response Too Large", "The response exceeds the configured size limit.")
                return

            response_body = decode_body(response_body, response.headers.get("Content-Encoding"))
            if parsed.path.lower().endswith(("/cbonline2.exe", "/uinlister.exe", "/uinserver.exe")):
                # Inspect only structural markers. Never log a chat message,
                # login body, UIN, email address or query value.
                marker_found = any(marker in response_body for marker in (b"$$UIN", b"$$SNDTO", b"$$MYIP", b"&&EOT"))
                if status == 405:
                    detail = "server rejected request method; native protocol handler needed"
                elif status == 404:
                    detail = "directory endpoint missing; native protocol handler needed"
                elif status >= 400:
                    detail = "upstream chat service error"
                elif not marker_found:
                    detail = "HTTP response received without known legacy chat markers; message delivery is not confirmed"
                else:
                    detail = "legacy chat markers detected; message delivery still requires two-client verification"
                log.warning("LEGACY CHAT method=%s endpoint=%s status=%s bytes=%d markers=%s: %s",
                            method, parsed.path.rsplit("/", 1)[-1], status,
                            len(response_body), marker_found, detail)

            content_type = response.headers.get("Content-Type", "application/octet-stream")
            response_body, content_type = make_legacy_compatible(response_body, content_type)

            self.wfile.write(f"HTTP/1.0 {status} {reason}\r\n".encode("iso-8859-1", "replace"))
            for key, value in response.headers.items():
                lower = key.lower()
                if lower in HOP_BY_HOP or lower in {"content-length", "content-type", "content-encoding"}:
                    continue
                self.wfile.write(f"{key}: {value}\r\n".encode("iso-8859-1", "replace"))
            self.wfile.write(f"Content-Type: {content_type}\r\n".encode("iso-8859-1", "replace"))
            self.wfile.write(f"Content-Length: {len(response_body)}\r\n".encode("ascii"))
            self.wfile.write(b"Connection: close\r\n\r\n")
            if method != "HEAD":
                self.wfile.write(response_body)
            log.info("%s %s -> %s (%d bytes)", method, urllib.parse.urlunsplit((parsed.scheme, parsed.netloc.rsplit("@", 1)[-1], parsed.path, "[redacted]" if parsed.query else "", "")), status, len(response_body))

        except (ValueError, UnicodeError) as error:
            log.warning("Invalid request from %s: %s", self.client_address[0], error)
            self.send_simple(400, "Bad Request", f"Invalid request: {error}")
        except (urllib.error.URLError, socket.timeout, TimeoutError) as error:
            log_upstream_failure(target if 'target' in locals() else '', error)
            self.send_simple(502, "Bad Gateway", f"Could not access the address: {error}")
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            log.debug("Legacy client closed the connection; request finished")
        except Exception as error:
            log.exception("Unexpected error")
            try:
                self.send_simple(500, "Internal Server Error", f"Internal error: {error}")
            except Exception:
                pass

    def handle_connect(self, target: str):
        """Relay HTTPS unchanged so the Windows proxy does not break modern sites."""
        host, separator, port_text = target.rpartition(":")
        if not separator:
            host, port_text = target, "443"
        host = host.strip("[]")
        try:
            port = int(port_text)
        except ValueError:
            self.send_simple(400, "Bad Request", "Invalid HTTPS port.")
            return
        if not host or port < 1 or port > 65535:
            self.send_simple(400, "Bad Request", "Invalid HTTPS destination.")
            return

        if host.lower() in {"127.0.0.1", "localhost", "::1"} and port == PORT:
            self.send_simple(400, "Bad Request", "Cannot tunnel the proxy into itself.")
            return

        upstream = None
        try:
            upstream = socket.create_connection((host, port), timeout=TIMEOUT)
            self.connection.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
            sockets = [self.connection, upstream]
            while True:
                readable, _, exceptional = select.select(sockets, [], sockets, TIMEOUT)
                if exceptional or not readable:
                    break
                for source in readable:
                    data = source.recv(65536)
                    if not data:
                        return
                    destination = upstream if source is self.connection else self.connection
                    destination.sendall(data)
            log.debug("CONNECT %s:%d closed", host, port)
        except (OSError, socket.timeout) as error:
            log_upstream_failure("https://" + host, error)
            if upstream is None:
                try:
                    self.send_simple(502, "Bad Gateway", "Could not open the HTTPS tunnel.")
                except OSError:
                    pass
        finally:
            if upstream is not None:
                try:
                    upstream.close()
                except OSError:
                    pass


class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


class TLSBridgeHandler(socketserver.BaseRequestHandler):
    remote_host = ""
    remote_port = 0
    bridge_name = "TLS"
    failure_reply = b"-ERR Secure bridge unavailable\r\n"

    def handle(self):
        upstream = None
        try:
            raw = socket.create_connection((self.remote_host, self.remote_port), timeout=TIMEOUT)
            upstream = tls_context().wrap_socket(raw, server_hostname=self.remote_host)
            log.info(
                "%s: secure connection established to %s:%d",
                self.bridge_name,
                self.remote_host,
                self.remote_port,
            )
            sockets = [self.request, upstream]
            while True:
                readable, _, exceptional = select.select(sockets, [], sockets, TIMEOUT)
                if exceptional or not readable:
                    break
                for source in readable:
                    data = source.recv(65536)
                    if not data:
                        return
                    destination = upstream if source is self.request else self.request
                    destination.sendall(data)
        except Exception as error:
            log.error("%s: could not establish a secure connection: %s", self.bridge_name, error)
            try:
                self.request.sendall(self.failure_reply)
            except OSError:
                pass
        finally:
            if upstream is not None:
                try:
                    upstream.close()
                except OSError:
                    pass


def decode_mail_header_value(value: bytes) -> bytes:
    """Decode RFC 2047/UTF-8 headers for mail clients from the Windows 98 era."""
    try:
        source = value.decode("ascii")
    except UnicodeDecodeError:
        for charset in ("utf-8", "cp1252"):
            try:
                return value.decode(charset).encode("cp1252", "replace")
            except UnicodeDecodeError:
                continue
        return value.decode("latin-1", "replace").encode("cp1252", "replace")
    pieces = []
    try:
        decoded = email.header.decode_header(source)
    except (LookupError, UnicodeError):
        decoded = [(value, None)]
    for part, charset in decoded:
        if isinstance(part, str):
            pieces.append(part)
            continue
        candidates = [charset, "utf-8", "cp1252"] if charset else ["utf-8", "cp1252"]
        for candidate in candidates:
            if not candidate:
                continue
            try:
                pieces.append(part.decode(candidate))
                break
            except (LookupError, UnicodeError):
                continue
        else:
            pieces.append(part.decode("latin-1", "replace"))
    return "".join(pieces).encode("cp1252", "replace")


def convert_pop3_message_headers(lines: list[bytes]) -> list[bytes]:
    """Return POP3 message lines with readable Windows-1252 mail headers."""
    try:
        separator = lines.index(b"\r\n")
    except ValueError:
        separator = len(lines)

    logical_headers: list[list[bytes]] = []
    for line in lines[:separator]:
        if line[:1] in {b" ", b"\t"} and logical_headers:
            logical_headers[-1].append(line)
        else:
            logical_headers.append([line])

    converted: list[bytes] = []
    for physical in logical_headers:
        first = physical[0].rstrip(b"\r\n")
        if b":" not in first:
            converted.extend(physical)
            continue
        name, value = first.split(b":", 1)
        continuation = [item.strip(b" \t\r\n") for item in physical[1:]]
        unfolded = b" ".join([value.strip()] + continuation)
        decoded_value = decode_mail_header_value(unfolded)
        converted.append(name + b": " + decoded_value + b"\r\n")

    if separator < len(lines):
        converted.append(b"\r\n")
        converted.extend(lines[separator + 1:])
    return converted


class _HTMLTextExtractor(HTMLParser):
    block_tags = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.ignored = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in {"script", "style", "head"}:
            self.ignored += 1
        elif tag in self.block_tags:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in {"script", "style", "head"} and self.ignored:
            self.ignored -= 1
        elif tag in self.block_tags:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.ignored:
            self.parts.append(data)

    def text(self) -> str:
        value = html.unescape("".join(self.parts)).replace("\xa0", " ")
        value = re.sub(r"[ \t]+", " ", value)
        value = re.sub(r" *\n *", "\n", value)
        value = re.sub(r"\n{3,}", "\n\n", value)
        return value.strip()


def _decode_text_part(part) -> str:
    payload = part.get_payload(decode=True)
    if payload is None:
        raw = part.get_payload()
        return raw if isinstance(raw, str) else ""
    candidates = [part.get_content_charset(), "utf-8", "cp1252", "latin-1"]
    for charset in candidates:
        if not charset:
            continue
        try:
            return payload.decode(charset)
        except (LookupError, UnicodeDecodeError):
            continue
    return payload.decode("utf-8", "replace")


def convert_pop3_message_to_legacy(lines: list[bytes]) -> list[bytes]:
    """Flatten a modern MIME e-mail into plain Windows-1252 text."""
    # POP3 dot-stuffing is transport syntax, not part of the message.
    raw_lines = [line[1:] if line.startswith(b"..") else line for line in lines]
    raw_message = b"".join(raw_lines)
    try:
        message = email.parser.BytesParser(policy=email.policy.default).parsebytes(raw_message)
    except Exception:
        return convert_pop3_message_headers(lines)

    plain_parts: list[str] = []
    html_parts: list[str] = []
    parts = message.walk() if message.is_multipart() else [message]
    for part in parts:
        if part.is_multipart() or part.get_content_disposition() == "attachment":
            continue
        kind = part.get_content_type().lower()
        if kind not in {"text/plain", "text/html"}:
            continue
        decoded = _decode_text_part(part)
        if kind == "text/plain" and decoded.strip():
            plain_parts.append(decoded)
        elif kind == "text/html" and decoded.strip():
            extractor = _HTMLTextExtractor()
            try:
                extractor.feed(decoded)
                cleaned = extractor.text()
            except Exception:
                cleaned = re.sub(r"<[^>]+>", " ", decoded)
            if cleaned:
                html_parts.append(cleaned)

    body = "\n\n".join(plain_parts or html_parts).strip()
    if not body:
        body = "This message has no compatible text content."
    body = body.replace("\r\n", "\n").replace("\r", "\n")

    output: list[bytes] = []
    for name in ("From", "To", "Cc", "Date", "Subject", "Reply-To", "Message-ID"):
        values = message.get_all(name, [])
        for value in values:
            encoded = str(value).encode("cp1252", "replace")
            output.append(name.encode("ascii") + b": " + encoded + b"\r\n")
    output.extend([
        b"MIME-Version: 1.0\r\n",
        b"Content-Type: text/plain; charset=windows-1252\r\n",
        b"Content-Transfer-Encoding: 8bit\r\n",
        b"\r\n",
    ])
    for text_line in body.split("\n"):
        wire_line = text_line.encode("cp1252", "replace")
        if wire_line.startswith(b"."):
            wire_line = b"." + wire_line
        output.append(wire_line + b"\r\n")
    return output


class POP3BridgeHandler(socketserver.StreamRequestHandler):
    remote_host = POP3_REMOTE_HOST
    remote_port = POP3_REMOTE_PORT
    bridge_name = "POP3"
    failure_reply = b"-ERR Could not connect to secure POP3 server\r\n"

    @staticmethod
    def is_multiline(command: str, response: bytes) -> bool:
        if not response.startswith(b"+OK"):
            return False
        verb, _, argument = command.partition(" ")
        return verb in {"RETR", "TOP", "CAPA"} or (verb in {"LIST", "UIDL"} and not argument)

    def handle(self):
        upstream = None
        pending_username = None
        pending_password = None
        try:
            raw = socket.create_connection((self.remote_host, self.remote_port), timeout=TIMEOUT)
            upstream = tls_context().wrap_socket(raw, server_hostname=self.remote_host)
            upstream_file = upstream.makefile("rb")
            greeting = upstream_file.readline(65537)
            if not greeting:
                raise ConnectionError("POP3 server did not send a greeting")
            self.wfile.write(greeting)
            self.wfile.flush()
            log.info("POP3: secure connection established to %s:%d", self.remote_host, self.remote_port)

            while True:
                client_line = self.rfile.readline(65537)
                if not client_line:
                    return
                upstream.sendall(client_line)
                command = client_line.decode("ascii", "ignore").strip().upper()
                original_command = client_line.decode("utf-8", "replace").strip()
                verb, _, argument = original_command.partition(" ")
                if verb.upper() == "USER" and argument:
                    pending_username = argument.strip()
                elif verb.upper() == "PASS" and argument:
                    pending_password = argument.strip().replace(" ", "")
                response = upstream_file.readline(65537)
                if not response:
                    return
                self.wfile.write(response)

                if command.startswith("PASS ") and response.startswith(b"+OK"):
                    if pending_username and pending_password:
                        with MAIL_CREDENTIALS_LOCK:
                            MAIL_CREDENTIALS["username"] = pending_username
                            MAIL_CREDENTIALS["password"] = pending_password
                        _save_mail_credentials(pending_username, pending_password)
                        log.info("POP3: temporary credentials are available for SMTP")

                if self.is_multiline(command, response):
                    lines = []
                    while True:
                        line = upstream_file.readline(1024 * 1024 + 1)
                        if not line:
                            return
                        if line == b".\r\n":
                            break
                        lines.append(line)
                    if command.startswith("RETR "):
                        lines = convert_pop3_message_to_legacy(lines)
                    elif command.startswith("TOP "):
                        # CyberBuddy commonly uses TOP with a large line count
                        # instead of RETR when opening/reading a message.
                        pieces = command.split()
                        requested_body_lines = 0
                        if len(pieces) >= 3:
                            try:
                                requested_body_lines = int(pieces[2])
                            except ValueError:
                                pass
                        if requested_body_lines > 0:
                            lines = convert_pop3_message_to_legacy(lines)
                        else:
                            lines = convert_pop3_message_headers(lines)
                    for line in lines:
                        self.wfile.write(line)
                    self.wfile.write(b".\r\n")
                self.wfile.flush()
                if command == "QUIT":
                    return
        except Exception as error:
            log.error("POP3: could not connect or process data securely: %s", error)
            try:
                self.wfile.write(self.failure_reply)
                self.wfile.flush()
            except OSError:
                pass
        finally:
            if upstream is not None:
                try:
                    upstream.close()
                except OSError:
                    pass


class SMTPBridgeHandler(socketserver.StreamRequestHandler):
    """Accept legacy plain SMTP locally and submit it to Gmail with TLS/AUTH."""

    def reply(self, text: str):
        self.wfile.write(text.encode("ascii", "replace") + b"\r\n")
        self.wfile.flush()

    @staticmethod
    def address_from_command(command: str) -> str:
        value = command.split(":", 1)[1].strip() if ":" in command else ""
        value = value.split(" ", 1)[0].strip()
        return value.strip("<>")

    @staticmethod
    def decode_b64(value: str) -> str:
        return base64.b64decode(value.strip()).decode("utf-8", "replace")

    def authenticate_legacy_client(self, command: str) -> bool:
        pieces = command.split()
        mechanism = pieces[1].upper() if len(pieces) > 1 else ""
        try:
            if mechanism == "PLAIN":
                token = pieces[2] if len(pieces) > 2 else ""
                if not token:
                    self.reply("334 ")
                    token = self.rfile.readline(65537).decode("ascii", "ignore").strip()
                decoded = base64.b64decode(token).decode("utf-8", "replace")
                _authorization, username, password = decoded.split("\x00", 2)
            elif mechanism == "LOGIN":
                if len(pieces) > 2:
                    username = self.decode_b64(pieces[2])
                else:
                    self.reply("334 VXNlcm5hbWU6")
                    username = self.decode_b64(self.rfile.readline(65537).decode("ascii", "ignore"))
                self.reply("334 UGFzc3dvcmQ6")
                password = self.decode_b64(self.rfile.readline(65537).decode("ascii", "ignore"))
            else:
                self.reply("504 5.5.4 Use AUTH LOGIN or AUTH PLAIN")
                return False
        except Exception:
            self.reply("501 5.5.2 Invalid authentication data")
            return False

        with MAIL_CREDENTIALS_LOCK:
            MAIL_CREDENTIALS["username"] = username.strip()
            MAIL_CREDENTIALS["password"] = password.strip().replace(" ", "")
        _save_mail_credentials(username.strip(), password.strip().replace(" ", ""))
        self.reply("235 2.7.0 Authentication accepted by local bridge")
        log.info("SMTP: temporary credentials received from the legacy client")
        return True

    def submit_to_gmail(self, sender: str, recipients: list[str], message: bytes):
        with MAIL_CREDENTIALS_LOCK:
            username = MAIL_CREDENTIALS["username"]
            password = MAIL_CREDENTIALS["password"]
        if not username or not password:
            raise PermissionError("use Get Email Now first to provide temporary credentials")

        # Some old clients omit modern headers. Gmail accepts the legacy body
        # once minimum From/To headers are supplied.
        header_block = message.split(b"\r\n\r\n", 1)[0].lower()
        additions = []
        if b"from:" not in header_block:
            additions.append(f"From: {sender or username}\r\n".encode("cp1252", "replace"))
        if b"to:" not in header_block:
            additions.append(f"To: {', '.join(recipients)}\r\n".encode("cp1252", "replace"))
        if additions:
            message = b"".join(additions) + message

        with smtplib.SMTP_SSL(
            SMTP_REMOTE_HOST,
            SMTP_REMOTE_PORT,
            timeout=TIMEOUT,
            context=tls_context(),
        ) as smtp:
            smtp.login(username, password)
            smtp.sendmail(sender or username, recipients, message)

    def handle(self):
        sender = ""
        recipients: list[str] = []
        self.reply("220 CyberBuddy Classic Proxy 2.0 SMTP bridge ready")
        log.info("SMTP: cliente antigo conectado em %s", self.client_address[0])
        while True:
            raw = self.rfile.readline(65537)
            if not raw:
                return
            command = raw.decode("iso-8859-1", "replace").strip()
            upper = command.upper()

            if upper.startswith("EHLO"):
                self.reply("250-CyberBuddy Classic Proxy")
                self.reply("250-AUTH LOGIN PLAIN")
                self.reply("250 8BITMIME")
            elif upper.startswith("HELO"):
                self.reply("250 CyberBuddy Classic Proxy")
            elif upper.startswith("AUTH "):
                self.authenticate_legacy_client(command)
            elif upper.startswith("MAIL FROM:"):
                sender = self.address_from_command(command)
                recipients = []
                self.reply("250 2.1.0 Sender OK")
            elif upper.startswith("RCPT TO:"):
                recipient = self.address_from_command(command)
                if recipient:
                    recipients.append(recipient)
                    self.reply("250 2.1.5 Recipient OK")
                else:
                    self.reply("501 5.1.3 Invalid recipient")
            elif upper == "DATA":
                if not recipients:
                    self.reply("503 5.5.1 Need RCPT TO first")
                    continue
                self.reply("354 End data with <CRLF>.<CRLF>")
                lines = []
                while True:
                    line = self.rfile.readline(1024 * 1024 + 1)
                    if not line or line in {b".\r\n", b".\n"}:
                        break
                    if line.startswith(b".."):
                        line = line[1:]
                    lines.append(line.replace(b"\n", b"\r\n") if not line.endswith(b"\r\n") else line)
                try:
                    self.submit_to_gmail(sender, recipients, b"".join(lines))
                    self.reply("250 2.0.0 Message accepted for delivery")
                    log.info("SMTP: message sent successfully to %d recipient(s)", len(recipients))
                except PermissionError as error:
                    log.error("SMTP: credentials unavailable: %s", error)
                    self.reply("530 5.7.0 Check mail first, then try sending again")
                except smtplib.SMTPAuthenticationError as error:
                    log.error("SMTP: Gmail authentication refused (%s)", error.smtp_code)
                    self.reply("535 5.7.8 Gmail authentication failed")
                except Exception as error:
                    log.error("SMTP: could not send through Gmail: %s", error)
                    self.reply("451 4.3.0 Temporary Gmail submission failure")
                sender = ""
                recipients = []
            elif upper == "RSET":
                sender = ""
                recipients = []
                self.reply("250 2.0.0 Reset OK")
            elif upper == "NOOP":
                self.reply("250 2.0.0 OK")
            elif upper == "QUIT":
                self.reply("221 2.0.0 Bye")
                return
            else:
                self.reply("502 5.5.1 Command not implemented")


def start_bridge(bind: str, port: int, handler, name: str):
    try:
        server = ThreadedTCPServer((bind, port), handler)
    except OSError as error:
        log.error("%s could not start on %s:%d: %s", name, bind, port, error)
        print(f"WARNING: {name} could not start on port {port}: {error}")
        return None
    thread = threading.Thread(target=server.serve_forever, name=name, daemon=True)
    thread.start()
    log.info("%s started on %s:%d", name, bind, port)
    print(f"{name}: {bind}:{port}")
    return server


def main() -> int:
    print(f"{APP_NAME} {APP_VERSION}")
    print(f"Proxy: http://{BIND}:{PORT}")
    print(f"Test: configure the proxy and open http://proxy.local/")
    print("Remote Connection Request YES/NO page:")
    print(f"  http://127.0.0.1:{PORT}/REMOTE_CONNECTION_UIN_JOIN_REQUEST.html")
    print(f"  http://proxy.local:{PORT}/REMOTE_CONNECTION_UIN_JOIN_REQUEST.html")
    print(f"  Use THIS PC's LAN IP for other CyberBuddy clients: http://<LAN-IP>:{PORT}/REMOTE_CONNECTION_UIN_JOIN_REQUEST.html")
    print(f"Log: {LOG_PATH}")
    print("Press Ctrl+C to stop.\n")
    bridges = []
    if POP3_ENABLED:
        server = start_bridge(POP3_BIND, POP3_LOCAL_PORT, POP3BridgeHandler, "Secure POP3 bridge")
        if server:
            bridges.append(server)
    if SMTP_ENABLED:
        server = start_bridge(SMTP_BIND, SMTP_LOCAL_PORT, SMTPBridgeHandler, "Secure SMTP bridge")
        if server:
            bridges.append(server)
    try:
        with ThreadedTCPServer((BIND, PORT), ProxyHandler) as server:
            log.info("Server started on %s:%d", BIND, PORT)
            server.serve_forever()
    except OSError as error:
        print(f"ERROR: could not use {BIND}:{PORT}: {error}")
        return 1
    except KeyboardInterrupt:
        print("\nProxy stopped.")
    finally:
        for bridge in bridges:
            bridge.shutdown()
            bridge.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
