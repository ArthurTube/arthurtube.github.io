"""Offline Update 8 smoke test. Uses temporary profiles; never reads live memory."""
import json,tempfile
from pathlib import Path
import cyber_bot as bot,cyber_web as web,cyber_clock as clock

def main():
    original_memory=bot.MEMORY;original_lookup=web.wikipedia_answer;original_clock=clock._clock
    passed=[]
    def check(value,label):
        if not value:raise AssertionError(label)
        passed.append(label)
    try:
        with tempfile.TemporaryDirectory() as folder:
            bot.MEMORY=Path(folder)/'test_memory.json';bot.MEMORY.write_text('{}')
            ask=lambda q,user='1000':bot.reply(user,q,True)
            check('Classic Native LAN Patch 12' in ask('what version are you running'),'version')
            ask('my name is John');check(ask('what is my name')=='John','name')
            ask('I live Goias');check('Goiás, Brazil' in ask('where do I live'),'classic location grammar')
            ask('my birthdate is 04/03/2011');check('2011-04-03' in ask('when is my birthday'),'birthday')
            ask('remember my project is CyberBuddy Classic Proxy');check(ask('what is my project')=='CyberBuddy Classic Proxy','fact recall')
            ask('Bob is a fireman');check('fireman' in ask('who is Bob'),'teaching')
            ask(' and decline Cyber, Bob is not a fireman');check('removed' in ask('who is Bob'),'unlearning animation regression')
            ask('"Adios" is the same as "Good Bye"');check('Good Bye' in ask('what does Adios mean'),'quoted synonym')
            ask('"Adios" is not the same as "Good Bye"');check('not taught' in ask('what does Adios mean'),'synonym removal')
            ask('I have a dog named Sampson');check('Sampson' in ask("what is my dog's name"),'possession')
            check(ask('what is 2 times 2 + 5').rstrip('.')=='9','natural math')
            check('1 hour' in ask('convert 3600 seconds to hours'),'conversion')
            clock._clock=lambda *args:'CLOCK '+args[1]
            check('Europe/London' in ask('what time is it London'),'clock grammar')
            check('Europe/Madrid' in ask('what time is it Spain'),'Spain mapping')
            ask('my name is Alice','2000')
            ask('message for "UIN 2000" message is "Offline test message"')
            check('Offline test message' in ask('hello','2000'),'two-user queue')
            check('Offline test message' not in ask('hello','2000'),'queue not repeated')
            check('not told' in ask('where do I live','2000'),'UIN isolation')
            before=bot.MEMORY.read_bytes();check(bot.reply('1000','hello',False)=='','public addressing');check(before==bot.MEMORY.read_bytes(),'public silence does not write')
            check('January 2002' in ask('when were you born'),'classic identity')
            check('conversational AI recreation' in ask('are you a conversational AI'),'conversational role')
            bot.MEMORY.write_text('INVALID');check('not reset' in ask('my name is Other'),'malformed memory protection');check(bot.MEMORY.read_text()=='INVALID','malformed memory unchanged')
    finally:
        bot.MEMORY=original_memory;web.wikipedia_answer=original_lookup;clock._clock=original_clock
    print('PASS:',len(passed),'offline checks. Real profiles and settings were not read or reset.')
    print('Live research, native client acceptance, Windows installation and antivirus safety are separate checks.')
    return 0
if __name__=='__main__':raise SystemExit(main())
