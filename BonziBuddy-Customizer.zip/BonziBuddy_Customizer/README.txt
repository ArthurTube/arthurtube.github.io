BONZIBUDDY CUSTOMIZER
Target range: 2.0 through 4.1.0.9

Extract this ZIP to a writable folder. Install Python 3.8 or newer if needed.
Double-click START_CUSTOMIZER.bat. Enter your BonziBuddy data folder.
Press A to export ALL .nbd files in the selected folder as readable .txt files.
Or choose one jokes (J), facts (T), personality (P), or songs (S) NBD file.
Other .nbd filenames are listed too; only recognized layouts can be decoded.
Export it, edit its TXT in Notepad, save, validate, and apply with backup.
Close BonziBuddy before applying or restoring files. Restart it to test changes.

EDITING
Keep one record per line, the same number of records, and the first-line Header
prefix exactly as exported. Do not add [001] reading labels or a document title.
Use literal [username] where you want BonziBuddy to substitute your name.
Joke example: <sp=[username], why did the pencil take a nap?\pau=2000\It was tired of drawing conclusions!>
Use animations available in your installed character; preserve original commands
when replacing words. Pipes (|) separate alternatives in some personality files.
Songs use pitch/speed/pause commands. The editor preserves commands as text;
it does not compose a melody or check its musical accuracy.
Use Windows-1252-compatible characters in the UTF-8 TXT: avoid emoji.

The NBD encoding is based on uploaded joke/fact/song and personality samples.
Unedited exports re-encode to exactly the same bytes. Changed records reuse the
original filler bytes. Backups include the matching NBD-SR if present.
Selection-list files remain unchanged, since the number/order of records remains
fixed. Adding/removing/reordering records is outside this edition's workflow.
Readable files are stored beside the tool under readable; backups under backups.
For multiple installations, keep separate tool copies so readable names do not
mix. Existing readable exports are never silently overwritten.

Compatibility range is a target, not a claim of playback verification across
all releases. Unsupported byte layouts are rejected. Tests cover supplied files,
encoding/decoding, editing, backups and selection-list preservation. The Windows
BAT/Notepad flow and playback require testing on Windows with BonziBuddy.
No BonziBuddy executable or original databases are included. No downloads or
network access are performed by this customizer.

UPDATED TXT IMPORT
Blank lines, [001] reading labels, code fences and standard readable-report
headings are accepted. Missing first-line Header is restored from the original
NBD template. Actual record count must still match. Invalid lines are reported.
Action 3/4 show the matching TXT path. Action 6 lets you choose any edited TXT
and builds a NEW .nbd under rebuilt, without replacing the installed file.

TEST DATABASES — ACTION 7
Select the original NBD as a format template, then choose action 7 and a TXT
with one or more script records. This separate mode permits a different count,
including larger lists. Header is restored from the original template.
The test NBD is written under rebuilt, never over your installation. If the
original has a recognized comma-separated NBD-SR, a new shuffled list of
1..record count is written alongside it. Install the test NBD and matching SR
together after backing up your originals and closing BonziBuddy.
One-record example TXT: <sp=[username], why did the pencil rest?\pau=2000\It was all drawn out!>
Application limits and actual playback with resized files need Windows testing.
Other databases may still be chosen by BonziBuddy; a one-record file does not
force the program to choose that database instead of another installed file.
Actions 3, 4 and 6 still require the original count; use 7 for test lists.
