Arthur Tube unofficial BonziBUDDY 4.1.0.10 update, October 12, 2026.
Based on the supplied 4.1.0.9 client. This is an update package, not a complete installer.
Includes the supplied Portuguese EXE text edits and translated NBD files.
Close BonziBUDDY. Back up your complete existing program folder.
Copy these files into a separate copy of that folder, then run BonziBDY-4.1.0.10.exe.
Manual website links point to arthurtube.github.io. This does not replace the built-in browser.
Automatic updater downloads and legacy online service protocols were not repaired.
Runtime functionality, songs and speech require Windows testing.
The original program behavior has not been removed or certified safe.

Unofficial update Copyright 2026 Arthur Tube. Original Copyright 1999-2003 BONZI.COM Software is preserved.

Manual update links now point to the original Bonzi continuation page at /bonzibuddy/#dl.
