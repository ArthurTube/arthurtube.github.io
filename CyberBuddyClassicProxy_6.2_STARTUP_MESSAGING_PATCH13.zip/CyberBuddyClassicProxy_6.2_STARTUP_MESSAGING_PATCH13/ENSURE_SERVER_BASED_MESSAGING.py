"""CyberBuddy Classic Proxy 6.2 Patch 13.
Keeps the original CyberBuddy 'Use Server Based Instant Messaging' checkbox enabled
whenever its Advanced Options window/control is present. Uses Win32 only; no third-party packages.
"""
import ctypes, os, time
from ctypes import wintypes

LABEL = "Use Server Based Instant Messaging"
BM_GETCHECK = 0x00F0
BM_SETCHECK = 0x00F1
BM_CLICK = 0x00F5
BST_CHECKED = 1
WM_GETTEXT = 0x000D
WM_GETTEXTLENGTH = 0x000E

if os.name != "nt":
    raise SystemExit(0)

user32 = ctypes.WinDLL("user32", use_last_error=True)
EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
EnumChildProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

def text(hwnd):
    n = user32.SendMessageW(hwnd, WM_GETTEXTLENGTH, 0, 0)
    if n < 0 or n > 4096: return ""
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.SendMessageW(hwnd, WM_GETTEXT, n + 1, ctypes.byref(buf))
    return buf.value

def keep_checked(hwnd):
    if text(hwnd).strip().lower() != LABEL.lower(): return
    state = user32.SendMessageW(hwnd, BM_GETCHECK, 0, 0)
    if state != BST_CHECKED:
        user32.SendMessageW(hwnd, BM_SETCHECK, BST_CHECKED, 0)
        # BM_SETCHECK changes visual state; BM_CLICK also lets CyberBuddy process the setting.
        if user32.SendMessageW(hwnd, BM_GETCHECK, 0, 0) != BST_CHECKED:
            user32.SendMessageW(hwnd, BM_CLICK, 0, 0)
        print("Enabled:", LABEL, flush=True)

def child_cb(hwnd, lparam):
    keep_checked(hwnd)
    return True

def window_cb(hwnd, lparam):
    title = text(hwnd).lower()
    if "cyberbuddy" in title or "advanced options" in title:
        user32.EnumChildWindows(hwnd, EnumChildProc(child_cb), 0)
    return True

def main():
    print("CyberBuddy 6.2 Patch 13 - Server Based Messaging guard active.", flush=True)
    print("The guard does not change UIN, Memory, settings files, or Chat/LAN transport.", flush=True)
    while True:
        user32.EnumWindows(EnumWindowsProc(window_cb), 0)
        time.sleep(0.4)

if __name__ == "__main__":
    main()
