@echo off
where py >nul 2>nul
if errorlevel 1 (
 python -m pip install tzdata
) else (
 py -3 -m pip install tzdata
)
pause
