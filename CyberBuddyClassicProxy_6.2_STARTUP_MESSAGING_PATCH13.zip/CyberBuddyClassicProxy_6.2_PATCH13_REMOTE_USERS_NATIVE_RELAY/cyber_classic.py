"""Unofficial classic Cyber behavior. Existing per-UIN memory remains authoritative."""
import calendar,contextlib,hashlib,html,json,os,random,re,tempfile,threading,time,unicodedata
from datetime import datetime,timezone,date,timedelta
from pathlib import Path
from urllib.parse import unquote,urlparse
BUILD='6.2 - Classic Native LAN Patch 12'
_MUTEX=threading.RLock()
_LAST={}
TRIVIA=(
 'A triangle has three sides.',
 'The chemical formula for water is H2O.',
 'The Earth orbits the Sun.',
 'A standard chessboard has 64 squares.',
 'A leap year in the Gregorian calendar has 366 days.',
 'One hour contains 3,600 seconds.',
)

def load(path,default):
    try:result=json.loads(Path(path).read_text(encoding='utf-8'))
    except FileNotFoundError:return default
    if not isinstance(result,type(default)):raise ValueError('Unexpected saved-data format')
    return result

def save(path,data):
    path=Path(path)
    with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=path.parent,prefix=path.name+'.',suffix='.tmp',delete=False) as f:
        temp=Path(f.name)
        try:json.dump(data,f,ensure_ascii=False,indent=2)
        except BaseException:f.close();temp.unlink(missing_ok=True);raise
    try:os.replace(temp,path)
    finally:temp.unlink(missing_ok=True)

@contextlib.contextmanager
def serial(memory):
    """Coordinate HTTP and native bot processes without changing the memory schema."""
    with _MUTEX:
        lock=Path(memory).with_suffix('.classic.lock')
        with lock.open('a+b') as f:
            f.seek(0,2)
            if not f.tell():f.write(b'0');f.flush()
            start=time.monotonic()
            while True:
                try:
                    f.seek(0)
                    if os.name=='nt':
                        import msvcrt
                        msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
                    else:
                        import fcntl
                        fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
                    break
                except OSError:
                    if time.monotonic()-start>8:raise TimeoutError('Memory is busy')
                    time.sleep(.05)
            try:yield
            finally:
                f.seek(0)
                if os.name=='nt':msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
                else:fcntl.flock(f.fileno(),fcntl.LOCK_UN)

def normalized(text):
    return re.sub(r'^the\s+','',str(text).strip().strip('"').casefold()).rstrip('.?!').strip()

def recipient(data,reference):
    explicit=re.search(r'\buin\s*(\d+)\b',reference,re.I)
    if explicit:
        key=explicit[1]
        if key=='1111':return None,'That is Cyber\x27s UIN. Choose another known user.'
        return (key,None) if isinstance(data.get(key),dict) else (None,'I do not know UIN '+key+' yet. Ask that user to speak to me first.')
    matches=[key for key,p in data.items() if isinstance(p,dict) and normalized(p.get('name',''))==normalized(reference)]
    if len(matches)==1:return matches[0],None
    if matches:return None,'More than one person has that name. Please specify '+', '.join('UIN '+k for k in matches[:10])+'.'
    return None,'I do not know anyone by that name. Please use a known UIN.'

def activity(memory,stamp=None):
    path=Path(memory).with_name('cyber_activity.json');now=time.time() if stamp is None else stamp
    data=load(path,{});key=str(int(now//3600)*3600)
    data={k:v for k,v in data.items() if k.isdigit() and int(k)>=now-25*3600 and isinstance(v,int) and v>=0}
    data[key]=data.get(key,0)+1;save(path,data)

def activity_html(memory,now=None):
    now=datetime.now(timezone.utc) if now is None else now
    data=load(Path(memory).with_name('cyber_activity.json'),{})
    try:
        from zoneinfo import ZoneInfo
        zone=ZoneInfo('America/Chicago');zone_label='U.S. Central Time'
    except (ImportError,KeyError):
        zone=timezone.utc;zone_label='UTC (Central timezone data unavailable)'
    end=now.replace(minute=0,second=0,microsecond=0)
    rows=[]
    for i in range(23,-1,-1):
        t=end-timedelta(hours=i);label=t.astimezone(zone).strftime('%m-%d %H:%M %Z %z')
        count=data.get(str(int(t.timestamp())),0);count=count if isinstance(count,int) and count>=0 else 0
        rows.append((label,count))
    largest=max([v for _,v in rows]+[1]);bars=[]
    for i,(label,count) in enumerate(rows):
        x=45+i*28;h=160*count/largest
        bars.append(f'<rect x="{x}" y="{190-h:.1f}" width="20" height="{h:.1f}" fill="#154a91"><title>{html.escape(label)}: {count}</title></rect><text x="{x+10}" y="210" text-anchor="middle" font-size="9">{i+1}</text>')
    table=''.join('<tr><td>'+html.escape(label)+'</td><td>'+str(count)+'</td></tr>' for label,count in rows)
    return ('<!doctype html><html><head><meta charset="utf-8"><title>Cyber Activity</title>'
            '<style>body{font:14px Tahoma,Arial;background:#ece9d8;color:#182544;max-width:840px;margin:28px auto;padding:20px}h1{background:#154a91;color:white;padding:14px}table{border-collapse:collapse;width:100%;background:white}td,th{padding:6px;border:1px solid #aaa}svg{background:white;width:100%}</style></head><body>'
            '<h1>CyberBuddy Activity</h1><p>Last 24 hourly buckets, including the current hour. '+html.escape(zone_label)+'.</p>'
            '<p>Counts messages handled by this local Cyber recreation. It does not measure speaking time or all messages between other CyberBuddy users.</p>'
            '<svg viewBox="0 0 750 230" role="img" aria-label="Hourly messages">'+''.join(bars)+'</svg>'
            '<table><tr><th>Hour</th><th>Messages</th></tr>'+table+'</table><p><a href="/cyber/activity">Refresh activity</a> | <a href="/cyber/help">Classic help</a></p></body></html>')

def research_context(profile,answer):
    match=re.search(r'Source:\s*(https://en\.wikipedia\.org/wiki/[^\s]+)',str(answer))
    if not match:
        if 'Source: https://' in str(answer):profile.pop('classic_research',None)
        return
    url=match[1].rstrip('.,;');title=unquote(urlparse(url).path.split('/wiki/',1)[-1]).replace('_',' ')
    current=profile.get('classic_research',{})
    previous=current.get('previous',[]) if isinstance(current,dict) and current.get('url')==url else []
    if str(answer)[:1600] not in previous:previous=previous+[str(answer)[:1600]]
    profile['classic_research']={'title':title,'url':url,'previous':previous[-12:]}

def more(profile):
    import cyber_web
    context=profile.get('classic_research')
    if not isinstance(context,dict):return 'What would you like to know more about? Ask a research question first.'
    title=context.get('title','');url=context.get('url','')
    if not title or not url.startswith('https://en.wikipedia.org/wiki/'):return 'Please ask a research question first.'
    params={'action':'query','format':'json','formatversion':2,'titles':title,'redirects':1,'prop':'extracts','explaintext':1,'exintro':1,'exchars':5000}
    try:
        pages=cyber_web.get_json('https://en.wikipedia.org/w/api.php?'+cyber_web.urlencode(params)).get('query',{}).get('pages',[])
        page=next((p for p in pages if normalized(p.get('title',''))==normalized(title)),None)
        if page is None:return 'I could not verify more information from the same article.'
        previous=context.get('previous',[])
        for sentence in re.split(r'(?<=[.!?])\s+',page.get('extract','')):
            sentence=sentence.strip()
            if 40<=len(sentence)<=700 and not any(sentence in old for old in previous):
                answer=sentence+' Source: '+url;context['previous']=(previous+[answer])[-12:];return answer
        return 'I have no additional verified excerpt from that article. Please ask a more specific question.'
    except (OSError,ValueError,TypeError):return 'I could not retrieve more information from the same source. Please try again later.'

def definition_page(subject):
    import cyber_web
    from urllib.parse import quote
    params={'action':'query','format':'json','formatversion':2,'titles':subject,
            'redirects':1,'prop':'extracts|info|pageprops','inprop':'url',
            'explaintext':1,'exintro':1,'exchars':1800}
    try:
        result=cyber_web.get_json('https://en.wikipedia.org/w/api.php?'+cyber_web.urlencode(params))
        query=result.get('query',{});allowed={normalized(subject)}
        links=query.get('normalized',[])+query.get('redirects',[])
        for _ in range(len(links)+1):
            for link in links:
                if normalized(link.get('from','')) in allowed:allowed.add(normalized(link.get('to','')))
        pages=query.get('pages',[])
        if len(pages)!=1:return 'I could not verify a unique definition. Please use a more specific term.'
        page=pages[0];title=page.get('title','');extract=' '.join(page.get('extract','').split())
        if 'disambiguation' in page.get('pageprops',{}):return 'That term has several meanings. Which meaning would you like me to define?'
        if page.get('missing') is not None or normalized(title) not in allowed or not extract:
            return 'I could not verify a general definition for '+subject+'. I will not substitute a specific product or a loosely related article.'
        return title,extract,page.get('fullurl','https://en.wikipedia.org/wiki/'+quote(title.replace(' ','_')))
    except (OSError,ValueError,TypeError,KeyError):
        return 'The definition lookup failed. I could not verify a general definition; please try again later.'

def local(bot,data,key,clean,depth=0):
    profile=data.setdefault(key,{})
    if not isinstance(profile,dict):raise ValueError('Invalid user profile')
    low=clean.casefold();facts=profile.setdefault('facts',{});synonyms=profile.setdefault('synonyms',{})
    if not isinstance(facts,dict) or not isinstance(synonyms,dict):raise ValueError('Invalid teaching records')
    if low in ('who are you','are you a conversational ai','are you conversational','are you an ai','are you a recreation','what are you'):
        return "I'm Cyber, an unofficial conversational AI recreation for CyberBuddy. You can chat with me and teach me things."
    if low in ('what version are you running','what is your version','version','build'):return 'CyberBuddy Classic Proxy '+BUILD+'.'
    if low in ('who created your character','who made your character'):
        return 'The original 3D Cyber character was created by Bob Norris, UIN 29583. John DeFino wrote the original Cyber bot. The bundled character variant has not been independently identified.'
    if low in ('help','what can you do','what are your capabilities','what are your features'):
        return 'I can chat, remember your profile, learn and unlearn facts and phrases, calculate, convert units, use world clocks, research, and keep local messages and away status. Say "classic help" for examples.'
    if low=='classic help':return 'Teach: Bob is a fireman. Unlearn: Bob is not a fireman. Message: message for "UIN 1000" message is "Hello". Away: tell everyone I have gone to work. Return: I am back. Research: research Albert Einstein. More: tell me more. Activity: http://127.0.0.1:8081/cyber/activity'
    if low in ('goodbye','good bye','bye'):return 'Goodbye! Come back and talk to me again.'
    if low in ('are you there','r u there','r you there','hello','hi','helo','helllo'):return 'Hello! I am Cyber. I am here.'
    if low in ('what is today','what is the date','what is today s date','what is today\x27s date','what day is it'):
        return datetime.now().strftime('Today is %A, %B %d, %Y.')
    if low in ('what do you know about me','what do you remember about me'):
        fields=[f'{k}: {profile[k]}' for k in ('name','location','gender','birthdate','website','email','likes','possessions') if profile.get(k)]
        return 'I remember '+('; '.join(fields)+'.' if fields else 'nothing about you yet.')
    field=re.fullmatch(r'my (name|website|email) is\s+(.+)',clean,re.I)
    if field:
        value=field[2].strip()[:240]
        if not value:return 'Please provide a value.'
        profile[field[1].lower()]=value;return 'I will remember your '+field[1].lower()+'.'
    field=re.fullmatch(r'i am (a boy|a girl|male|female)',clean,re.I)
    if field:profile['gender']=field[1].lower();return 'I will remember that.'
    query={'what is my name':'name','who am i':'name','what is my website':'website','what is my web site':'website','what is my email':'email','what is my gender':'gender','what do i like':'likes','what do i have':'possessions'}
    if low in query:
        field=query[low];return str(profile[field]) if profile.get(field) else 'You have not told me your '+field+'.'
    if low.startswith('i like '):profile['likes']=clean[7:];return 'I will remember what you like.'
    if low.startswith('i have '):profile['possessions']=clean[7:];return 'I will remember that.'
    if low in ("what is my dog's name",'what is my dogs name'):
        m=re.fullmatch(r'a dog named (.+)',str(profile.get('possessions','')),re.I)
        return 'Your dog is named '+m[1]+'.' if m else 'You have not told me your dog\x27s name.'
    if low in ('how long until my birthday','how long till my birthday'):
        return bot._basic_reply(key,'Cyber, how many days until my birthday',True)
    if low in ('what is my horoscope','give me my horoscope'):
        value=profile.get('birthdate')
        if not value:return 'Tell me your birthdate first, using MM/DD/YYYY.'
        try:born=date.fromisoformat(value)
        except (ValueError,TypeError):return 'Please give me a valid birthdate first.'
        cuts=[(1,20,'Aquarius'),(2,19,'Pisces'),(3,21,'Aries'),(4,20,'Taurus'),(5,21,'Gemini'),(6,21,'Cancer'),(7,23,'Leo'),(8,23,'Virgo'),(9,23,'Libra'),(10,23,'Scorpio'),(11,22,'Sagittarius'),(12,22,'Capricorn')]
        sign='Capricorn'
        for month,day,label in cuts:
            if (born.month,born.day)>=(month,day):sign=label
        lines=('Take a little time to listen before making your next decision.', 'A small practical step can help you finish something you started.', 'Make room for a friendly conversation and a moment of rest.')
        index=int(hashlib.sha256((sign+date.today().isoformat()).encode()).hexdigest(),16)%len(lines)
        return 'Your traditional Western sign is '+sign+'. For entertainment only: '+lines[index]+' This is not a prediction.'
    definition=re.fullmatch(r'define\s+(.+)',clean,re.I)
    climate=re.fullmatch(r'(?:what is|describe)\s+(?:the\s+)?climate\s+(?:of\s+)?(.+)',clean,re.I)
    if definition or climate:
        import cyber_web
        subject=definition[1] if definition else 'Climate of '+climate[1]
        result=definition_page(subject) if definition else cyber_web._wiki_page(subject,chars=1400)
        if not isinstance(result,tuple):return str(result)
        title,extract,url=result
        if climate and normalized(title)!=normalized(subject):return 'I could not verify a dedicated climate article for that country. Please ask a more specific question.'
        sentence=next((part for part in re.split(r'(?<=[.!?])\s+',extract) if 20<len(part)<=700),None)
        return sentence+' Source: '+url if sentence else 'I could not verify a suitable definition or climate summary.'
    if low in ('what are my lucky numbers','give me lucky numbers'):
        rng=random.Random(hashlib.sha256((key+date.today().isoformat()).encode()).digest())
        return 'For fun only, today\x27s numbers are '+', '.join(map(str,sorted(rng.sample(range(1,50),6))))+'. They do not predict outcomes.'
    if low=='tell me some trivia' or low=='tell me trivia':
        count=int(profile.get('classic_trivia_index',0));profile['classic_trivia_index']=count+1;return TRIVIA[count%len(TRIVIA)]
    if low in ('how can i make my own character','how do i make my own character'):
        return 'Use a Microsoft Agent character editor to assemble artwork, animations and speech settings into an ACS character. Install a uniquely named character so you do not replace an existing Cyber.acs. The original 3D Cyber character was credited to Bob Norris.'
    if low in ('what else','tell me more'):return more(profile)
    message=re.fullmatch(r'message for "(.+?)" message is "(.+)"',clean,re.I)
    if message:
        target,error=recipient(data,message[1])
        if error:return error
        queue=data[target].setdefault('pending',[])
        if not isinstance(queue,list):raise ValueError('Invalid inbox')
        if len(queue)>=100:return 'That local inbox is full.'
        queue.append({'sender':key,'text':message[2][:4000],'created':datetime.now(timezone.utc).isoformat()})
        return 'I saved the message for UIN '+target+'. I will include it when that user next talks to this Cyber service.'
    if low in ('i am back','i am here'):
        profile.pop('away',None);return 'Welcome back! I have cleared your away status.'
    if low.startswith('tell everyone '):profile['away']=clean[14:][:500];return 'I saved your away status. I will report it when someone asks where you are.'
    if low.startswith('i will be '):profile['away']=clean[:500];return 'I saved your away status.'
    userquery=re.fullmatch(r"(?:where is (.+)|what is (.+?)(?:'s|s) web\s*site)",clean,re.I)
    if userquery:
        target,error=recipient(data,userquery[1] or userquery[2])
        if error:return error
        return str(data[target].get('away','No away status is saved for UIN '+target+'.')) if userquery[1] else str(data[target].get('website','No website is saved for UIN '+target+'.'))
    if low in ('who are you talking to','who are you chatting with'):
        recent=sum(isinstance(p,dict) and time.time()-float(p.get('classic_last_seen',0))<300 for p in data.values())
        return 'I am talking to '+str(profile.get('name','you'))+' (UIN '+key+'). '+str(recent)+' user profile(s) have contacted this local bot in the last five minutes; this does not prove they are online.'
    if low in ('what announcements','any announcements','what are the announcements'):
        return announcements(bot,profile,force=True) or 'There are no current local announcements.'
    synonym=re.fullmatch(r'"(.+?)" is (not )?the same as "(.+?)"',clean,re.I)
    if synonym:
        name=normalized(synonym[1]);value=synonym[3].strip()
        if synonym[2]:
            if normalized(synonyms.get(name,''))!=normalized(value):return 'I do not have that matching synonym association saved.'
            del synonyms[name];return 'I have removed that synonym association.'
        if normalized(synonyms.get(name,''))==normalized(value):return 'I already know that phrase.'
        synonyms[name]=value;return 'I have learned that phrase.'
    meaning=re.fullmatch(r'what does (.+?) mean',clean,re.I)
    if meaning:
        name=normalized(meaning[1]);return 'You taught me that '+meaning[1]+' means '+str(synonyms[name])+'.' if name in synonyms else 'You have not taught me a meaning for that phrase.'
    if low in synonyms and depth<1:
        replacement=str(synonyms[low]);answer=local(bot,data,key,replacement,depth+1)
        return answer if answer is not None else 'You taught me that '+clean+' means '+replacement+'.'
    # Existing tested teaching/unlearning stays in the old router. Match articles on recall.
    factquery=re.fullmatch(r'(?:what|who) is (.+)',clean,re.I)
    if factquery:
        matches=[str(v) for k,v in facts.items() if normalized(k)==normalized(factquery[1])]
        if len(matches)==1:return matches[0]
    return None

def announcements(bot,profile,force=False):
    path=Path(bot.MEMORY).with_name('cyber_announcements.json')
    items=load(path,[]);seen=profile.setdefault('classic_announcements_seen',[])
    if not isinstance(seen,list):raise ValueError('Invalid announcements state')
    output=[]
    for item in items[:100]:
        if len(output)>=3:break
        if not isinstance(item,dict) or item.get('enabled',True) is not True:continue
        ident=str(item.get('id',''));text=str(item.get('text',''))[:800]
        if ident and text and (force or ident not in seen):
            output.append(text)
            if ident not in seen:seen.append(ident)
    profile['classic_announcements_seen']=seen[-200:]
    return 'Announcements: '+' | '.join(output) if output else ''

def respond(bot,user,text,private,previous):
    original=str(text)
    address_probe=re.sub(r'^\s*(?:(?:and\s+|&&)?(?:decline|search))\s+(?=cyber\b)','',original,flags=re.I)
    called=bool(re.match(r'^\s*cyber\b',address_probe,re.I) or re.search(r'\bcyber[.!?,;: ]*$',address_probe,re.I))
    if not private and not called:return ''
    raw=unicodedata.normalize('NFC',original)
    raw=''.join(c for c in raw if unicodedata.category(c)!='Cf')
    raw=re.sub(r'\\[A-Za-z]+(?:=[^\\]*)?\\',' ',raw)
    raw=re.sub(r'^\s*(?:(?:and\s+|&&)?(?:decline|search))\s+(?=cyber\b)','',raw,flags=re.I)
    clean=bot._exp46f_clean(raw).replace('“','"').replace('”','"').rstrip('.?!').strip()
    clean=re.sub(r'[,;:]?\s+cyber$','',clean,flags=re.I).strip().rstrip('.?!')
    clean={'r u there':'are you there','r you there':'are you there','what else cyber':'what else'}.get(clean.lower(),clean)
    key=str(user)
    if clean.casefold()=='diagnose last route':
        last=_LAST.get(key)
        return 'DIAG8 PID='+str(os.getpid())+'; UIN-key='+hashlib.sha256(key.encode()).hexdigest()[:8]+'; last='+ascii(last)+'; module='+str(Path(bot.__file__).resolve())+'; memory='+str(Path(bot.MEMORY).resolve())
    try:
        with serial(bot.MEMORY):
            # Validate before any legacy routine can replace a malformed file.
            data=load(bot.MEMORY,{});profile=data.setdefault(key,{})
            if not isinstance(profile,dict):raise ValueError('Invalid profile')
            profile['classic_last_seen']=time.time()
            answer=local(bot,data,key,clean)
            route='classic-local' if answer is not None else 'core-rules/research/conversation'
            if answer is None:
                pending_before=profile.pop('pending',[])
                save(bot.MEMORY,data)
                # Use the tested location/clock/calculation/research rules.
                answer=previous(key,clean,True)
                data=load(bot.MEMORY,{});profile=data.setdefault(key,{})
                if clean.casefold() not in ('forget me','delete my memory','reset my data','forget everything about me'):
                    profile['pending']=pending_before
            research_context(profile,answer)
            notices=announcements(bot,profile)
            pending=profile.get('pending',[])
            if not isinstance(pending,list):raise ValueError('Invalid inbox')
            delivered=[]
            for item in pending[:3]:
                if isinstance(item,dict) and isinstance(item.get('text'),str):
                    delivered.append('From UIN '+str(item.get('sender','unknown'))+': '+item['text'][:4000])
            if delivered:
                archive=profile.setdefault('classic_delivered_messages',[])
                if not isinstance(archive,list):raise ValueError('Invalid delivery history')
                archive.extend(pending[:3]);profile['classic_delivered_messages']=archive[-100:];profile['pending']=pending[3:]
                answer=str(answer)+' Saved messages: '+' | '.join(delivered)
            if notices:answer=str(answer)+' '+notices
            save(bot.MEMORY,data)
            try:activity(bot.MEMORY)
            except (OSError,ValueError,TypeError):pass
            if len(_LAST)>=100 and key not in _LAST:_LAST.pop(next(iter(_LAST)))
            _LAST[key]={'clean':clean[:240],'route':route}
            answer=re.sub(r'^\[DIAG3 PID \d+\]\s*','',str(answer))
            answer=re.sub(r'(?<![\d.])1 (meters|hours|seconds|minutes|kilograms|grams|miles|centimeters|inches|pounds)\b',lambda m:'1 '+('inch' if m[1]=='inches' else m[1][:-1]),answer)
            return answer
    except (OSError,ValueError,TypeError,TimeoutError):
        return 'I could not safely access the saved data. Your memory was not reset. Check the file or try again when the other request finishes.'
