"""Read published presence from the local proxy directory; never fabricate it."""
import json,re,time
from pathlib import Path
from datetime import datetime
ROOT=Path(__file__).resolve().parent

def last_online(question,root=None):
    match=re.search(r'\bu[ -]*i[ -]*n\s*(\d+)\s+last\s+on\b',str(question),re.I)
    if not match:return None
    uin=match[1];base=Path(root) if root is not None else ROOT
    source=base/'chat_directory_2026.json'
    try:
        saved=json.loads(source.read_text(encoding='utf-8'))
    except (OSError,ValueError):return 'The local directory file is unavailable. Run the proxy and this bot from the same folder.'
    info=saved.get(uin) if isinstance(saved,dict) else None
    if not isinstance(info,dict) or info.get('published') is not True:
        return 'No published last-online record for UIN '+uin+' exists in this local directory.'
    try:
        stamp=float(info.get('last_seen',0))
        if stamp<=0 or stamp>time.time()+300:raise ValueError()
        clock=datetime.fromtimestamp(stamp).astimezone().strftime('%Y-%m-%d %H:%M:%S %z')
    except (ValueError,TypeError,OverflowError,OSError):return 'UIN '+uin+' has no valid recorded activity time in this local directory.'
    return 'UIN '+uin+' last recorded activity: '+clock+'. Source: local proxy directory; this does not confirm that the user is online now.'
