"""BonziBuddy EXE string editor with verified original padded capacities."""
from pathlib import Path
import struct, re, json, hashlib, datetime, shutil, subprocess, os, sys
BASE=Path(__file__).resolve().parent

def digest(data): return hashlib.sha256(data).hexdigest()

def resource_records(data, table, sections):
    result=[]
    keys=['CompanyName','FileDescription','FileVersion','InternalName',
          'LegalCopyright','OriginalFilename','ProductName','ProductVersion','Comments']
    for index in range(sections):
        h=table+40*index
        if data[h:h+8].rstrip(b'\0')!=b'.rsrc': continue
        size,offset=struct.unpack_from('<II',data,h+16);end=min(offset+size,len(data))
        # Delphi binary form Caption values: type 6 stores a length-prefixed ANSI string.
        for match in re.finditer(re.escape(b'\x07Caption\x06'),data[offset:end]):
            lengthpos=offset+match.end()
            if lengthpos>=end:continue
            n=data[lengthpos];start=lengthpos+1
            if not n or start+n>end:continue
            try:text=data[start:start+n].decode('cp1252')
            except UnicodeDecodeError:continue
            if any(ord(c)<32 for c in text):continue
            label='Form Caption'
            prefix=data[max(offset,start-70):lengthpos-9]
            if re.search(rb'\x09TTabSheet[\x01-\x3f](?:AboutSheet|GeneralPage|TimePage|ReminderPage|ReadPage|ICQpage|SendPage|EmailPage|StockPage|WWWpage)$',prefix):label='Tab Caption'
            result.append(dict(offset=start,bytes=n,original=text,encoding='cp1252',label=label))
        for key in keys:
            needle=(key+'\0').encode('utf-16le')
            for match in re.finditer(re.escape(needle),data[offset:end]):
                keypos=offset+match.start();header=keypos-6
                if header<offset: continue
                length,units,kind=struct.unpack_from('<HHH',data,header)
                start=(keypos+len(needle)+3)&~3
                if kind!=1 or units<2 or header+length>end or start+units*2>header+length: continue
                raw=data[start:start+units*2]
                if raw[-2:]!=b'\0\0': continue
                try:text=raw[:-2].decode('utf-16le').rstrip('\0')
                except UnicodeDecodeError:continue
                if not text or any(ord(c)<32 for c in text): continue
                result.append(dict(offset=start,bytes=(units-1)*2,original=text,encoding='utf-16le',label=key))
        # VS_FIXEDFILEINFO stores numeric versions independently of displayed strings.
        for match in re.finditer(re.escape(b'\xbd\x04\xef\xfe\x00\x00\x01\x00'),data[offset:end]):
            start=offset+match.start()
            if start+52>end:continue
            for delta,label in [(8,'Numeric FileVersion'),(16,'Numeric ProductVersion')]:
                ms,ls=struct.unpack_from('<II',data,start+delta)
                version='%d.%d.%d.%d'%(ms>>16,ms&65535,ls>>16,ls&65535)
                result.append(dict(offset=start+delta,bytes=8,original=version,encoding='version',label=label))
    return result

def scan(data):
    if data[:2]!=b'MZ': raise ValueError('Not a Windows EXE.')
    pe=struct.unpack_from('<I',data,60)[0]
    if data[pe:pe+4]!=b'PE\0\0': raise ValueError('Invalid PE header.')
    sections=struct.unpack_from('<H',data,pe+6)[0]
    optional=struct.unpack_from('<H',data,pe+20)[0]
    table=pe+24+optional
    result=[]
    # Visual Basic uses length-prefixed UTF16 BSTR constants.
    for index in range(sections):
        h=table+40*index;size,offset=struct.unpack_from('<II',data,h+16)
        end=min(offset+size,len(data))
        for match in re.finditer(rb'(?:[\x20-\xff]\x00){4,}',data[offset:end]):
            start=offset+match.start();raw=match.group()
            if start-4<offset or start+len(raw)+2>end:continue
            if struct.unpack_from('<I',data,start-4)[0]!=len(raw) or data[start+len(raw):start+len(raw)+2]!=b'\0\0':continue
            text=raw.decode('utf-16le')
            if any(not c.isprintable() for c in text):continue
            result.append(dict(offset=start,bytes=len(raw),original=text,encoding='utf-16le',length_offset=start-4,label='VB readable string'))
    result.extend(resource_records(data,table,sections))
    result=sorted({r['offset']:r for r in result}.values(),key=lambda r:r['offset'])
    catalog_file=BASE/'original-capacities.json'
    if catalog_file.is_file():
        catalog=json.loads(catalog_file.read_text());fields=catalog['fields']
        # Only use this original-layout map for the known 4.1.0.9-size binary.
        if len(data)==catalog['file_size']:
            for r in result:
                if 'length_offset' not in r:continue
                capacity=fields.get('%08X'%r['offset'],r['bytes'])
                end=r['offset']+capacity
                if capacity>r['bytes'] and end+2<=len(data):
                    padding=data[r['offset']+r['bytes']:end+2]
                    if padding and not any(padding):r['bytes']=capacity
    return result

def export(exe, folder):
    data=exe.read_bytes();records=scan(data)
    if not records: raise ValueError('No recognized VB text or version resources found.')
    folder.mkdir(parents=True,exist_ok=True)
    txt=folder/(exe.name+'.txt');manifest=folder/(exe.name+'.manifest.json')
    if txt.exists() and manifest.exists():return txt,manifest
    # JSON quoting inside TXT preserves backslashes and other literal characters.
    lines=['# BonziBuddy EXE readable strings. Edit only the quoted text after TAB.',
           '# Keep all IDs. Shorter text is padded; longer text is rejected.',
           '# This is text extraction, not Delphi source code.']
    for r in records:
        lines.append('# %s | %s | capacity %d bytes'%(r.get('label','VB string'),r.get('encoding','cp1252'),r['bytes']))
        lines.append('%08X\t%s'%(r['offset'],json.dumps(r['original'],ensure_ascii=False)))
    txt.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    manifest.write_text(json.dumps({'source_sha256':digest(data),'records':records},ensure_ascii=False,indent=2),encoding='utf-8')
    return txt,manifest

def validate(exe,txt,manifest):
    data=exe.read_bytes();info=json.loads(manifest.read_text(encoding='utf-8'))
    if digest(data)!=info['source_sha256']: raise ValueError('EXE differs from exported source. Export the correct EXE again.')
    if info['records']!=scan(data): raise ValueError('Manifest does not match recognized strings in this EXE.')
    edits={}
    for number,line in enumerate(txt.read_text(encoding='utf-8-sig').splitlines(),1):
        if not line.strip() or line.startswith('#'): continue
        key,sep,value=line.partition('\t')
        if not sep: raise ValueError('Line %d: keep ID, TAB and quoted text.'%number)
        offset=int(key,16)
        if offset in edits: raise ValueError('Duplicate ID: '+key)
        try:text=json.loads(value)
        except json.JSONDecodeError as e:raise ValueError('TXT line %d (%s): %s'%(number,key,e.msg)) from e
        if not isinstance(text,str) or any(ord(c)<32 or ord(c)==127 for c in text): raise ValueError('Invalid text at '+key)
        edits[offset]=text
    if set(edits)!={r['offset'] for r in info['records']}: raise ValueError('Keep all record IDs. Do not add or delete records.')
    output=bytearray(data);count=0
    for r in info['records']:
        text=edits[r['offset']];encoding=r.get('encoding','cp1252')
        if text==r['original']:continue
        if encoding=='version':
            if not re.fullmatch(r'\d+\.\d+\.\d+\.\d+',text): raise ValueError('Numeric versions require four numbers, e.g. 4.13.10.0.')
            parts=[int(v) for v in text.split('.')]
            if any(v>65535 for v in parts):raise ValueError('Version numbers must be 0 to 65535.')
            raw=struct.pack('<II',parts[0]<<16|parts[1],parts[2]<<16|parts[3])
        else:
            raw=text.encode(encoding)
            if len(raw)>r['bytes']:raise ValueError('%08X: maximum %d bytes; got %d.'%(r['offset'],r['bytes'],len(raw)))
            if 'length_offset' in r:
                output[r['length_offset']:r['length_offset']+4]=struct.pack('<I',len(raw))
                raw+=b'\0'*(r['bytes']-len(raw))
            elif encoding=='utf-16le':raw+=b'\0'*(r['bytes']-len(raw))
            else:raw+=b' '*(r['bytes']-len(raw))
        if raw!=data[r['offset']:r['offset']+r['bytes']]:
            count+=1;output[r['offset']:r['offset']+r['bytes']]=raw
    return bytes(output),count

def apply(exe,txt,manifest):
    result,count=validate(exe,txt,manifest)
    if not count: raise ValueError('No text edits found; no EXE created.')
    out=exe.with_name(exe.stem+'-customized.exe')
    if out.exists():out=exe.with_name(exe.stem+'-customized-'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.exe')
    backup=BASE/'backups'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup.mkdir(parents=True);shutil.copy2(exe,backup/exe.name)
    with out.open('xb') as f: f.write(result)
    return out,backup,count

def prepare_version(exe,txt,manifest,value):
    if not re.fullmatch(r'\d+\.\d+\.\d+\.\d+',value):raise ValueError('Use four numbers, e.g. 4.13.10.0.')
    parts=[int(v) for v in value.split('.')]
    if any(v>65535 for v in parts):raise ValueError('Version numbers must be 0 to 65535.')
    validate(exe,txt,manifest)
    info=json.loads(manifest.read_text(encoding='utf-8'));updates={};skipped=[]
    for r in info['records']:
        label=r.get('label','');new=None
        if label in ('Numeric FileVersion','Numeric ProductVersion','FileVersion','ProductVersion'):new=value
        elif re.fullmatch(r'Rev \d+\.\d+\.\d+',r['original']):new='Rev '+'.'.join(value.split('.')[:3])
        if new is None:continue
        encoding=r.get('encoding','cp1252')
        if encoding!='version' and len(new.encode(encoding))>r['bytes']:
            skipped.append(label or r['original']);continue
        updates[r['offset']]=new
    if not updates:raise ValueError('No compatible version fields found.')
    lines=txt.read_text(encoding='utf-8-sig').splitlines()
    for i,line in enumerate(lines):
        if not line or line.startswith('#'):continue
        key,_,old=line.partition('\t');offset=int(key,16)
        if offset in updates:lines[i]=key+'\t'+json.dumps(updates[offset],ensure_ascii=False)
    backup=txt.with_name(txt.name+'.before_version_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    shutil.copy2(txt,backup);txt.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    validate(exe,txt,manifest)
    return len(updates),skipped

def edit_tab(exe,txt,manifest,choice,text):
    validate(exe,txt,manifest)
    info=json.loads(manifest.read_text(encoding='utf-8'))
    tabs=[r for r in info['records'] if r.get('label')=='Tab Caption']
    if not 1<=choice<=len(tabs):raise ValueError('Select a listed tab number.')
    record=tabs[choice-1]
    if not text.strip() or any(ord(c)<32 for c in text):raise ValueError('Enter a nonempty tab name.')
    if len(text.encode('cp1252'))>record['bytes']:raise ValueError('Tab name can use at most %d CP1252 bytes.'%record['bytes'])
    lines=txt.read_text(encoding='utf-8-sig').splitlines()
    for i,line in enumerate(lines):
        if line.startswith('%08X\t'%record['offset']):lines[i]='%08X\t%s'%(record['offset'],json.dumps(text,ensure_ascii=False))
    backup=txt.with_name(txt.name+'.before_tab_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    shutil.copy2(txt,backup);txt.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    validate(exe,txt,manifest)
    return record['original'],text

def preview(exe,txt,manifest):
    output,count=validate(exe,txt,manifest)
    info=json.loads(manifest.read_text(encoding='utf-8'));edits={}
    for line in txt.read_text(encoding='utf-8-sig').splitlines():
        if not line or line.startswith('#'):continue
        key,_,value=line.partition('\t');edits[int(key,16)]=json.loads(value)
    for r in info['records']:
        new=edits[r['offset']]
        if new!=r['original']:print('%08X %s: %r -> %r'%(r['offset'],r.get('label','VB string'),r['original'],new))
    print('Total changed records:',count)
    return count

def select_exe():
    try:
        import tkinter as tk
        from tkinter import filedialog
        window=tk.Tk();window.withdraw();window.attributes('-topmost',True)
        try:path=filedialog.askopenfilename(parent=window,title='Select BonziBDY.EXE',filetypes=[('Windows EXE','*.exe')])
        finally:window.destroy()
    except ImportError:path=input('Full path to BonziBDY.EXE: ').strip().strip('"')
    return Path(path).resolve() if path else None

def workspace(exe):
    folder=BASE/'readable'/digest(exe.read_bytes());txt=folder/(exe.name+'.txt');manifest=folder/(exe.name+'.manifest.json')
    if txt.exists() and manifest.exists():
        old=json.loads(manifest.read_text(encoding='utf-8'));new=scan(exe.read_bytes())
        if old['source_sha256']==digest(exe.read_bytes()) and old['records']!=new:
            def signature(rs):return [(r['offset'],r['original'],r.get('encoding')) for r in rs]
            if signature(old['records'])!=signature(new):raise ValueError('Source records differ. Choose a fresh export folder.')
            backup=manifest.with_name(manifest.name+'.before-capacity-fix-'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
            shutil.copy2(manifest,backup);old['records']=new;manifest.write_text(json.dumps(old,ensure_ascii=False,indent=2),encoding='utf-8')
            print('Verified original padded capacities restored. Your edited TXT was retained.')
        return txt,manifest
    return export(exe,folder)

def menu():
    exe=select_exe()
    if exe is None:return
    txt,manifest=workspace(exe)
    while True:
        print('\nBonziBuddy EXE Customizer — versions 2 to 4\nCURRENT EXE:',exe,'\nTXT:',txt)
        print('1 Export/current TXT path\n2 Edit TXT in Notepad\n3 Validate TXT\n4 Create edited EXE with backup\n5 Restore backup to a separate file\n6 Find links, messages or copyright\n7 Prepare version metadata\n8 Select another EXE\n9 Preview edits\n0 Exit')
        try:
            action=input('Action: ').strip()
            expected=json.loads(manifest.read_text())['source_sha256']
            if digest(exe.read_bytes())!=expected:txt,manifest=workspace(exe);print('EXE changed; separate export selected. Earlier export retained.')
            out=None
            if action=='0':return
            if action=='1':print('TXT:',txt)
            elif action=='2':
                if os.name!='nt':raise ValueError('Notepad requires Windows.')
                subprocess.run(['notepad.exe',str(txt)],check=True)
            elif action=='3':print('Valid; changed records:',validate(exe,txt,manifest)[1])
            elif action=='4':
                data,count=validate(exe,txt,manifest)
                if not count:print('No text edits found.');continue
                out,backup,count=apply(exe,txt,manifest);print('Created:',out,'\nOriginal backup:',backup)
            elif action=='5':
                source=Path(input('Backup EXE path: ').strip().strip('"'));scan(source.read_bytes())
                out=exe.with_name(exe.stem+'-restored-'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.exe')
                with out.open('xb') as handle:handle.write(source.read_bytes())
            elif action=='6':
                query=input('Find text (http, Copyright, joke): ').casefold()
                for record in json.loads(manifest.read_text())['records']:
                    if query in (record['original']+' '+record.get('label','')).casefold():print('%08X [%d bytes] %s: %s'%(record['offset'],record['bytes'],record.get('label','VB string'),record['original']))
            elif action=='7':
                count,skipped=prepare_version(exe,txt,manifest,input('Version metadata (four numbers): ').strip());print('Prepared:',count,'Skipped:',skipped)
            elif action=='8':
                selected=select_exe()
                if selected is not None:
                    newtxt,newmanifest=workspace(selected);exe=selected;txt,manifest=newtxt,newmanifest
            elif action=='9':preview(exe,txt,manifest)
            else:print('Choose 0 to 9.')
            if out is not None:exe=out;txt,manifest=workspace(exe);print('New EXE selected automatically. Runtime test still required.')
        except Exception as error:print('Error:',error)

if __name__=='__main__':
    try:menu()
    except Exception as e:print('Error:',e);sys.exit(1)
