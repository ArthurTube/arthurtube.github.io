# Classic Cyber recreation — Release 11

The supplied original tutorials define the behavior targets. This is new code,
not the original Cyber AI engine. Original bot credit: John DeFino. Original
3D character credit: Bob Norris, UIN 29583. Arthur Tube is the proxy/recreation
project credit. The exact bundled Cyber.acs variant remains unidentified.

| Original behavior | Release 11 implementation and verification |
|---|---|
| Conversation and classic identity | Fixed identity answers; optional local Ollama conversation; self-denial guard tested with a model-response fixture |
| User profiles and memory | Existing JSON retained; per-UIN name, location, gender, birthday, website, email, preferences and possessions; restart regression tests |
| Address by name outside private mode | Enforced by dispatcher; native packet simulation passed; actual client mode mapping awaits Windows test |
| IM shorthand and spelling | Explicit common greeting forms; broad spelling correction and uncertainty clarification are not fully recreated |
| Teaching and correction | Existing facts and update/unlearning preserved; quotation-safe synonyms and matching-only removal tested |
| Research and further information | Existing sourced research retained; same-article follow-up excerpts and definitions; live coverage not certified |
| Population | Structured Wikidata P1082 totals with date and source; fixture/offline tests, live country checks pending |
| Capitals and climate | Existing capital question routing; taught capital facts take precedence; climate summaries require a matching dedicated article; live tests pending |
| Arithmetic and conversions | Verified regressions; singular-unit presentation improved |
| Date and world clocks | Verified clock fixes retained; fixed timezone mappings and Windows timezone fallback; unsupported zones are not guessed |
| Birthday and horoscope | Stored birthdate/age retained; zodiac plus labeled entertainment-only daily text; not a prediction service |
| Lucky numbers and trivia | Local entertainment numbers and curated trivia |
| Other users | Unambiguous name/UIN resolution, saved website/away status; existing published-directory last-seen lookup retained |
| Stored messages | Known recipients only; durable local queue; up to three delivered on next bot contact; local delivery archive; not automatic online-login delivery |
| Away / return | Save status and clear on return, tested with two simulated users |
| Announcements | Local configurable list; per-UIN once-only display, explicit repeat query; no original online announcement service |
| Activity graph | Real hourly counts of messages handled by this local bot; 24 buckets; Central time when data is available, labeled UTC fallback; not original network-wide peer activity |
| Character | Existing ACS bundled unchanged, hash recorded; no independent variant attribution |

## What the checks establish

52 automated test executions passed, including inherited regression groups,
native private/public packet examples, two-user queues and simultaneous
cross-process memory updates. The installed offline self-check runs 23 checks
using temporary profiles. These checks do not read or reset the live profile.

They do not establish real Windows installation success, cross-computer
transport acceptance, complete live research coverage, or antivirus safety.
The user verified conversation, teaching/unlearning, memory restart, location,
clocks, research/definitions and biography handling through Fix 10, plus
same-user away status. The consolidated Release 11 installer still requires
a Windows acceptance pass. The Avast analysis remains unresolved.


Release 11 consolidates Fixes 9 and 10. New isolated end-to-end UDP tests
verify two-client delivery after restart, per-recipient separation, second-user
away lookup, announcement persistence and public/private packet mapping.
Local HTTP help/activity tests pass. These do not replace a two-computer
Windows acceptance test or an antivirus verdict.
