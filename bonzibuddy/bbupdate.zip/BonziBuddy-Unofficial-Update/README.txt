NEW BONZIBUDDY PERSONALITY — OCTOBER 3, 2026

82 personality routines refreshed in a similar classic style.
Keep a backup of your existing files, close BonziBuddy, and place p001.nbd and P001.nbd-SR in the same location as their existing counterparts.

Preserved: Header prefix, 82 record slots, original animation order, delay/stop commands, pauses, emphasis/pitch commands, and selection file bytes. The original song and echo voice effects remain; their introductions/dedications are refreshed. Obsolete website promotion was replaced, and the pronunciation mapping for removed wording was dropped.

Validation: all 82 records changed; encoded file decodes exactly to the readable scripts. Runtime playback of this new edition has not been tested. This content edition does not change or establish the application version.
