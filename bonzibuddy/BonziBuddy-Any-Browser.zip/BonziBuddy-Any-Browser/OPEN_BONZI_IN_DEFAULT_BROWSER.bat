@echo off
start "" "https://arthurtube.github.io/bonzibuddy/"
