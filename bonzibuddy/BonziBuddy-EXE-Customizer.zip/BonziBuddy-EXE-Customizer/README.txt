BonziBuddy EXE Customizer - verified padded capacity fix

Close the old Customizer. Extract this ZIP and run START_CUSTOMIZER.bat.
Select your BonziBDY-4.1.0.10.exe using the file picker. Option 1 shows the new
TXT path. Copy your FULL ENGLISH edited TXT contents into that TXT, save it,
then use 3 Validate and 4 Create edited EXE.

Alternatively copy customizer.py and original-capacities.json into your
existing Customizer folder. Keep readable and backups. The updated program
migrates a matching manifest after backing it up and retains your edited TXT.

This restores known original field capacity only when the original binary
layout matches and the extra bytes are still unused zero padding. It does
not blindly disable bounds checks, shift EXE bytes or overwrite adjacent data.
Versions 2 and 3 retain their existing bounds unless a verified layout is known.
The supported original 4.x layout restores 0003B364 from 160 to 176 bytes.

Verified full-sentence restoration, unchanged EXE size, rescan, and rejection
when padding contains occupied bytes. Windows UI/runtime remain untested.
