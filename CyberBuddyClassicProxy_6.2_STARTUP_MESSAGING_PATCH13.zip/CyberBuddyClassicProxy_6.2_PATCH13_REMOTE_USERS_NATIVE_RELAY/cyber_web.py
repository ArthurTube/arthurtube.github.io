"""Key-free sourced lookup. No LLM-generated claims of web research."""
import json,re,time,unicodedata
from urllib.request import Request,build_opener,ProxyHandler
from urllib.parse import urlencode,quote
from datetime import datetime,timezone
CACHE={}
def get_json(url):
    request=Request(url,headers={'User-Agent':'CyberBuddyClassicProxy/6.2 (local compatibility bot; source lookup)'})
    with build_opener(ProxyHandler({})).open(request,timeout=12) as response:
        return json.loads(response.read(1000000).decode('utf-8'))
def research(question):
    query=re.sub(r'^.*?\bresearch\s*','',question,flags=re.I).strip().rstrip('.?!')
    if not query:return 'Tell me what to research.'
    search=re.sub(r'^(?:when was|when did|who is|who was|what is|where was)\s+','',query,flags=re.I)
    search=re.sub(r'\s+(?:born|died|die)$','',search,flags=re.I)
    params={'action':'query','format':'json','formatversion':2,'generator':'search','gsrsearch':search[:240],'gsrlimit':1,'prop':'extracts|info','inprop':'url','exintro':1,'explaintext':1,'exchars':500}
    try:
        data=get_json('https://en.wikipedia.org/w/api.php?'+urlencode(params))
        pages=data.get('query',{}).get('pages',[])
        if not pages:return 'Wikipedia did not return a matching article.'
        page=pages[0];extract=' '.join(page.get('extract','').split())[:600]
        title=page.get('title','');url=page.get('fullurl','https://en.wikipedia.org/wiki/'+quote(title.replace(' ','_')))
        if not extract:return 'I found '+title+', but no readable summary. Source: '+url
        # Only extract a clearly marked birth date from the article opening.
        # Do not infer it from unrelated dates later in the biography.
        if re.fullmatch(r'when (?:was|did) .+ (?:died|die)',query,re.I):
            # A death date must follow the lifespan dash in the opening.
            # This also handles bracketed Old Style birth dates.
            lifespan=re.search(r'\([^)]{0,200}?[–—]\s*([A-Z][a-z]+ \d{1,2}, \d{4}|\d{1,2} [A-Z][a-z]+ \d{4})\s*\)',extract[:350])
            if lifespan:
                for pattern in ('%B %d, %Y','%d %B %Y'):
                    try:
                        day=datetime.strptime(lifespan[1],pattern)
                        return title+' died on '+day.strftime('%B')+' '+str(day.day)+', '+str(day.year)+'. Source: '+url
                    except ValueError:pass
            return 'The retrieved article does not give a verified death date for '+title+'. I will not invent one. Source: '+url
        if re.fullmatch(r'when (?:was|did) .+ born',query,re.I):
            opening=extract[:300]
            date_pattern=r'([A-Z][a-z]+ \d{1,2}, \d{4}|\d{1,2} [A-Z][a-z]+ \d{4})'
            birth=re.search(r'\bborn\s+'+date_pattern,opening) or re.search(r'\(\s*'+date_pattern+r'\s*(?:\[[^]]*\]\s*)?(?:[–—]|\))',opening)
            if birth:
                value=birth[1]
                for pattern in ('%B %d, %Y','%d %B %Y'):
                    try:
                        day=datetime.strptime(value,pattern)
                        return title+' was born on '+day.strftime('%B')+' '+str(day.day)+', '+str(day.year)+'. Source: '+url
                    except ValueError:pass
            return 'I found '+title+', but could not reliably extract the birth date. Source: '+url
        words=extract.split()
        summary=' '.join(words[:100])+('...' if len(words)>100 else '')
        return 'Wikipedia, '+title+': '+summary+' Source: '+url
    except (OSError,ValueError,TypeError,KeyError):return 'The Wikipedia lookup failed. No research result was verified. Try again later.'
def norm(text):return ''.join(c for c in unicodedata.normalize('NFKD',text.lower()) if not unicodedata.combining(c))
def world_time(city):
    parts=[p.strip() for p in city.split(',')];name=parts[0];country=parts[-1] if len(parts)>1 else None
    try:
        key=norm(city);now=time.monotonic()
        record=CACHE.get(key)
        if not record or record[0]<now:
            data=get_json('https://geocoding-api.open-meteo.com/v1/search?'+urlencode({'name':name,'count':10,'language':'en','format':'json'}))
            matches=[r for r in data.get('results',[]) if r.get('timezone')]
            if country:matches=[r for r in matches if norm(country) in (norm(r.get('country','')),norm(r.get('country_code','')))]
            exact=[r for r in matches if norm(r.get('name',''))==norm(name)]
            if exact:matches=exact
            if not matches:return 'I could not locate that city. Try city, country.'
            if len({r.get('country_code') for r in matches})>1 and not country:return 'That city name matches multiple countries. Ask with city, country.'
            chosen=matches[0];CACHE[key]=(now+86400,chosen)
            if len(CACHE)>200:CACHE.pop(next(iter(CACHE)))
        else:chosen=record[1]
        from zoneinfo import ZoneInfo,ZoneInfoNotFoundError
        try:clock=datetime.now(timezone.utc).astimezone(ZoneInfo(chosen['timezone']))
        except ZoneInfoNotFoundError:return 'Install timezone data with INSTALL_TIMEZONES.bat, then restart this test.'
        label=chosen['name']+', '+chosen.get('country','')
        return clock.strftime('In '+label+' it is %H:%M on %Y-%m-%d (%Z).')+' Timezone: '+chosen['timezone']+'. City lookup: Open-Meteo.'
    except (OSError,ValueError,TypeError,KeyError,ImportError):return 'City or timezone lookup failed. I will not guess the time. Try again later.'

def parse_any_date(value):
    for fmt in ('%d %B %Y','%B %d, %Y'):
        try:return datetime.strptime(value,fmt)
        except ValueError:pass
    return None

# Experimental 28: question-aware Wikipedia answers.
def wikipedia_answer(question):
    q=' '.join(str(question).split()).strip().rstrip('.?!')
    if not q:return 'Tell me what you want to look up on Wikipedia.'

    # Experimental 38: high-confidence world/country counts. Wikipedia search can
    # rank an unrelated place for broad count questions (for example Tarasp for
    # "how many countries are in the world?"). Answer these concepts directly
    # and never treat an unrelated article as evidence.
    qn=norm(q)
    if re.fullmatch(r'how many (?:countries|sovereign states) (?:are there )?(?:in the world|worldwide|exist|are there)',qn,re.I) or qn in {
        'how many countries are in the world','how many countries are there in the world',
        'how many countries exist','how many countries are there','how many sovereign states are there'
    }:
        return 'There are 195 countries commonly recognized worldwide: 193 United Nations member states and 2 United Nations observer states, the Holy See and the State of Palestine. Source: https://en.wikipedia.org/wiki/List_of_sovereign_states'
    if re.fullmatch(r'how many (?:un|united nations) member states (?:are there|exist)?',qn,re.I):
        return 'The United Nations has 193 member states. Source: https://en.wikipedia.org/wiki/Member_states_of_the_United_Nations'

    # Duration questions are handled from a dated Wikipedia lead when possible.
    m=re.fullmatch(r'how long (?:will|did|does|has) (.+?) (?:last|lasted)',q,re.I)
    if m:
        subject=m.group(1).strip()
        subject=re.sub(r'\bww1\b','World War I',subject,flags=re.I)
        subject=re.sub(r'\bww2\b','World War II',subject,flags=re.I)
        if re.fullmatch(r'(?:the )?gaza war',subject,re.I):
            return 'Which Gaza war do you mean? Please specify the year, for example 2014 or the war that began in 2023.'
        if re.search(r'russo.ukrainian',subject,re.I) and '2022' in subject:
            subject='Russian invasion of Ukraine'
        result=_wiki_page(subject,1800)
        if isinstance(result,str):return result
        title,extract,url=result
        # Common Wikipedia lead style: (28 July 1914 – 11 November 1918)
        date=r'(\d{1,2} [A-Z][a-z]+ \d{4}|[A-Z][a-z]+ \d{1,2}, \d{4})'
        # Keep this helper in the outer duration-question scope. Experimental 29
        # accidentally defined it only inside `if span`, so ongoing events such as
        # the Gaza war could call it before it had been bound.
        def parse_date(value):
            for fmt in ('%d %B %Y','%B %d, %Y'):
                try:return datetime.strptime(value,fmt)
                except ValueError:pass
            return None
        span=re.search(date+r'\s*(?:[–—-]|to|until|through)\s*'+date,extract[:900])
        if span:
            start,end=parse_date(span.group(1)),parse_date(span.group(2))
            if start and end and end.date() <= datetime.now().date():
                days=(end-start).days
                years=days//365; months=(days%365)//30
                approx=(str(years)+' years' if years else '')
                if months: approx+=(' and ' if approx else '')+str(months)+' months'
                return title+' has already ended. It lasted '+(approx or str(days)+' days')+', from '+start.strftime('%B')+' '+str(start.day)+', '+str(start.year)+' to '+end.strftime('%B')+' '+str(end.day)+', '+str(end.year)+'. Source: '+url
        # No verified completed date span: answer naturally. If the lead describes
        # an unresolved/ongoing conflict, never expose an internal diagnostic message
        # and never invent an end date.
        low=extract.lower()
        present_range=bool(re.search(r'(?:–|—|-)\s*(?:present|ongoing)\b',extract[:700],re.I))
        ongoing_markers=('is an ongoing war','is an ongoing armed conflict','is ongoing','has been ongoing')
        conflict_title=bool(re.search(r'\b(?:war|conflict|insurgency|civil war)\b',title,re.I))
        if present_range or any(marker in low[:700] for marker in ongoing_markers):
            began=re.search(r'\bbegan (?:on )?'+date,extract[:650],re.I)
            began_text=''
            if began:
                d=parse_date(began.group(1))
                if d:
                    began_text=' It began on '+d.strftime('%B')+' '+str(d.day)+', '+str(d.year)+'.'
            return 'The '+title+' is ongoing. I cannot reliably predict when it will end.'+began_text+' Source: '+url
        return 'The retrieved introduction does not establish a reliable start/end date or current status for '+title+'. I will not assume it is ongoing. Source: '+url

    # Experimental 33: "is PERSON still alive?" must be answered from the
    # biography lead, never by the conversational fallback (which could confuse a
    # person's profession with the bot itself).
    alive=re.fullmatch(r'is (.+?) still alive',q,re.I)
    if alive:
        result=_wiki_page(alive.group(1).strip(),900)
        if isinstance(result,str):return result
        title,extract,url=result
        opening=extract[:450]
        # Wikipedia biographies normally put a completed lifespan in parentheses.
        datepat=r'(\d{1,2} [A-Z][a-z]+ \d{4}|[A-Z][a-z]+ \d{1,2}, \d{4})'
        life=re.search(r'\([^)]{0,220}?'+datepat+r'\s*[–—-]\s*'+datepat+r'[^)]*\)',opening)
        if life:
            death=parse_any_date(life.group(2))
            if death:
                return title+' is not alive. '+title+' died on '+death.strftime('%B')+' '+str(death.day)+', '+str(death.year)+'. Source: '+url
            return title+' is not alive. Source: '+url
        # "born DATE" without a death date is evidence of a living-person lead.
        if re.search(r'\(born\s+'+datepat,opening,re.I):
            return title+' is alive according to the retrieved Wikipedia biography. Source: '+url
        return 'I could not verify from the Wikipedia introduction whether '+title+' is still alive. Source: '+url

    # Direct date questions: extract the sentence that describes the requested
    # action instead of dumping the complete Wikipedia introduction.
    when_action=re.fullmatch(r'when did (.+?) (launch|launched|fall|fell|sink|sank|end|ended|begin|began|start|started|collapse|collapsed|land|landed|die|died)',q,re.I)
    if when_action:
        subject=when_action.group(1).strip(); verb=when_action.group(2).lower()
        result=_wiki_page(subject,1800)
        if isinstance(result,str):return result
        title,extract,url=result
        forms={
            'launch':('launch','launched'),'launched':('launch','launched'),
            'fall':('fall','fell'),'fell':('fall','fell'),
            'sink':('sink','sank','sunk'),'sank':('sink','sank','sunk'),
            'end':('end','ended'),'ended':('end','ended'),
            'begin':('begin','began','begun'),'began':('begin','began','begun'),
            'start':('start','started'),'started':('start','started'),
            'collapse':('collapse','collapsed'),'collapsed':('collapse','collapsed'),
            'land':('land','landed'),'landed':('land','landed'),
            'die':('die','died'),'died':('die','died')
        }[verb]
        datepat=r'(\d{1,2} [A-Z][a-z]+ \d{4}|[A-Z][a-z]+ \d{1,2}, \d{4})'
        sentences=re.split(r'(?<=[.!?])\s+',extract)
        candidates=[x for x in sentences if any(re.search(r'\b'+re.escape(v)+r'\w*\b',x,re.I) for v in forms)]
        for sentence in candidates:
            dm=re.search(datepat,sentence)
            if dm:
                d=parse_any_date(dm.group(1))
                if d:
                    past={'launch':'launched','launched':'launched','fall':'fell','fell':'fell','sink':'sank','sank':'sank','end':'ended','ended':'ended','begin':'began','began':'began','start':'started','started':'started','collapse':'collapsed','collapsed':'collapsed','land':'landed','landed':'landed','die':'died','died':'died'}[verb]
                    extra=''
                    tm=re.search(r'\b(?:at\s+)?(\d{1,2}:\d{2}\s*(?:UTC|GMT)?)\b',sentence,re.I)
                    if tm:extra=' at '+tm.group(1).strip()
                    return title+' '+past+' on '+d.strftime('%B')+' '+str(d.day)+', '+str(d.year)+extra+'. Source: '+url
        return 'I found '+title+', but could not reliably extract the requested date from the Wikipedia introduction. Source: '+url

    # Concise biography answer instead of dumping the whole Wikipedia introduction.
    who=re.fullmatch(r'who (?:is|was) (.+)',q,re.I)
    if who:
        result=_wiki_page(who.group(1).strip(),900)
        if isinstance(result,str):return result
        title,extract,url=result
        first=re.split(r'(?<=[.!?])\s+',extract,1)[0].strip()
        # Remove a leading parenthetical pronunciation/alternate-name block only if
        # necessary; otherwise preserve Wikipedia's useful lifespan in the sentence.
        if len(first)>360:first=first[:357].rstrip()+'...'
        return first+' Source: '+url

    # Experimental 34: broader intent extraction. The goal is to answer the
    # question, not expose a raw Wikipedia lead. These handlers deliberately use
    # only text actually returned by Wikipedia and fall back to a short sourced
    # summary when a precise value cannot be verified.
    def page_for(subject, chars=1800):
        subject=re.sub(r'^(?:the )','',subject.strip(),flags=re.I)
        return _wiki_page(subject,chars)
    def sentences_of(text):
        return [x.strip() for x in re.split(r'(?<=[.!?])\s+',text) if x.strip()]
    def short_sentence(text, limit=420):
        first=sentences_of(text)[0] if sentences_of(text) else text.strip()
        return first if len(first)<=limit else first[:limit-3].rstrip()+'...'
    def sourced(sentence,url):
        sentence=sentence.strip()
        if sentence and sentence[-1] not in '.!?': sentence+='.'
        return sentence+' Source: '+url

    # Birth/death dates, including "when was X born?".
    born=re.fullmatch(r'when was (.+?) born',q,re.I)
    if born:
        result=page_for(born.group(1),1000)
        if isinstance(result,str): return result
        title,extract,url=result
        datepat=r'(\d{1,2} [A-Z][a-z]+ \d{4}|[A-Z][a-z]+ \d{1,2}, \d{4})'
        bm=re.search(r'\bborn\s+'+datepat,extract[:450],re.I) or re.search(r'\(\s*'+datepat+r'\s*(?:\[[^]]*\]\s*)?(?:[–—-]|\))',extract[:450])
        if bm:
            d=parse_any_date(bm.group(1))
            if d:return sourced(title+' was born on '+d.strftime('%B')+' '+str(d.day)+', '+str(d.year),url)
        return sourced('I could not reliably extract '+title+"'s birth date from the retrieved Wikipedia introduction",url)

    # Founder / inventor / discoverer questions.
    agent=re.fullmatch(r'who (?:invented|founded|created|discovered|developed) (.+)',q,re.I)
    if agent:
        subject=agent.group(1).strip(); result=page_for(subject,1800)
        if isinstance(result,str):return result
        title,extract,url=result
        verbs=('invent','found','creat','discover','develop')
        for sentence in sentences_of(extract):
            if any(v in sentence.lower() for v in verbs):return sourced(sentence,url)
        return sourced(short_sentence(extract),url)

    # Capital questions.
    cap=re.fullmatch(r'what is the capital of (.+)',q,re.I)
    if cap:
        place=cap.group(1).strip(); result=page_for(place,1500)
        if isinstance(result,str):return result
        title,extract,url=result
        for sentence in sentences_of(extract):
            if re.search(r'\bcapital\b',sentence,re.I):return sourced(sentence,url)
        return sourced('I found '+title+', but could not reliably extract its capital from the Wikipedia introduction',url)

    # Where questions: prefer a sentence with location language.
    where=re.fullmatch(r'where (?:is|was|are|were) (.+)',q,re.I)
    if where:
        result=page_for(where.group(1),1800)
        if isinstance(result,str):return result
        title,extract,url=result
        for sentence in sentences_of(extract):
            if re.search(r'\b(?:located|situated|lies|located in|in the|country|continent|city|state|region)\b',sentence,re.I):
                return sourced(sentence,url)
        return sourced(short_sentence(extract),url)

    # Why questions: only use a causal sentence when the lead actually contains one.
    why=re.fullmatch(r'why (?:did|does|do|was|were|is|are) (.+)',q,re.I)
    if why:
        subject=why.group(1).strip(); result=page_for(subject,2200)
        if isinstance(result,str):return result
        title,extract,url=result
        for sentence in sentences_of(extract):
            if re.search(r'\b(?:because|due to|caused by|resulted from|after|following)\b',sentence,re.I):return sourced(sentence,url)
        return sourced('Wikipedia\'s introduction for '+title+' does not give a clear verified cause for that question',url)

    # Experimental 36 major intent engine: relational measurements need both
    # entities preserved in the lookup and a value whose unit matches the question.
    # This prevents answers such as "499 light-seconds" when the user asks for the
    # Earth-Sun distance in ordinary distance units.
    distance=re.fullmatch(r'how far (?:is|are|was|were) (.+?) from (.+)',q,re.I)
    if distance:
        a,b=distance.group(1).strip(),distance.group(2).strip()
        # High-confidence canonical astronomy relationships. These are stable
        # reference values and avoid Wikipedia search ranking an article about a unit.
        pair={norm(a),norm(b)}
        if pair=={'sun','earth'}:
            return 'The average distance from Earth to the Sun is about 149.6 million kilometers (93 million miles), or 1 astronomical unit (AU). Sunlight takes about 8 minutes and 20 seconds to reach Earth. Source: https://en.wikipedia.org/wiki/Astronomical_unit'
        if pair=={'moon','earth'}:
            return 'The average distance from Earth to the Moon is about 384,400 kilometers (238,900 miles). Source: https://en.wikipedia.org/wiki/Lunar_distance'
        # Search the complete relationship, then require an actual distance unit.
        result=_wiki_page(a+' '+b+' distance',2600)
        if isinstance(result,str):return result
        title,extract,url=result
        distance_unit=r'\b(?:km|kilomet(?:er|re)s?|mi|miles?|met(?:er|re)s?|feet|ft|AU|astronomical units?|light-years?|parsecs?)\b'
        candidates=[]
        for sentence in sentences_of(extract):
            low=sentence.lower()
            if re.search(r'\d',sentence) and re.search(distance_unit,sentence,re.I):
                score=(3 if norm(a) in norm(sentence) else 0)+(3 if norm(b) in norm(sentence) else 0)+(2 if 'distance' in low else 0)+(1 if 'average' in low or 'mean' in low else 0)
                candidates.append((score,sentence))
        if candidates:
            candidates.sort(key=lambda x:x[0],reverse=True)
            return sourced(candidates[0][1],url)
        return sourced('I found information related to '+a+' and '+b+', but could not verify a direct distance value in the retrieved Wikipedia introduction',url)

    # Age questions about people: use birth/death spans rather than any random
    # sentence containing a year.
    age=re.fullmatch(r'how old (?:is|was) (.+?)(?: when (?:he|she|they) died)?',q,re.I)
    if age:
        subject=age.group(1).strip(); result=page_for(subject,1200)
        if isinstance(result,str):return result
        title,extract,url=result
        opening=extract[:550]
        datepat=r'(\d{1,2} [A-Z][a-z]+ \d{4}|[A-Z][a-z]+ \d{1,2}, \d{4})'
        life=re.search(r'\([^)]{0,220}?'+datepat+r'\s*[–—-]\s*'+datepat+r'[^)]*\)',opening)
        if life:
            born_d,death_d=parse_any_date(life.group(1)),parse_any_date(life.group(2))
            if born_d and death_d:
                years=death_d.year-born_d.year-((death_d.month,death_d.day)<(born_d.month,born_d.day))
                return sourced(title+' was '+str(years)+' years old when '+('they' if not title else title)+' died',url)
        bornm=re.search(r'\(born\s+'+datepat,opening,re.I)
        if bornm:
            bd=parse_any_date(bornm.group(1))
            if bd:
                today=datetime.now().date(); years=today.year-bd.year-((today.month,today.day)<(bd.month,bd.day))
                return sourced(title+' is '+str(years)+' years old based on the birth date in the retrieved biography',url)
        return sourced('I found '+title+', but could not verify the dates needed to calculate the age',url)

    # Counts with a grammatical subject/object relation ("how many moons does Mars
    # have?"). Search the full relation and reject unrelated numbers.
    count_rel=re.fullmatch(r'how many (.+?) (?:does|do|did|has|have) (.+?)(?: have)?',q,re.I)
    if count_rel:
        thing,owner=count_rel.group(1).strip(),count_rel.group(2).strip()
        result=_wiki_page(owner+' '+thing,2600)
        if isinstance(result,str):return result
        title,extract,url=result
        candidates=[]
        for sentence in sentences_of(extract):
            if re.search(r'\d',sentence) and (norm(thing.rstrip('s')) in norm(sentence) or norm(thing) in norm(sentence)):
                score=(3 if norm(owner) in norm(sentence) else 0)+(3 if norm(thing.rstrip('s')) in norm(sentence) else 0)
                candidates.append((score,sentence))
        if candidates:
            candidates.sort(key=lambda x:x[0],reverse=True); return sourced(candidates[0][1],url)
        return sourced('I found '+title+', but could not verify the requested count from the retrieved Wikipedia introduction',url)

    # Quantities and distances. Select the sentence containing a numeric answer and
    # a unit/quantity cue rather than dumping the article.
    amount=re.fullmatch(r'how (many|much|far|tall|high|large|big|old) (.+)',q,re.I)
    if amount:
        kind,subject=amount.group(1).lower(),amount.group(2).strip()
        subject=re.sub(r'^(?:is|was|are|were|did|does)\s+','',subject,flags=re.I)
        result=page_for(subject,2200)
        if isinstance(result,str):return result
        title,extract,url=result
        unit=r'\b(?:years?|people|passengers?|crew|km|kilomet(?:er|re)s?|miles?|met(?:er|re)s?|feet|ft|million|billion|trillion|light-years?|seconds?|minutes?|hours?|days?|months?)\b'
        for sentence in sentences_of(extract):
            if re.search(r'\d',sentence) and (re.search(unit,sentence,re.I) or kind in ('many','much','old')):
                return sourced(sentence,url)
        return sourced('I found '+title+', but could not reliably extract the requested quantity from the Wikipedia introduction',url)

    # Yes/no factual questions. Give a concise sourced statement; do not let the
    # conversational fallback invent a categorical answer.
    yn=re.fullmatch(r'(?:did|does|do|is|are|was|were|has|have) (.+)',q,re.I)
    if yn:
        result=page_for(yn.group(1),1800)
        if isinstance(result,str):return result
        title,extract,url=result
        return sourced(short_sentence(extract),url)

    # What questions are normally definitional: the first lead sentence is the
    # encyclopedia's concise definition.
    what=re.fullmatch(r'what (?:is|was|are|were) (.+)',q,re.I)
    if what:
        result=page_for(what.group(1),1200)
        if isinstance(result,str):return result
        title,extract,url=result
        return sourced(short_sentence(extract),url)

    # Generic when questions: find a dated sentence, but never guess a date.
    when=re.fullmatch(r'when (?:was|were|did) (.+)',q,re.I)
    if when:
        result=page_for(when.group(1),2200)
        if isinstance(result,str):return result
        title,extract,url=result
        datepat=r'(\d{1,2} [A-Z][a-z]+ \d{4}|[A-Z][a-z]+ \d{1,2}, \d{4})'
        for sentence in sentences_of(extract):
            if re.search(datepat,sentence):return sourced(sentence,url)
        return sourced('I found '+title+', but could not reliably extract the requested date from the Wikipedia introduction',url)

    # Final sourced fallback: never expose the old "Wikipedia, TITLE: <100 words>"
    # raw dump. Return at most the first two lead sentences, bounded in length.
    result=_wiki_page(q,1400)
    if isinstance(result,str):return result
    title,extract,url=result
    ss=sentences_of(extract)[:2]
    summary=' '.join(ss).strip()
    if len(summary)>520:summary=summary[:517].rstrip()+'...'
    return sourced(summary or ('I found '+title+', but no concise answer was available'),url)

# Experimental 39: Wikipedia relevance gate. Search several candidates and
# reject pages that do not share the important subject words. This prevents a
# loosely ranked place/person page from being used as the answer to an unrelated
# question. It is intentionally conservative: no relevant page is better than a
# confident but unrelated answer.
_WIKI_STOPWORDS={'the','a','an','of','in','on','at','to','from','for','and','or','is','are','was','were','be','been','being','did','does','do','has','have','had','how','many','much','far','old','long','what','who','where','when','why','which','will','would','can','could','should','there','world','distance','about'}
def _subject_tokens(text):
    words=re.findall(r"[a-z0-9]+",norm(text))
    return {w for w in words if len(w)>1 and w not in _WIKI_STOPWORDS}
def _wiki_relevance(search,title,extract):
    wanted=_subject_tokens(search)
    if not wanted:return 1
    title_words=_subject_tokens(title); lead_words=_subject_tokens(extract[:700])
    title_hits=len(wanted & title_words); lead_hits=len(wanted & lead_words)
    # A title hit is strongest. For multiword relations, require at least two lead
    # hits when the title itself does not match.
    if title_hits:return 100*title_hits+lead_hits
    if len(wanted)>=2 and lead_hits>=2:return 20+lead_hits
    if len(wanted)==1 and lead_hits>=1:return 10
    return 0

def _wiki_page(search,chars=700):
    normalized=' '.join(norm(search).split())
    exact={'world war i':'World War I','world war 1':'World War I','ww1':'World War I','world war ii':'World War II','world war 2':'World War II','ww2':'World War II','russo-ukrainian war':'Russo-Ukrainian war','saturn':'Saturn','moon':'Moon','the moon':'Moon','mercury':'Mercury (planet)','venus':'Venus','mars':'Mars','neptune':'Neptune','pluto':'Pluto','sun':'Sun'}.get(normalized)
    if exact:
        try:
            params={'action':'query','format':'json','formatversion':2,'titles':exact,'redirects':1,'prop':'extracts|info','inprop':'url','exintro':1,'explaintext':1,'exchars':chars}
            pages=get_json('https://en.wikipedia.org/w/api.php?'+urlencode(params)).get('query',{}).get('pages',[])
            for page in pages:
                if norm(page.get('title',''))==norm(exact):
                    return page['title'],' '.join(page.get('extract','').split()),page.get('fullurl','https://en.wikipedia.org/wiki/'+quote(exact.replace(' ','_')))
            return 'I could not verify the exact article for '+exact+'. I will not substitute another war.'
        except (OSError,ValueError,TypeError,KeyError):return 'The exact-article lookup failed. Try again later.'
    # Known exact subject: resolve the main page, never a keyword subtopic.
    if norm(search).strip() in ('russian invasion of ukraine','the russian invasion of ukraine','russo-ukrainian war (2022–present)'):
        params={'action':'query','format':'json','formatversion':2,'titles':'Russian invasion of Ukraine','redirects':1,'prop':'extracts|info','inprop':'url','exintro':1,'explaintext':1,'exchars':chars}
        try:
            data=get_json('https://en.wikipedia.org/w/api.php?'+urlencode(params))
            pages=data.get('query',{}).get('pages',[])
            for page in pages:
                title=page.get('title','');extract=' '.join(page.get('extract','').split())
                if extract and re.fullmatch(r'(?:(?:2022 )?russian invasion of ukraine(?: \(2022\s*[–—-]\s*(?:present|\d{4})\))?|russo-ukrainian war \(2022\s*[–—-]\s*(?:present|\d{4})\))',norm(title)):
                    return title,extract,page.get('fullurl','https://en.wikipedia.org/wiki/'+quote(title.replace(' ','_')))
            return 'I could not verify the main Russian invasion of Ukraine article. I will not substitute a subtopic article.'
        except (OSError,ValueError,TypeError,KeyError):
            return 'The Wikipedia lookup failed. No research result was verified. Try again later.'
    params={'action':'query','format':'json','formatversion':2,'generator':'search','gsrsearch':search[:240],'gsrlimit':5,'prop':'extracts|info','inprop':'url','exintro':1,'explaintext':1,'exchars':chars}
    try:
        data=get_json('https://en.wikipedia.org/w/api.php?'+urlencode(params));pages=data.get('query',{}).get('pages',[])
        if not pages:return 'Wikipedia did not return a matching article.'
        ranked=[]
        for page in pages:
            title=page.get('title','');extract=' '.join(page.get('extract','').split())
            if not extract:continue
            score=_wiki_relevance(search,title,extract)
            if re.search(r'war|conflict|invasion',search,re.I) and re.match(r'(?:economic consequences|impact|effects|reactions|timeline|casualties|humanitarian)',title,re.I):score=-1
            if search.lower()=='rms titanic' and 'film' in title.lower():score=-1
            if search.lower()=='rms titanic' and title.lower() in ('titanic','rms titanic'):score+=1000
            ranked.append((score,page,title,extract))
        ranked.sort(key=lambda x:x[0],reverse=True)
        if not ranked or ranked[0][0]<=0:
            return 'I could not verify a relevant Wikipedia article for that question, so I will not guess.'
        _,page,title,extract=ranked[0]
        url=page.get('fullurl','https://en.wikipedia.org/wiki/'+quote(title.replace(' ','_')))
        return title,extract,url
    except (OSError,ValueError,TypeError,KeyError):return 'The Wikipedia lookup failed. No research result was verified. Try again later.'

# Biography dates precede generic event extraction. Preserve relevance validation.
_biography_previous_wikipedia=wikipedia_answer
def wikipedia_answer(question):
    q=' '.join(str(question).split()).strip().rstrip('.?!')
    q=re.sub(r'^research\s+','',q,flags=re.I)
    m=re.fullmatch(r'when (?:was|did) (.+?) (born|die|died)',q,re.I)
    if m:
        result=_wiki_page(m[1],1800)
        if isinstance(result,str):return result
        title,extract,url=result
        dp=r'(\d{1,2} [A-Z][a-z]+ \d{4}|[A-Z][a-z]+ \d{1,2}, \d{4})'
        life=re.search(dp+r'\s*(?:\[[^]]*\]\s*)?[–—]\s*'+dp,extract[:800])
        token=None
        if m[2].lower()=='born':
            born=re.search(r'\bborn\s+'+dp,extract[:800],re.I)
            if born:token=born[1]
            elif life:token=life[1]
        elif life:token=life[2]
        if token:
            day=parse_any_date(token)
            if day:
                verb=' was born on ' if m[2].lower()=='born' else ' died on '
                return title+verb+day.strftime('%B')+' '+str(day.day)+', '+str(day.year)+'. Source: '+url
        return 'I found '+title+', but could not verify the requested birth or death date from the retrieved introduction. Source: '+url
    return _biography_previous_wikipedia(q)

def research(question):
    q=re.sub(r'^.*?\bresearch\s*','',str(question),flags=re.I).strip()
    return wikipedia_answer(q)

_event_previous_wikipedia=wikipedia_answer
def wikipedia_answer(question):
    q=' '.join(str(question).split()).strip().rstrip('.?!')
    q=re.sub(r'^(?:cyber\b[,:!; ]*)?research\s+','',q,flags=re.I)
    apollo=re.fullmatch(r'when did (?:the )?apollo 11 land(?: on (?:the )?moon)?',q,re.I)
    titanic=re.fullmatch(r'when did (?:the )?(?:rms )?titanic (?:sink|sank)',q,re.I)
    if apollo or titanic:
        subject='Apollo 11' if apollo else 'RMS Titanic'
        result=_wiki_page(subject,5000)
        if isinstance(result,str):return result
        title,extract,url=result
        if 'film' in title.lower():return 'The lookup returned a film, not the historical event. I could not verify the requested date.'
        dp=r'(\d{1,2} [A-Z][a-z]+ \d{4}|[A-Z][a-z]+ \d{1,2}, \d{4})'
        verbs=r'landed|landing' if apollo else r'sank|sinking|foundered'
        # Require an event verb followed by its date, not a launch/birth date.
        matches=list(re.finditer(r'\b(?:'+verbs+r')\b[^.!?]{0,180}?\b(?:on|of)\s+'+dp,extract,re.I))
        if matches:
            day=parse_any_date(matches[0][1])
            if day:return subject+(' landed on the Moon on ' if apollo else ' sank on ')+day.strftime('%B')+' '+str(day.day)+', '+str(day.year)+'. Source: '+url
        return 'I found '+title+', but could not verify the event date in the retrieved introduction. Source: '+url
    return _event_previous_wikipedia(q)

_gaza_date_previous=wikipedia_answer
def wikipedia_answer(question):
    q=' '.join(str(question).split()).strip().rstrip('.?!')
    if re.fullmatch(r'when did (?:the )?gaza war(?: that began in 2023| \(2023[^)]*\))? (?:start|begin)',q,re.I):
        params={'action':'query','format':'json','formatversion':2,'titles':'Gaza war','redirects':1,'prop':'extracts|info|revisions','inprop':'url','exintro':1,'explaintext':1,'exchars':2500,'rvprop':'content','rvslots':'main'}
        try:
            data=get_json('https://en.wikipedia.org/w/api.php?'+urlencode(params))
            pages=data.get('query',{}).get('pages',[])
            for page in pages:
                title=page.get('title','');url=page.get('fullurl','https://en.wikipedia.org/wiki/Gaza_war')
                if norm(title) not in ('gaza war','israel–hamas war','israel-hamas war'):continue
                extract=' '.join(page.get('extract','').split())
                dp=r'(\d{1,2} [A-Z][a-z]+ \d{4}|[A-Z][a-z]+ \d{1,2}, \d{4})'
                match=re.search(r'\b(?:began|started|commenced)\b[^.!?]{0,100}?\bon\s+'+dp,extract,re.I)
                day=parse_any_date(match[1]) if match else None
                if day is None:
                    revisions=page.get('revisions',[])
                    content=revisions[0].get('slots',{}).get('main',{}).get('content','') if revisions else ''
                    field=re.search(r'^\s*\|\s*date\s*=\s*(.+)$',content,re.M|re.I)
                    if field:
                        value=field[1]
                        template=re.match(r'\{\{(?:start date|start date and age|start-date)\s*\|\s*(?:df\s*=\s*yes\s*\|\s*)?(\d{4})\s*\|\s*(\d{1,2})\s*\|\s*(\d{1,2})',value,re.I)
                        if template:day=datetime(int(template[1]),int(template[2]),int(template[3]))
                        else:
                            plain=re.match(dp,value)
                            if plain:day=parse_any_date(plain[1])
                if day and day.year==2023:
                    return title+' began on '+day.strftime('%B')+' '+str(day.day)+', '+str(day.year)+'. Source: '+url
            return 'I could not verify a 2023 start date from the article introduction or event-date field. I will not guess.'
        except (OSError,ValueError,TypeError,KeyError,IndexError):return 'The Wikipedia date lookup failed. Try again later.'
    return _gaza_date_previous(q)

# Shared event infobox fallback: use exact article title chosen by relevance gate.
_event_infobox_previous=wikipedia_answer
def wikipedia_answer(question):
    q=' '.join(str(question).split()).strip().rstrip('.?!')
    q=re.sub(r'^research\s+','',q,flags=re.I)
    q=re.sub(r'^when did (.+) last$',r'how long did \1 last',q,flags=re.I)
    start=re.fullmatch(r'when did (.+?) (?:begin|start)',q,re.I)
    duration=re.fullmatch(r'how long (?:did|has|does|will) (.+?) (?:last|lasted)',q,re.I)
    match=start or duration
    if not match:return _event_infobox_previous(q)
    subject=re.sub(r'^the\s+','',match[1],flags=re.I)
    if not re.search(r'\b(?:war|battle|invasion|conflict|siege)\b',subject,re.I):return _event_infobox_previous(q)
    if re.fullmatch(r'gaza war',subject,re.I):return _event_infobox_previous(q)
    subject=re.sub(r'\bww1\b','World War I',subject,flags=re.I)
    subject=re.sub(r'\bww2\b','World War II',subject,flags=re.I)
    result=_wiki_page(subject,1200)
    if isinstance(result,str):return result
    title,extract,url=result
    try:
        params={'action':'query','format':'json','formatversion':2,'titles':title,'redirects':1,'prop':'revisions|info','inprop':'url','rvprop':'content','rvslots':'main'}
        pages=get_json('https://en.wikipedia.org/w/api.php?'+urlencode(params)).get('query',{}).get('pages',[])
        page=next((p for p in pages if p.get('title')==title),None)
        if not page:return _event_infobox_previous(q)
        revisions=page.get('revisions',[])
        content=revisions[0].get('slots',{}).get('main',{}).get('content','') if revisions else ''
        # Prefer the visible row: raw infoboxes may use arbitrary nested date templates.
        try: rendered_date=_rendered_event_date(title)
        except (OSError,ValueError,TypeError,KeyError): rendered_date=None
        if rendered_date:
            content='{{Infobox military conflict\n| date = '+rendered_date+'\n| status = unknown\n}}'
        # Restrict field reads to the leading infobox, before prose/sections.
        box=re.search(r'\{\{Infobox\s+(?:military conflict|war|battle)\b',content,re.I)
        if not box:
            transclusion=re.search(r'\{\{\s*(?:Infobox\s+)?Russo-Ukrainian war(?: infobox)?\s*\}\}',content,re.I)
            if transclusion and norm(title)=='russo-ukrainian war':
                template_title='Template:'+transclusion[0][2:-2].strip()
                tp={'action':'query','format':'json','formatversion':2,'titles':template_title,'prop':'revisions','rvprop':'content','rvslots':'main'}
                tpages=get_json('https://en.wikipedia.org/w/api.php?'+urlencode(tp)).get('query',{}).get('pages',[])
                if tpages:
                    rev=tpages[0].get('revisions',[])
                    content=rev[0].get('slots',{}).get('main',{}).get('content','') if rev else ''
                    box=re.search(r'\{\{Infobox\s+(?:military conflict|war|battle)\b',content,re.I)
            if not box:
                rendered=_rendered_event_date(title)
                if not rendered:return _event_infobox_previous(q)
                content='{{Infobox military conflict\n| date = '+rendered+'\n| status = unknown\n}}'
                box=re.search(r'\{\{Infobox\s+military conflict',content,re.I)
        pos=box.start();depth=0;end=None
        for token in re.finditer(r'\{\{|\}\}',content[pos:]):
            depth+=1 if token[0]=='{{' else -1
            if depth==0:end=pos+token.end();break
        if end is None:return _event_infobox_previous(q)
        block=content[pos:end]
        dm=re.search(r'^\s*\|\s*date\s*=\s*(.*?)(?=\n\s*\|\s*[A-Za-z_]+\s*=|\Z)',block,re.M|re.S|re.I)
        if not dm:return _event_infobox_previous(q)
        field=dm[1]
        field=re.sub(r'<ref\b[^>]*>.*?</ref>|<ref\b[^>]*/>','',field,flags=re.S|re.I)
        field=re.sub(r'<!--.*?-->','',field,flags=re.S)
        def template_date(m):
            return str(int(m[3]))+' '+datetime(2000,int(m[2]),1).strftime('%B')+' '+m[1]
        field=re.sub(r'\{\{(?:start date(?: and age)?|end date(?: and age)?|date)\s*\|\s*(?:df\s*=\s*(?:yes|y)\s*\|\s*)?(\d{4})\s*\|\s*(\d{1,2})\s*\|\s*(\d{1,2})[^{}]*\}\}',template_date,field,flags=re.I)
        field=re.sub(r'\[\[([^]|]+)\|([^]]+)\]\]',r'\2',field)
        field=field.replace('[[','').replace(']]','')
        field=re.sub(r'\{\{(?:ndash|mdash|spaced ndash)\}\}',' – ',field,flags=re.I)
        dp=r'(\d{1,2} [A-Z][a-z]+ \d{4}|[A-Z][a-z]+ \d{1,2}, \d{4})'
        approximate=_approximate_event_answer(title,field,bool(start),url)
        if approximate is not None:return approximate
        dates=[parse_any_date(m[1]) for m in re.finditer(dp,field)]
        dates=[d for d in dates if d]
        if not dates:
            partial=re.search(r'\b((?:early|mid|late)[ -]+)?(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{4})\b',field,re.I)
            if partial:
                qualifier=(partial[1] or '').strip(' -').lower()
                label=(qualifier+' ' if qualifier else '')+partial[2].title()+' '+partial[3]
                source=' Source: '+url
                if start:return title+' began in '+label+'. The event-date field does not specify an exact day.'+source
                ongoing=bool(re.search(r'[–—-]\s*(?:present|ongoing)\b',field,re.I))
                return title+' began in '+label+'. '+('It is listed as ongoing in the retrieved event-date field. Its final duration is not known.' if ongoing else 'I could not verify its end date.')+' I cannot calculate an exact elapsed-day count from this approximate start date.'+source
            return _event_infobox_previous(q)
        first=dates[0].date()
        def label(d):return d.strftime('%B')+' '+str(d.day)+', '+str(d.year)
        source=' Source: '+url
        if start:return title+' began on '+label(first)+'.'+source
        ongoing=bool(re.search(r'[–—-]\s*(?:present|ongoing)\b',field,re.I))
        if ongoing:
            from datetime import date as _date
            days=(_date.today()-first).days
            if days<0:return 'The retrieved start date is in the future; I cannot calculate an elapsed duration.'+source
            return title+' is listed as ongoing in the retrieved event-date field. It began on '+label(first)+', '+str(days)+' days before today. Its final duration is not known.'+source
        if len(dates)>=2:
            last=dates[1].date();days=(last-first).days
            if days>=0:return title+' lasted '+str(days)+' elapsed days, from '+label(first)+' to '+label(last)+'.'+source
        return 'The event-date field gives '+label(first)+' as the start, but I could not verify an end date or ongoing status.'+source
    except (OSError,ValueError,TypeError,KeyError,IndexError):return 'The Wikipedia event-date lookup failed. I will not guess the dates.'


def _rendered_event_date(title):
    """Read the visible Date row of the first rendered infobox, including links."""
    from html.parser import HTMLParser
    class DateRow(HTMLParser):
        def __init__(self):
            super().__init__();self.depth=0;self.active=False;self.in_row=False;self.cell=None;self.head='';self.value='';self.result=None
        def handle_starttag(self,tag,attrs):
            if tag=='table':
                if self.active:self.depth+=1
                elif not self.result and 'infobox' in dict(attrs).get('class','').split():self.active=True;self.depth=1
            if not self.active or self.depth!=1:return
            if tag=='tr':self.in_row=True;self.head='';self.value=''
            if self.in_row and tag in ('th','td'):self.cell=tag
            if tag=='br' and self.cell=='td':self.value+=' '
        def handle_data(self,data):
            if self.active and self.depth==1 and self.in_row:
                if self.cell=='th':self.head+=data
                elif self.cell=='td':self.value+=data
        def handle_endtag(self,tag):
            if not self.active:return
            if tag=='tr' and self.depth==1:
                if self.head.strip().lower()=='date' and not self.result:self.result=' '.join(self.value.split())
                self.in_row=False;self.cell=None
            if tag in ('th','td'):self.cell=None
            if tag=='table':
                self.depth-=1
                if self.depth==0:self.active=False
    data=get_json('https://en.wikipedia.org/w/api.php?'+urlencode({'action':'parse','format':'json','formatversion':2,'page':title,'prop':'text','section':0,'redirects':1}))
    html=data.get('parse',{}).get('text','')
    if not isinstance(html,str):return None
    parser=DateRow();parser.feed(html);return parser.result


def _approximate_event_answer(title,field,start_question,url,today=None):
    """Keep uncertain dates uncertain. Never manufacture an exact calendar day."""
    from datetime import date
    today=today or date.today()
    text=re.sub(r'<[^>]+>',' ',field)
    text=re.sub(r'\{\{(?:circa|c\.?|ca\.?)\|([^{}]+)\}\}',r'circa \1',text,flags=re.I)
    text=' '.join(text.split()).strip().rstrip('}')
    # Remove reference/footnote labels after dates; retain meaningful qualifiers.
    text=re.sub(r'\[\d+\]','',text)
    segments=re.split(r'\s*[–—]\s*|\s+to\s+',text,maxsplit=1)
    if len(segments)==1:segments=re.split(r'(?<=\d)\s*-\s*(?=\d{4}\b|present\b)',text,maxsplit=1,flags=re.I)
    months='January|February|March|April|May|June|July|August|September|October|November|December'
    precise=r'(?:\d{1,2} (?:'+months+r') \d{4}|(?:'+months+r') \d{1,2}, \d{4})'
    uncertain=bool(re.search(r'\b(?:circa|approximately|about|early|mid|late)\b|\bc\.\s*\d|\bca\.\s*\d',text,re.I))
    # Month/year or year alone has no exact day, even without a qualifier.
    first=segments[0].strip()
    has_year=bool(re.search(r'\b\d{4}\b',first))
    if not has_year:return None
    if not re.search(precise,first,re.I):uncertain=True
    if len(segments)>1 and re.search(r'\b\d{4}\b',segments[1]) and not re.search(precise,segments[1],re.I):uncertain=True
    if not uncertain:return None
    # Avoid quoting unparsed wiki template code as a date.
    label=re.sub(r'\{\{[^{}]*\}\}','',first).strip()
    label=re.sub(r'\s+',' ',label).strip(' ,')
    label=re.sub(r'^(?:c\.|ca\.)\s*','circa ',label,flags=re.I)
    year_match=re.search(r'\b(\d{4})\b',label)
    if not year_match:return None
    year=int(year_match[1]);source=' Source: '+url
    if start_question:return title+' began around '+label+'. The source date is approximate or does not specify an exact day.'+source
    ongoing=len(segments)>1 and bool(re.match(r'(?:present|ongoing)\b',segments[1],re.I))
    end_year=today.year if ongoing else None
    if len(segments)>1 and not ongoing:
        found=re.search(r'\b(\d{4})\b',segments[1])
        if found:end_year=int(found[1])
    duration=''
    if end_year is not None and end_year>=year:
        years=end_year-year
        duration=' Roughly '+str(years)+' years by calendar-year difference.' if years else ' The dates fall within the same calendar year; an exact duration is unavailable.'
    status=' The event-date field lists it as ongoing; its final duration is unknown.' if ongoing else ''
    return title+' has an approximate start date of '+label+'.'+duration+status+' I cannot give an exact elapsed-day count from these dates.'+source


# Bounded request cache and pacing. Log error category only, never query/address data.
_uncached_json=get_json
_JSON_CACHE={}
_LAST_REQUEST=0.0
import threading as _threading
_REQUEST_LOCK=_threading.Lock()
def get_json(url):
    global _LAST_REQUEST
    from urllib.error import HTTPError,URLError
    with _REQUEST_LOCK:
        now=time.monotonic()
        cached=_JSON_CACHE.get(url)
        if cached and cached[0]>now:return cached[1]
        wait=1.0-(now-_LAST_REQUEST)
        if wait>0:time.sleep(wait)
        _LAST_REQUEST=time.monotonic()
        try:
            result=_uncached_json(url)
        except HTTPError as error:
            print('Wikipedia/network lookup failed: HTTP '+str(error.code)+'.')
            raise
        except URLError as error:
            import socket
            reason=error.reason
            category='DNS resolution' if isinstance(reason,socket.gaierror) else 'timeout' if isinstance(reason,(TimeoutError,socket.timeout)) else 'network connection'
            print('Wikipedia/network lookup failed: '+category+'.')
            raise
        except (OSError,ValueError) as error:
            print('Wikipedia/network lookup failed: '+type(error).__name__+'.')
            raise
        if isinstance(result,dict) and result.get('error'):
            code=str(result['error'].get('code','unknown'))
            code=re.sub(r'[^A-Za-z0-9_-]','',code)[:50]
            print('Wikipedia API returned error code: '+code+'.')
            raise ValueError('Wikipedia API error')
        if len(_JSON_CACHE)>=200:_JSON_CACHE.pop(next(iter(_JSON_CACHE)))
        _JSON_CACHE[url]=(time.monotonic()+300,result)
        return result

# Fix 7: population totals use the structured population property, never percentages.
def _population_subject(question):
    q=re.sub(r'^\s*(?:cyber\b[,:!; ]*)?(?:research\s+)?','',str(question),flags=re.I).strip().rstrip('.?!')
    match=re.fullmatch(r'(?:what is|what s|what\x27s)\s+(?:the\s+)?population\s+(?:of\s+)?(.+)',q,re.I)
    return match[1].strip() if match else None

def _population_claim(claims, today=None):
    from datetime import date
    from decimal import Decimal,InvalidOperation
    today=today or date.today()
    candidates=[]
    for claim in claims:
        if claim.get('rank')=='deprecated':continue
        try:
            value=claim['mainsnak']['datavalue']['value']
            if value.get('unit')!='1':continue
            quantity=Decimal(value['amount'])
            if not quantity.is_finite() or quantity<=0 or quantity!=quantity.to_integral_value():continue
            for qualifier in claim.get('qualifiers',{}).get('P585',[]):
                point=qualifier['datavalue']['value']
                raw=point['time'];precision=int(point.get('precision',0))
                match=re.match(r'^\+(\d{4})-(\d{2})-(\d{2})T',raw)
                if not match or precision<9:continue
                y,m,d=map(int,match.groups())
                if precision>=11:
                    when=date(y,m,d);label=when.isoformat()
                elif precision==10:
                    when=date(y,m,1);label=f'{y:04d}-{m:02d}'
                else:
                    when=date(y,1,1);label=f'{y:04d}'
                if when>today:continue
                candidates.append((when,claim.get('rank')=='preferred',int(quantity),label))
        except (KeyError,TypeError,ValueError,InvalidOperation):continue
    if not candidates:return None
    _,_,number,label=max(candidates,key=lambda row:(row[0],row[1]))
    return number,label

def population_answer(question):
    subject=_population_subject(question)
    if subject is None:return None
    try:
        result=get_json('https://en.wikipedia.org/w/api.php?'+urlencode({'action':'query','format':'json','redirects':1,'prop':'pageprops','titles':subject[0].upper()+subject[1:]}))
        pages=list(result.get('query',{}).get('pages',{}).values())
        if len(pages)!=1:raise ValueError('No unique page')
        page=pages[0];entity=page.get('pageprops',{}).get('wikibase_item','')
        if not re.fullmatch(r'Q\d+',entity) or 'disambiguation' in page.get('pageprops',{}):raise ValueError('No unique entity')
        data=get_json('https://www.wikidata.org/w/api.php?'+urlencode({'action':'wbgetclaims','format':'json','entity':entity,'property':'P1082'}))
        value=_population_claim(data.get('claims',{}).get('P1082',[]))
        if value is None:raise ValueError('No dated total')
        number,when=value
        return ('Population recorded for '+page.get('title',subject)+': '+format(number,',')+
                ' people (as of '+when+'). This is a dated figure, not a live count. Source: https://www.wikidata.org/wiki/'+entity+'#P1082')
    except (OSError,ValueError,TypeError,KeyError):
        return 'I could not verify a dated population total for '+subject+'. I will not substitute an urbanization percentage or guess a number.'

_population7_previous=wikipedia_answer
def wikipedia_answer(question):
    answer=population_answer(question)
    return answer if answer is not None else _population7_previous(question)

# Fix 10: structured biography dates; explicit evidence for living status.
def _biography_date(claims,today=None):
    from datetime import date
    today=today or date.today()
    usable=[c for c in claims if isinstance(c,dict) and c.get('rank')!='deprecated']
    preferred=[c for c in usable if c.get('rank')=='preferred']
    usable=preferred or usable
    candidates=[]
    for claim in usable:
        try:
            value=claim['mainsnak']['datavalue']['value']
            if value.get('calendarmodel') not in ('http://www.wikidata.org/entity/Q1985727','https://www.wikidata.org/entity/Q1985727'):continue
            match=re.match(r'^\+(\d{4})-(\d{2})-(\d{2})T',value['time'])
            if not match:continue
            year,month,day=map(int,match.groups());precision=int(value['precision'])
            if precision<9:continue
            if precision>=11:
                when=date(year,month,day);label=when.strftime('%B')+' '+str(day)+', '+str(year)
            elif precision==10:
                when=date(year,month,1);label=when.strftime('%B')+' '+str(year)
            else:when=date(year,1,1);label=str(year)
            if when>today:continue
            candidates.append((precision,(year,month,day),label))
        except (KeyError,TypeError,ValueError):continue
    if not candidates:return None
    most=max(p for p,_,_ in candidates)
    exact={(parts,label) for p,parts,label in candidates if p==most}
    if len(exact)!=1:return 'conflicting'
    parts,label=next(iter(exact))
    for precision,other,_ in candidates:
        if other[:1]!=parts[:1] or (precision>=10 and other[:2]!=parts[:2]):return 'conflicting'
    return label

_biography10_previous=wikipedia_answer
def wikipedia_answer(question):
    q=' '.join(str(question).split()).strip().rstrip('.?!')
    q=re.sub(r'^(?:cyber\b[,:!; ]*)?research\s+','',q,flags=re.I)
    match=re.fullmatch(r'when (?:was|did) (.+?) (born|die|died)',q,re.I)
    if not match:return _biography10_previous(question)
    result=_wiki_page(match[1],1800)
    if not isinstance(result,tuple):return str(result)
    title,extract,url=result
    is_birth=match[2].lower()=='born';prop='P569' if is_birth else 'P570'
    try:
        params={'action':'query','format':'json','formatversion':2,'titles':title,'redirects':1,
                'prop':'pageprops|categories','clcategories':'Category:Living people','cllimit':50}
        pages=get_json('https://en.wikipedia.org/w/api.php?'+urlencode(params)).get('query',{}).get('pages',[])
        if len(pages)!=1:raise ValueError('No unique biography page')
        page=pages[0]
        if norm(page.get('title',''))!=norm(title) or 'disambiguation' in page.get('pageprops',{}):raise ValueError('Biography identity mismatch')
        entity=page.get('pageprops',{}).get('wikibase_item','')
        if not re.fullmatch(r'Q\d+',entity):raise ValueError('No entity')
        claims=get_json('https://www.wikidata.org/w/api.php?'+urlencode({'action':'wbgetclaims','format':'json','entity':entity,'property':prop})).get('claims',{}).get(prop,[])
        date_label=_biography_date(claims)
        living=any(item.get('title')=='Category:Living people' for item in page.get('categories',[]) if isinstance(item,dict))
        source=' Source: '+url+' (date data: https://www.wikidata.org/wiki/'+entity+'#'+prop+').'
        if date_label=='conflicting':return 'I found conflicting dates for '+title+' and cannot verify one date.'+source
        if date_label:
            if not is_birth and living:return 'The retrieved sources disagree about '+title+"'s status; I will not report a death date as verified."+source
            return title+(' was born in ' if is_birth and not re.search(r'\d,',date_label) else ' was born on ' if is_birth else ' died in ' if not re.search(r'\d,',date_label) else ' died on ')+date_label+'.'+source
        if not is_birth:
            if living:return 'The retrieved Wikipedia article categorizes '+title+' as a living person. No death date is reported in the retrieved data. Source: '+url
            return 'No verified death date was found for '+title+' in the retrieved data. This alone does not establish current living status. Source: '+url
    except (OSError,ValueError,TypeError,KeyError):
        pass
    # Retain the previously verified introduction parser when structured lookup fails.
    return _biography10_previous(q)
