"""BonziBuddy NBD customizer. Python 3.8+, standard library only."""
import datetime
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

BASE = Path(__file__).resolve().parent

def decode(data):
    trailing = data.endswith(b'\r\n')
    chunks = data.split(b'\r\n')
    if trailing:
        chunks.pop()
    if not chunks or any(not x or len(x) % 2 for x in chunks):
        raise ValueError('Unrecognized NBD layout: empty or odd-length record.')
    records = [bytes((v + 1) % 256 for v in b[1::2]).decode('cp1252') for b in chunks]
    if any('<sp=' not in s or '\x00' in s for s in records):
        raise ValueError('Unrecognized NBD content. No files were changed.')
    return records, chunks, trailing

def read_records(readable, original, resize=False):
    before = decode(original)[0]
    result = []
    for line_no, line in enumerate(readable.read_text(encoding='utf-8-sig').splitlines(), 1):
        if not line.strip() or line.lstrip().startswith('```'):
            continue
        line = re.sub(r'^\[\d+\] ?', '', line)
        if '<sp=' not in line:
            # Accept report headings only before the first actual record.
            if not result and re.match(r'^(CLASSIC |BONZIBUDDY|Source:|Records:|Original |Header |Record numbers|Edition:|\[username\])', line, re.I):
                continue
            raise ValueError('TXT line %d is not a complete record. Keep each script on one line.' % line_no)
        result.append(line)
    if not result:
        raise ValueError('TXT contains no script records.')
    if not resize and len(result) != len(before):
        raise ValueError('TXT has %d records; NBD requires %d. File: %s. Blank lines and reading labels are ignored; restore missing records or remove extra ones.' % (len(result), len(before), readable))
    prefix = before[0].split('<', 1)[0]
    if result and result[0].startswith('<'):
        result[0] = prefix + result[0]
    return result

def encode(records, original, resize=False):
    before, chunks, trailing = decode(original)
    if not records:
        raise ValueError('At least one record is required.')
    if not resize and len(records) != len(before):
        raise ValueError('TXT has %d records; NBD requires %d.' % (len(records), len(before)))
    prefix = before[0].split('<', 1)[0]
    if records[0].split('<', 1)[0] != prefix:
        raise ValueError('Keep the original Header prefix on the first line.')
    result = []
    templates = [(before[i % len(before)], chunks[i % len(chunks)]) for i in range(len(records))]
    for index, (text, (old, chunk)) in enumerate(zip(records, templates), 1):
        if text == old:
            result.append(chunk)
            continue
        if not text or '<sp=' not in text or text.count('<sp=') != len(re.findall(r'<sp=[^>]*>', text)):
            raise ValueError('Record %d has a missing or unfinished speech tag.' % index)
        if '\r' in text or '\n' in text or '\x00' in text:
            raise ValueError('Keep each record on one line.')
        fill = chunk[::2]
        data = text.encode('cp1252')
        buf = bytearray()
        for i, c in enumerate(data):
            buf.extend((fill[i % len(fill)], (c - 1) % 256))
        result.append(bytes(buf))
    data = b'\r\n'.join(result) + (b'\r\n' if trailing else b'')
    if decode(data)[0] != records:
        raise ValueError('Encoded line delimiter collision; adjust the edited wording.')
    return data

def backup(path):
    destination = BASE / 'backups' / datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    destination.mkdir(parents=True, exist_ok=False)
    shutil.copy2(path, destination / path.name)
    for sr in path.parent.iterdir():
        if sr.is_file() and sr.name.lower() == (path.name + '-sr').lower():
            shutil.copy2(sr, destination / sr.name)
    return destination

def export(path):
    records, _, _ = decode(path.read_bytes())
    folder = BASE / 'readable'
    folder.mkdir(exist_ok=True)
    target = folder / (path.name + '.txt')
    if target.exists():
        raise ValueError('Readable copy already exists. Use Edit, or rename it before exporting again.')
    target.write_text('\n'.join(records) + '\n', encoding='utf-8')
    return target

def apply(path, readable):
    original = path.read_bytes()
    records = read_records(readable, original)
    data = encode(records, original)
    if data == original:
        return None
    saved = backup(path)
    temp = path.with_name(path.name + '.customizer.tmp')
    try:
        with temp.open('xb') as stream:
            stream.write(data)
        os.replace(str(temp), str(path))
    except Exception:
        if temp.exists():
            temp.unlink()
        raise
    return saved

def open_editor(path):
    if os.name != 'nt':
        raise ValueError('The Notepad editor launcher requires Windows.')
    subprocess.run(['notepad.exe', str(path)], check=True)

def choose_folder():
    value = input('BonziBuddy data folder (containing .nbd files): ').strip().strip('"')
    folder = Path(value).expanduser().resolve()
    if not folder.is_dir():
        raise ValueError('Folder does not exist.')
    return folder

def main():
    print('BonziBuddy Customizer - target versions 2.0 through 4.1.0.9')
    print('Format checked against supplied samples; other installations need testing.')
    print('Close BonziBuddy before applying changes. Python 3.8+ is required.')
    folder = choose_folder()
    while True:
        files = sorted((p for p in folder.iterdir() if p.is_file() and p.suffix.lower() == '.nbd'), key=lambda p:p.name.lower())
        print('\nJ=jokes, T=facts, P=personality, S=songs')
        for i, path in enumerate(files, 1):
            print('%d. %s' % (i, path.name))
        print('A. Export ALL NBD files to readable TXT')
        print('0. Exit   F. Change folder')
        choice = input('Select file: ').strip()
        if choice == '0':
            return
        try:
            if choice.lower() == 'a':
                for item in files:
                    try:
                        print('Exported:', export(item))
                    except (ValueError, OSError, UnicodeError) as exc:
                        print('%s: %s' % (item.name, exc))
                continue
            if choice.lower() == 'f':
                folder = choose_folder()
                continue
            number = int(choice)
            if not 1 <= number <= len(files):
                raise ValueError('Choose a listed file number.')
            path = files[number - 1]
            records = decode(path.read_bytes())[0]
            print('%s: %d records. Keep record count and Header prefix.' % (path.name, len(records)))
            print('1. Export readable TXT   2. Edit TXT in Notepad')
            print('3. Validate TXT          4. Apply TXT with backup')
            print('5. Restore an NBD backup')
            print('6. Convert chosen TXT (same record count)')
            print('7. Build TEST NBD from 1 or more TXT records   0. Back')
            action = input('Action: ').strip()
            txt = BASE / 'readable' / (path.name + '.txt')
            print('Matching TXT:', txt)
            if action == '1':
                print('Exported:', export(path))
            elif action == '2':
                if not txt.exists():
                    export(path)
                open_editor(txt)
            elif action == '3':
                encode(read_records(txt, path.read_bytes()), path.read_bytes())
                print('Encoding and record checks passed. Voice/animation playback still needs testing.')
            elif action == '4':
                saved = apply(path, txt)
                print('Applied. Backup: %s' % saved if saved else 'No changes to apply.')
            elif action == '7':
                chosen = Path(input('Full path to your test TXT (1 or more records): ').strip().strip(chr(34)))
                original = path.read_bytes()
                test_records = read_records(chosen, original, resize=True)
                data = encode(test_records, original, resize=True)
                selection = next((sr for sr in path.parent.iterdir() if sr.is_file() and sr.name.lower() == (path.name + '-sr').lower()), None)
                if selection is not None and not re.fullmatch(rb'(?:[0-9]+,)+\r\n', selection.read_bytes()):
                    raise ValueError('Unrecognized selection list format; test build cancelled.')
                destination = BASE / 'rebuilt' / datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
                destination.mkdir(parents=True, exist_ok=False)
                (destination / path.name).write_bytes(data)
                if selection is not None:
                    import random
                    order = list(range(1, len(test_records) + 1))
                    random.SystemRandom().shuffle(order)
                    (destination / selection.name).write_bytes((''.join(str(n) + ',' for n in order) + '\r\n').encode('ascii'))
                print('Built %d-record TEST NBD: %s' % (len(test_records), destination / path.name))
                print('Matching SR rebuilt.' if selection else 'No original SR found; none created.')
                print('Installed files unchanged. Back up originals and close BonziBuddy before testing this NBD and its matching SR together.')
            elif action == '6':
                chosen = Path(input('Full path to your edited TXT: ').strip().strip(chr(34)))
                data = encode(read_records(chosen, path.read_bytes()), path.read_bytes())
                destination = BASE / 'rebuilt' / datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
                destination.mkdir(parents=True, exist_ok=False)
                (destination / path.name).write_bytes(data)
                for sr in path.parent.iterdir():
                    if sr.is_file() and sr.name.lower() == (path.name + '-sr').lower():
                        shutil.copy2(sr, destination / sr.name)
                print('Converted TXT to NBD:', destination / path.name)
                print('Installed files unchanged. Close BonziBuddy before copying the rebuilt file into its folder.')
            elif action == '5':
                src = Path(input('Full path to backed-up NBD: ').strip().strip('"'))
                restored = src.read_bytes()
                decode(restored)
                if src.name.lower() != path.name.lower():
                    raise ValueError('Backup filename must match the selected file.')
                # Record-count-preserving editor does not change the selection list.
                if len(decode(restored)[0]) != len(records):
                    raise ValueError('Backup record count differs; restore matching NBD/SR manually.')
                saved = backup(path)
                shutil.copyfile(src, path)
                print('Restored. Previous file backed up to:', saved)
        except (ValueError, OSError, UnicodeError, subprocess.SubprocessError) as exc:
            print('Error:', exc)

if __name__ == '__main__':
    try:
        main()
    except (EOFError, KeyboardInterrupt):
        print('\nClosed.')
    except (ValueError, OSError) as exc:
        print('Error:', exc)
        sys.exit(1)
