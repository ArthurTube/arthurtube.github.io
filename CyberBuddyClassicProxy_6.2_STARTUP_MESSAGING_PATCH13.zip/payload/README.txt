CYBERBUDDY CLASSIC PROXY 6.2 — PATCH 14 FAST NEWS

This release bundles the classic major update plus all corrections through
Biography Fix 10. It is an unofficial recreation of classic Cyber behavior.
Original Cyber bot: John DeFino, January 2002. Original 3D character credit:
Bob Norris, UIN 29583. Proxy/recreation project credit: Arthur Tube.
The original AI engine is not included. Bundled character variant unidentified.

UPDATE WITHOUT RESETTING DATA
1. Close both Proxy and Cyber service windows; do not uninstall.
2. Run the EXE and select the SAME installed folder:
C:\Users\belad\AppData\Local\Programs\CyberBuddy Classic Proxy\CyberBuddyClassicProxy_6.2
3. Existing Python code is backed up before replacement. Saved memory,
   UIN files and proxy.ini are not included as replacement payloads. Existing
   AI settings and announcements are installed only if absent.
4. Python and original CyberBuddy components are optional; do not reinstall
   existing dependencies unnecessarily. No automatic downloads are required
   by the offline installer. General conversation needs your local Ollama model.
5. Reopen START_PROXY.bat and ask: Cyber, what version are you running?
Expected: CyberBuddy Classic Proxy 6.2 - Patch 14 Fast News
This is a modern Windows 10/11 build with classic behavior, not an XP build.

INCLUDED FIXES
Location grammar with/without in; timezone clocks; matching-only unlearning;
classic synonyms and quoted commands; explicit research animation cleanup;
exact/verified-redirect definitions; structured population totals and dates;
structured biography dates with explicit source evidence for living status.

CLASSIC FEATURES
Per-UIN profiles, facts and phrases; local queued messages; name/UIN recipient
resolution; away/return status; announcements; same-article research follow-up;
math and conversions; clocks; entertainment horoscope/lucky numbers; trivia;
help and actual local bot-message activity; diagnostics; shared-file locking.

HELP / ACTIVITY
http://127.0.0.1:8081/cyber/help
http://127.0.0.1:8081/cyber/activity
Or open installed CLASSIC_HELP.html. Activity shows 24 hourly buckets of
messages this bot handled, not all peer-to-peer traffic from the old service.
Central timezone is used if available; otherwise UTC is explicitly labeled.

ANNOUNCEMENTS
Existing cyber_announcements.json is preserved. Its default is []. Example:
[{"id":"local-1","text":"Local test announcement","enabled":true}]
Announcements appear once per UIN; asking any announcements repeats them.
The local tests verified once-per-user behavior across service restart.

MESSAGE DELIVERY
Known recipients only; use UIN when names are ambiguous. Up to three pending
messages attach to a recipient's next bot reply. This is next-contact delivery,
not automatic delivery merely because someone logs into a directory. A local
archive is retained. Receipt passed the isolated loopback test; that does not
certify delivery to another Windows computer.

VERIFICATION COMPLETED HERE
52 automated test executions passed (including shared regression groups).
Two native UDP clients tested actual local send/receive, queue persistence
across a service restart, recipient isolation, second-user away lookup,
clearing status, public/private addressing and announcement persistence.
The local HTTP help/activity endpoints returned 200 and the activity page
contained 24 actual hourly buckets. Research uses synthetic fixtures in the
suite. The separate offline self-check passed 23 checks with temporary data.
No real user memory is read/reset by these tests. Native source tests use
isolated ports so they do not contact an installed Cyber service.
NSIS compilation, archive integrity and embedded-source matching are checked
separately. See VALIDATION_REPORT.json for completed and remaining checks.

REMAINING ACCEPTANCE CHECKS
Install this consolidated release on Windows, confirm version and saved data,
open help/activity, and test against a second Windows client if available.
No cross-computer success is claimed. Live sources can be incomplete/stale.
The reported Avast review is unresolved. Tests/hashes are not a safety verdict.
Bundled dependency EXEs are retained from the previous offline package; their
signatures/trust have not been independently certified. No security exclusion
or security-policy bypass is introduced by this release.


=== Native LAN Release 12 ===
Native LAN Patch 12 is integrated into this package. Native LAN is detected automatically; no CONFIGURE_NATIVE_LAN step is required. Existing memory, settings, and UIN data are preserved during update installation. The recorded practical Patch 12 test passed.


PATCH 13 - STARTUP SERVER-BASED MESSAGING
The launcher now starts ENSURE_SERVER_BASED_MESSAGING.py. While the original CyberBuddy Advanced Options control exists, the guard keeps "Use Server Based Instant Messaging" checked. Patch 12 Chat/LAN transport is unchanged. Existing Memory, settings and UIN data are preserved.
