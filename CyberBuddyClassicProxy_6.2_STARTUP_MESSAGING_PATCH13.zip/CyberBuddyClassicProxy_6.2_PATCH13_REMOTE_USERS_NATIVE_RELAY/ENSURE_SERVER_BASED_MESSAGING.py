"""CyberBuddy Classic Proxy 6.2 Patch 13.
Keeps the original CyberBuddy 'Use Server Based Instant Messaging' checkbox enabled
whenever its Advanced Options window/control is present. Uses Win32 only; no third-party packages.
"""
import ctypes, os, time
from ctypes import wintypes

LABEL = "Use Server Based Instant Messaging"
BM_GETCHECK = 0x00F0
BM_SETCHECK = 0x00F1
BM_CLICK = 0x00F5
BST_CHECKED = 1
WM_GETTEXT = 0x000D
WM_GETTEXTLENGTH = 0x000E
PRIVATE_BUTTON_WHEN_GROUP_ACTIVE = "Private"
PRIVATE_BUTTON_WHEN_PRIVATE_ACTIVE = "Group"

private_applied = False
chat_seen_this_scan = False

if os.name != "nt":
    raise SystemExit(0)

user32 = ctypes.WinDLL("user32", use_last_error=True)
EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
EnumChildProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

def text(hwnd):
    n = user32.SendMessageW(hwnd, WM_GETTEXTLENGTH, 0, 0)
    if n < 0 or n > 4096: return ""
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.SendMessageW(hwnd, WM_GETTEXT, n + 1, ctypes.byref(buf))
    return buf.value

def keep_checked(hwnd):
    if text(hwnd).strip().lower() != LABEL.lower(): return
    state = user32.SendMessageW(hwnd, BM_GETCHECK, 0, 0)
    if state != BST_CHECKED:
        user32.SendMessageW(hwnd, BM_SETCHECK, BST_CHECKED, 0)
        # BM_SETCHECK changes visual state; BM_CLICK also lets CyberBuddy process the setting.
        if user32.SendMessageW(hwnd, BM_GETCHECK, 0, 0) != BST_CHECKED:
            user32.SendMessageW(hwnd, BM_CLICK, 0, 0)
        print("Enabled:", LABEL, flush=True)

def child_cb(hwnd, lparam):
    global private_applied, chat_seen_this_scan
    keep_checked(hwnd)
    label = text(hwnd).strip()
    if label.lower() in (PRIVATE_BUTTON_WHEN_GROUP_ACTIVE.lower(), PRIVATE_BUTTON_WHEN_PRIVATE_ACTIVE.lower()):
        chat_seen_this_scan = True
        if not private_applied:
            # CyberBuddy toggle text describes the action, not the current mode:
            # "Private" => Group is active, so click once to enter Private.
            # "Group"   => Private is already active; leave it untouched.
            if label.lower() == PRIVATE_BUTTON_WHEN_GROUP_ACTIVE.lower():
                user32.SendMessageW(hwnd, BM_CLICK, 0, 0)
                print("Startup Chat mode set to Private (toggle should now show Group).", flush=True)
            else:
                print("Startup Chat mode already Private (toggle shows Group).", flush=True)
            private_applied = True
    return True

def window_cb(hwnd, lparam):
    title = text(hwnd).lower()
    if "cyberbuddy" in title or "advanced options" in title:
        user32.EnumChildWindows(hwnd, EnumChildProc(child_cb), 0)
    return True

def main():
    global private_applied, chat_seen_this_scan
    print("CyberBuddy 6.2 Patch 13 - Server Based Messaging guard active.", flush=True)
    print("Startup Chat mode: Private once per CyberBuddy session; no repeated Group/Private clicking.", flush=True)
    print("The guard does not change UIN, Memory, settings files, or Chat/LAN transport.", flush=True)
    missing_scans = 0
    while True:
        chat_seen_this_scan = False
        user32.EnumWindows(EnumWindowsProc(window_cb), 0)
        if chat_seen_this_scan:
            missing_scans = 0
        else:
            missing_scans += 1
            # Re-arm only after CyberBuddy/Chat has been absent long enough to count as a new session.
            if missing_scans >= 10:
                private_applied = False
        time.sleep(0.4)

if __name__ == "__main__":
    main()
