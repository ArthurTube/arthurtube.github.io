@echo off
setlocal
cd /d "%~dp0"
py -3 -c "import sys;sys.exit(0 if sys.version_info >= (3,8) else 1)" >nul 2>&1
if not errorlevel 1 (
    py -3 "%~dp0customizer.py"
    goto finish
)
python -c "import sys;sys.exit(0 if sys.version_info >= (3,8) else 1)" >nul 2>&1
if not errorlevel 1 (
    python "%~dp0customizer.py"
    goto finish
)
echo Python 3.8 or newer is required. Install Python, then run this BAT again.
:finish
pause
endlocal
