"""Configure trusted LAN peers, with backups. Never changes user memory/UINs."""
from pathlib import Path
import configparser,datetime,json,shutil,socket,sys,io,os,tempfile
import cyber_lan
ROOT=Path(__file__).resolve().parent

def backup(path):
    if path.exists():shutil.copy2(path,path.with_name(path.name+'.before_lan_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.bak'))

def main():
    import tkinter as tk
    from tkinter import simpledialog,messagebox
    ui=tk.Tk();ui.withdraw()
    try:
        try:settings=cyber_lan.read_settings()
        except (OSError,ValueError):settings={'enabled':False,'host_ip':None,'allowed_clients':[]}
        action=messagebox.askyesnocancel('Cyber native LAN','Enable Cyber LAN / private VPN access on this HOST computer?\n\nYes = configure trusted clients.\nNo = disable LAN and keep local chat.\nCancel = change nothing.')
        if action is None:return
        if action is False:
            backup(cyber_lan.CONFIG);cyber_lan.atomic_json(cyber_lan.CONFIG,{'enabled':False})
            messagebox.showinfo('LAN disabled','LAN is disabled. Restart Proxy/Cyber.\nExisting profile and UIN data were not changed.\nExisting HTTP proxy binding and firewall rules are unchanged.');return
        host=simpledialog.askstring('Host computer IP','Enter THIS computer\x27s LAN or private VPN IPv4 address.\nExamples: 192.168.1.50 or 100.x VPN address\nDo not enter 127.0.0.1 or the other computer\x27s IP.',initialvalue=settings['host_ip'] or '')
        if host is None:return
        host=cyber_lan.private_ipv4(host)
        # Binding an ephemeral port verifies that the address belongs to this host.
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as probe:probe.bind((host,0))
        clients=simpledialog.askstring('Trusted client computer(s)','Enter the OTHER computer\x27s LAN or private VPN IPv4 address.\nFor remote users, enter their private VPN 100.x address.\nFor several computers, separate addresses with commas.',initialvalue=','.join(settings['allowed_clients']))
        if clients is None:return
        proposed={'enabled':True,'host_ip':host,'allowed_clients':[v.strip() for v in clients.split(',') if v.strip()]}
        # Use the same strict validation as the runtime before writing any setting.
        temp=ROOT/'cyber_lan_config.validation.tmp'
        try:
            cyber_lan.atomic_json(temp,proposed);validated=cyber_lan.read_settings(temp)
        finally:temp.unlink(missing_ok=True)
        share=messagebox.askyesno('Shared proxy','Also make this HOST\x27s proxy reachable on TCP 8081?\n\nThis backs up proxy.ini and changes only server.bind to 0.0.0.0 and server.port to 8081. Other setting values are preserved.\nLocal proxy access continues to work.')
        cfg=None
        if share:
            cfg=configparser.ConfigParser();cfg.read(ROOT/'proxy.ini',encoding='utf-8')
            if not cfg.has_section('server'):cfg.add_section('server')
            cfg.set('server','bind','0.0.0.0');cfg.set('server','port','8081')
        paths=[cyber_lan.CONFIG]+([ROOT/'proxy.ini'] if cfg is not None else [])
        snapshots={p:p.read_bytes() if p.exists() else None for p in paths}
        for p in paths:backup(p)
        try:
            if cfg is not None:
                output=io.StringIO();cfg.write(output)
                with tempfile.NamedTemporaryFile(dir=ROOT,prefix='proxy.ini.',suffix='.tmp',delete=False) as f:
                    pending=Path(f.name);f.write(output.getvalue().encode('utf-8'))
                try:os.replace(pending,ROOT/'proxy.ini')
                finally:pending.unlink(missing_ok=True)
            cyber_lan.atomic_json(cyber_lan.CONFIG,validated)
        except Exception:
            for path,content in snapshots.items():
                if content is None:path.unlink(missing_ok=True)
                else:path.write_bytes(content)
            raise
        commands=cyber_lan.firewall_commands(validated)
        (ROOT/'LAN_FIREWALL_COMMANDS.txt').write_text('Run these commands manually in PowerShell as Administrator. Use only a trusted LAN or private VPN overlay; do NOT port-forward 8081 to the public Internet.\nNo router port forwarding is required or recommended.\n\nHOST computer (first two commands):\n'+commands[0]+'\n'+commands[1]+'\n\nCLIENT computer (third command):\n'+commands[2]+'\n\nRestart Proxy/Cyber on the HOST. On the CLIENT configure CyberBuddy proxy to '+host+':8081, recipient IP '+host+', UIN 1111, private mode. Use a distinct own UIN.\n',encoding='utf-8')
        messagebox.showinfo('LAN / VPN configuration saved','Configuration saved with backups. Memory and UIN files were not modified.\n\n1. Open LAN_FIREWALL_COMMANDS.txt and apply the HOST/CLIENT rules on the appropriate computers.\n2. Restart Proxy/Cyber on this HOST.\n3. Check the native window shows the LAN address listening.\n\nIf a UDP port is occupied, first close the original CyberBuddy app on the HOST and restart the services. Do not enable socket sharing.')
    except Exception as error:messagebox.showerror('LAN setup stopped',str(error))
    finally:ui.destroy()
if __name__=='__main__':main()
