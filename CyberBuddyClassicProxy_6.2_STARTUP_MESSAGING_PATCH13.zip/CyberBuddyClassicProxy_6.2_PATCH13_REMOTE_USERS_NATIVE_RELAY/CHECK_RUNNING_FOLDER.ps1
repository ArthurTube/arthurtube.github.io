# Read-only. Does not start, stop or alter CyberBuddy or its saved data.
$ErrorActionPreference = 'Continue'
Write-Host 'CyberBuddy 6.2 - running process and folder evidence'
$connections = @(Get-NetTCPConnection -State Listen -LocalPort 8081 -ErrorAction SilentlyContinue)
$ownerIds = @($connections | Select-Object -ExpandProperty OwningProcess -Unique)
$processes = @(Get-CimInstance Win32_Process | Where-Object {
 ($_.Name -match '^python(w)?\.exe$') -and
 (($_.CommandLine -match 'proxy\.py|CYBER_REPLY_TEST\.py|START_PROXY_AND_CYBER\.py') -or ($ownerIds -contains $_.ProcessId))
})
foreach ($item in $processes) {
 Write-Host ''
 Write-Host ('PID: ' + $item.ProcessId)
 Write-Host ('Python: ' + $item.ExecutablePath)
 Write-Host ('Command: ' + $item.CommandLine)
 if ($ownerIds -contains $item.ProcessId) { Write-Host 'THIS PROCESS OWNS TCP PORT 8081' }
}
if ($processes.Count -eq 0) { Write-Host 'No matching Python process visible. This does not confirm an installation folder.' }
Write-Host ''
Write-Host 'Use absolute script paths above as evidence. Relative commands alone do not reveal the working folder.'
Write-Host 'After update, the launcher prints Installation folder and the native chat prints Bot module and Memory file.'
Write-Host 'Do not infer the active folder from the shortcut name or installer default.'
Read-Host 'Press Enter to close'
