@echo off
cd /d "%~dp0"
where py >nul 2>nul && (py -3 CONFIGURE_EMAIL_BRIDGE.py & pause & exit /b)
python CONFIGURE_EMAIL_BRIDGE.py
pause
