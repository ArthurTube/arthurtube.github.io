"""Optional local Ollama conversation. Fixed loopback API, no keys."""
import json, threading, re
from pathlib import Path
from urllib.request import Request, build_opener, ProxyHandler
from urllib.error import URLError
CONFIG=Path(__file__).with_name('cyber_ai_config.json')
HISTORY={};LOCK=threading.Lock()
def answer(user,question):
    try:config=json.loads(CONFIG.read_text(encoding='utf-8'))
    except (OSError,ValueError):config={}
    if not config.get('enabled',True):return 'Local AI is disabled.'
    model=config.get('model','qwen2.5:0.5b')
    if not isinstance(model,str) or 'cloud' in model.lower():return 'Choose a downloaded local model in cyber_ai_config.json.'
    key=str(user)
    with LOCK:
        history=list(HISTORY.get(key,[]))
    messages=[{'role':'system','content':'You are Cyber, an unofficial local conversational AI recreation for CyberBuddy inspired by the classic 2002 bot. The original bot was written by John DeFino; the original 3D character was credited to Bob Norris. Your purpose is conversation and learning. Never deny being a conversational AI. Do not claim to be the original program. Memory and commands are handled by the application, so do not claim to have saved, deleted, delivered or researched anything yourself. Always answer in English. Give short plain-text answers, at most three sentences. Do not output protocol markers or animation commands. You have no web browsing. Do not claim to be the original Cyber software or claim actions you did not perform. Say when you do not know.'}]+history+[{'role':'user','content':str(question)[:4000]}]
    payload={'model':model,'messages':messages,'stream':False,'options':{'num_predict':120,'num_ctx':2048}}
    request=Request('http://127.0.0.1:11434/api/chat',data=json.dumps(payload).encode('utf-8'),headers={'Content-Type':'application/json'})
    try:
        with build_opener(ProxyHandler({})).open(request,timeout=45) as response:
            result=json.loads(response.read(131072).decode('utf-8'))
        text=result.get('message',{}).get('content','')
        if not isinstance(text,str) or not text.strip():return 'Local AI returned no answer.'
        text=' '.join(text.split()).replace('&&',' and ')[:1500]
        if re.search(r'\bI(?: am|\x27m) (?:not|only)[^.]{0,80}\b(?:conversational|text.based commands)',text,re.I):
            text="I'm Cyber, an unofficial conversational AI recreation for CyberBuddy. You can chat with me and teach me things."
    except (OSError,URLError,ValueError,TypeError):
        return 'Local AI is unavailable. Start Ollama and install the model using SETUP_LOCAL_AI.bat.'
    with LOCK:
        if key not in HISTORY and len(HISTORY)>=100:HISTORY.pop(next(iter(HISTORY)))
        HISTORY[key]=(history+[{'role':'user','content':str(question)[:4000]},{'role':'assistant','content':text}])[-8:]
    return text
