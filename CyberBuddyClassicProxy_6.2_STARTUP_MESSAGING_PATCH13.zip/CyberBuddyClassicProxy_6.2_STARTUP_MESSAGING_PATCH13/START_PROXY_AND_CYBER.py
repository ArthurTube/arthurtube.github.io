"""Start the local proxy and native Cyber bot together on Windows."""
import ctypes, os, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
    if os.name != "nt":
        print("This launcher is for Windows."); return 1
    kernel=ctypes.WinDLL("kernel32",use_last_error=True)
    kernel.CreateMutexW.restype=ctypes.c_void_p
    mutex=kernel.CreateMutexW(None,False,"Local\\CyberBuddyClassicProxyCombined39")
    if not mutex: raise ctypes.WinError(ctypes.get_last_error())
    if ctypes.get_last_error()==183:
        print("The combined launcher is already running. Use its existing windows.")
        kernel.CloseHandle(ctypes.c_void_p(mutex));return 1
    children=[]
    try:
        print("CyberBuddy Classic Proxy 6.2 - Startup Messaging Patch 13")
        print("Installation folder:", ROOT)
        print("Python:", sys.executable)
        print("Proxy script:", ROOT / "proxy.py")
        print("Native chat script:", ROOT / "CYBER_REPLY_TEST.py")
        print("Starting Proxy and Cyber. Keep these windows open.")
        print("CyberBuddy proxy: 127.0.0.1, port 8081")
        print("Cyber Chat: recipient 127.0.0.2, Private mode; bot UIN 1111")
        print("Keep the original CyberBuddy application open separately.")
        print("Press Ctrl+C here to stop both services.")
        for script in ("proxy.py","CYBER_REPLY_TEST.py","ENSURE_SERVER_BASED_MESSAGING.py"):
            children.append(subprocess.Popen([sys.executable,str(ROOT/script)],cwd=ROOT,creationflags=subprocess.CREATE_NEW_CONSOLE))
        while all(p.poll() is None for p in children): time.sleep(0.5)
        print("A service stopped. Check its error window before restarting.")
    except KeyboardInterrupt: print("Stopping Proxy and Cyber.")
    finally:
        for p in children:
            if p.poll() is None:p.terminate()
        for p in children:
            try:p.wait(timeout=5)
            except subprocess.TimeoutExpired:p.kill();p.wait()
        kernel.CloseHandle(ctypes.c_void_p(mutex))
    return 0
if __name__=="__main__":raise SystemExit(main())
