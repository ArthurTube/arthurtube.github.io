@echo off
cd /d "%~dp0"
if not exist "CyberBud.exe" (echo CyberBud.exe is missing.& pause& exit /b 1)
start "" "%~dp0CyberBud.exe"
