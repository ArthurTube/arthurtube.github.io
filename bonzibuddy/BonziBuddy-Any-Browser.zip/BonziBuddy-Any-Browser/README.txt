Run OPEN_BONZI_IN_DEFAULT_BROWSER.bat. Windows opens the site in your default browser, including Microsoft Edge, Google Chrome, Firefox, Opera or Brave when selected as default.
This opens an external browser. It does not replace the Internet Explorer component inside BonziBUDDY. Windows execution remains untested.
