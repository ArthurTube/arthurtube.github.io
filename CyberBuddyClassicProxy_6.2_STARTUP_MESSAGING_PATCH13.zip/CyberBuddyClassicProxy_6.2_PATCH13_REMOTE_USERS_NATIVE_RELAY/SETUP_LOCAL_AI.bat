@echo off
where ollama >nul 2>nul
if errorlevel 1 (
 echo Install Ollama from https://ollama.com then run this file again.
 pause
 exit /b 1
)
ollama pull qwen2.5:0.5b
pause
