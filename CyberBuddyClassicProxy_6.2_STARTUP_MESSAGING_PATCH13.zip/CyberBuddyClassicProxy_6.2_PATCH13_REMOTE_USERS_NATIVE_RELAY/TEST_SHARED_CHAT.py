"""Isolated HTTP regression tests. No live directory or mail bridges are used."""
import concurrent.futures
import http.client
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import threading
import time
import unittest
import urllib.parse


class SharedChatTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        root = Path(cls.temp.name)
        for name in ('proxy.py', 'Chat.html'):
            shutil.copyfile(Path(__file__).resolve().parent / name, root / name)
        spec = importlib.util.spec_from_file_location('isolated_chat_proxy', root / 'proxy.py')
        cls.proxy = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.proxy)
        cls.server = cls.proxy.ThreadedTCPServer(('127.0.0.1', 0), cls.proxy.ProxyHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()
        cls.temp.cleanup()

    def setUp(self):
        p = self.proxy
        with p.CHAT_LOCK:
            p.CHAT_USERS.clear()
            p.CHAT_QUEUES.clear()
            p.CHAT_LAST_TARGET.clear()
        Path(p.CHAT_DIRECTORY_STATE_FILE).unlink(missing_ok=True)
        p.UIN_REGISTRATION_FILE.unlink(missing_ok=True)

    def req(self, path, data=None):
        connection = http.client.HTTPConnection(*self.server.server_address, timeout=3)
        body = urllib.parse.urlencode(data) if data is not None else None
        connection.request('POST' if data is not None else 'GET', path, body,
                           {'Content-Type': 'application/x-www-form-urlencoded'} if data is not None else {})
        response = connection.getresponse()
        content = response.read()
        charset = 'utf-8' if path.lower() == '/chat.html' else 'cp1252'
        connection.close()
        self.assertEqual(response.status, 200)
        return content.decode(charset)

    def form(self, endpoint, **fields):
        return self.req('/cgi-bin/' + endpoint + '?' + urllib.parse.urlencode(fields))

    def publish(self):
        self.form('uinlister.exe', action='y', uin='10001', name="Alice's Buddy", comments='Hi')
        self.req('/cgi-bin/uinlister.exe', {'action':'y','uin':'10002','name':'Bob'})

    def test_native_contact_status_post(self):
        self.req('/cgi-bin/CBonline2.exe?L10001&&Alice&&2_12_26&&Account&&192_168_1_2_')
        self.req('/cgi-bin/CBonline2.exe?L10002&&Bob&&2_12_26&&Account&&192_168_1_3_')
        self.proxy.CHAT_QUEUES['10001'] = [{'text': 'keep me'}]
        before = dict(self.proxy.CHAT_USERS['10001'])
        connection = http.client.HTTPConnection(*self.server.server_address, timeout=3)
        connection.request('POST', '/cgi-bin/CBonline2.exe',
                           '10001\r10001\r99999\r',
                           {'User-Agent': 'clst&&10002&&Bob&&2_12_26&&Account&&192_168_1_3_'})
        response = connection.getresponse()
        result = response.read().decode('cp1252')
        connection.close()
        self.assertEqual(response.status, 200)
        self.assertEqual(len(result.splitlines()), 1)
        self.assertTrue(result.startswith('10001&&192.168.1.2&&'))
        self.assertEqual(self.proxy.CHAT_USERS['10001'], before)
        self.assertEqual(len(self.proxy.CHAT_QUEUES['10001']), 1)
        self.assertNotIn('100011000199999', self.proxy.CHAT_USERS)
        self.assertNotIn('99999', self.proxy.CHAT_USERS)
        self.req('/cgi-bin/CBonline2.exe?l10001&&Alice&&2_12_26&&Account&&192_168_1_2_')
        self.assertEqual(self.proxy._native_contact_status('10001\r'), b'')

    def test_double_separator_login_and_publication(self):
        self.req('/cgi-bin/CBonline2.exe?L10001&&Alice&&4_13_9&&&&192_168_1_2')
        self.assertEqual(self.proxy.CHAT_USERS['10001']['name'], 'Alice')
        self.req('/cgi-bin/UINlister.exe?Y10001&&Alice&&Hello')
        self.assertEqual(self.proxy.CHAT_USERS['10001']['comments'], 'Hello')
        self.assertTrue(self.proxy.CHAT_USERS['10001']['published'])
        self.assertTrue(self.req('/cgi-bin/CBonline2.exe?G10001').startswith('10001&&192.168.1.2&&'))

    def test_registered_but_offline_lookup(self):
        number = self.req('/cgi-bin/uinserver.exe?U0&&TestBuddy&&4&&Account&&IP')[3:]
        result = self.req('/cgi-bin/CBonline2.exe?G' + number)
        self.assertEqual(result, '')
        self.assertNotIn(number, self.proxy.CHAT_USERS)

    def test_native_ping_parser_fields_and_saved_address(self):
        self.req('/cgi-bin/CBonline2.exe?L10001&&Alice&&4_13_9&&&&192_168_1_2_')
        self.req('/cgi-bin/UINlister.exe?Y10001&&Alice&&Hi')
        self.proxy.CHAT_USERS.clear()
        self.proxy._chat_directory_load_state()
        response = self.req('/cgi-bin/CBonline2.exe?G10001')
        # Reproduce the three successive && extractions in CyberBud.exe.
        fields = response.strip().split('&&')
        self.assertEqual(fields[:2], ['10001', '192.168.1.2'])
        self.assertRegex(fields[2], r'^\d{2}-\d{2} \d{2}:\d{2}$')
        self.assertNotIn('$$', response)
        self.form('cbonline2.exe', uin='10001', action='poll')
        self.assertEqual(self.proxy.CHAT_USERS['10001']['ip'], '192.168.1.2')
        self.req('/cgi-bin/CBonline2.exe?L10001&&Alice&&4&&&&bad_ip')
        self.assertEqual(self.req('/cgi-bin/CBonline2.exe?G10001'), '')

    def test_native_lowercase_logout_clears_presence_keeps_identity(self):
        self.req('/cgi-bin/CBonline2.exe?L10001&&Alice&&2_12_26&&Account&&192_168_1_2')
        self.req('/cgi-bin/UINlister.exe?Y10001&&Alice&&Hi')
        self.assertTrue(self.req('/cgi-bin/CBonline2.exe?G10001'))
        self.assertEqual(self.req('/cgi-bin/CBonline2.exe?l10001&&Alice&&2_12_26&&Account&&192_168_1_2'), '')
        self.assertEqual(self.proxy.CHAT_USERS['10001']['last_seen'], 0)
        self.assertEqual(self.req('/cgi-bin/CBonline2.exe?G10001'), '')
        self.assertTrue(self.proxy.CHAT_USERS['10001']['published'])
        self.req('/cgi-bin/CBonline2.exe?L10001&&Alice&&2_12_26&&Account&&192_168_1_2')
        self.assertTrue(self.req('/cgi-bin/CBonline2.exe?G10001'))

    def test_browser_directory_get_and_post(self):
        self.publish()
        text = self.form('uinlister.exe', action='A')
        self.assertIn("$$USER=10001|Alice's Buddy", text)
        self.assertIn('$$USER=10002|Bob', text)
        self.assertEqual(set(self.proxy.CHAT_USERS), {'10001','10002'})

    def test_round_trip_and_no_duplicate_delivery(self):
        self.publish()
        for sender, recipient, message in [('10001','10002','Hello Bob'),('10002','10001','Hi Alice')]:
            sent = self.req('/cgi-bin/cbonline2.exe', {'uin':sender,'sendto':recipient,'message':message})
            self.assertIn('$$SENT=1', sent)
            received = self.form('cbonline2.exe', uin=recipient, action='poll')
            self.assertIn('$$MESSAGE='+message, received)
            self.assertNotIn('$$MESSAGE=', self.req('/cgi-bin/cbonline2.exe', {'uin':recipient,'action':'poll'}))

    def test_ping_and_login_do_not_consume_messages(self):
        self.publish()
        self.form('cbonline2.exe', uin='10001', sendto='10002', message='Keep this')
        ping = self.form('cbonline2.exe', uin='10002', action='g', sndto='10001')
        self.assertIn('$$PINGONLINE=1', ping)
        self.req('/cgi-bin/cbonline2.exe?L10002&Bob&4.13.9&&')
        self.assertIn('$$MESSAGE=Keep this', self.req('/cgi-bin/cbonline2.exe', {'uin':'10002','action':'poll'}))

    def test_original_positional_directory_lookup_and_contact(self):
        self.req('http://thecyberbuddy.com/cgi-bin/uinlister.exe?Y10001&Alice&Hi')
        html = self.req('/cgi-bin/uinlister.exe?A')
        self.assertIn('?u10001', html)
        self.assertIn('Alice', self.req('/cgi-bin/uinlister.exe?u10001'))
        self.assertEqual(self.req('/cgi-bin/UIN/10001.cbb'), '$$UIN10001\r\n')
        found = self.req('/cgi-bin/cbonline2.exe?G10001')
        self.assertEqual(found, '')  # Published without a native login IP
        self.assertEqual(self.req('/cgi-bin/cbonline2.exe?G99999'), '')

    def test_presence_is_not_rolled_back_by_directory(self):
        self.publish()
        self.proxy.CHAT_USERS['10002']['last_seen'] = 1
        self.proxy._chat_directory_save_state()
        self.form('cbonline2.exe', uin='10002', action='poll')
        self.req('/cgi-bin/uinlister.exe?A')
        self.assertIn('$$PINGONLINE=1', self.form('cbonline2.exe', action='g', sndto='10002'))

    def test_published_state_survives_reload(self):
        self.publish()
        self.proxy.CHAT_USERS.clear()
        self.proxy._chat_directory_load_state()
        self.assertEqual(set(self.proxy.CHAT_USERS), {'10001','10002'})

    def test_simultaneous_publications_persist_valid_complete_json(self):
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            list(pool.map(lambda i:self.proxy._publish_remote_uin(str(20000+i),'Test'),range(30)))
        saved = json.loads(Path(self.proxy.CHAT_DIRECTORY_STATE_FILE).read_text())
        self.assertEqual(len(saved), 30)

    def test_browser_page_served_locally(self):
        self.assertIn('Browser Chat', self.req('/Chat.html'))

    def test_only_published_users_in_directory(self):
        self.publish()
        self.form('cbonline2.exe', uin='10003', action='poll')
        self.assertNotIn('$$USER=10003', self.form('uinlister.exe', action='A'))

    def test_native_raw_poll_receives_once(self):
        self.publish()
        self.req('/cgi-bin/cbonline2.exe', {'uin':'10001','sendto':'10002','message':'Native poll test'})
        def raw_poll():
            c = http.client.HTTPConnection(*self.server.server_address, timeout=3)
            c.request('POST','/cgi-bin/cbonline2.exe','10002\r\n',
                      {'Content-Type':'application/octet-stream'})
            response = c.getresponse()
            text = response.read().decode('cp1252')
            c.close()
            self.assertEqual(response.status,200)
            return text
        self.assertIn('$$MESSAGE=Native poll test',raw_poll())
        self.assertNotIn('$$MESSAGE=',raw_poll())

    def test_offline_published_contact_lookup_is_retained(self):
        self.publish()
        self.proxy.CHAT_USERS['10002']['last_seen'] = 1
        reply = self.req('/cgi-bin/cbonline2.exe?G10002')
        self.assertEqual(reply, '')

    def test_native_login_preserves_pending_message(self):
        self.publish()
        self.req('/cgi-bin/cbonline2.exe',{'uin':'10001','sendto':'10002','message':'Pending'})
        self.req('/cgi-bin/cbonline2.exe?L10002&Bob&4.13.9&&')
        self.assertEqual(len(self.proxy.CHAT_QUEUES['10002']),1)

    def test_positional_cp1252_name_and_empty_comment(self):
        self.req('/cgi-bin/uinlister.exe?Y10004&Jo%E3o&')
        self.assertEqual(self.proxy.CHAT_USERS['10004']['name'],'João')
        self.assertEqual(self.proxy.CHAT_USERS['10004']['comments'],'')

    def test_uin_registration_exact_native_response(self):
        response = self.req('/cgi-bin/uinserver.exe?U0&&Bob&&2_13_9&&Bob_&&192_168_1_2_')
        self.assertRegex(response, r'^UIN[0-9]+$')
        self.assertNotIn('$$',response)
        self.assertNotIn('0',self.proxy.CHAT_USERS)
        self.assertNotIn(response[3:],self.proxy.CHAT_USERS)

    def test_uin_registration_unique_stable_and_persistent(self):
        self.publish()
        first = self.req('/cgi-bin/uinserver.exe?U0&&Alice&&2_13_9&&AccountA&&ipA')
        second = self.req('/cgi-bin/uinserver.exe?U0&&Bob&&2_13_9&&AccountB&&ipB')
        self.assertNotEqual(first,second)
        self.assertNotIn(first[3:],{'10001','10002'})
        self.assertEqual(first,self.req('/cgi-bin/uinserver.exe?U0&&Alice&&4_13_9&&AccountA&&ipA'))
        saved = json.loads(self.proxy.UIN_REGISTRATION_FILE.read_text())
        self.assertEqual(set(saved.values()),{first[3:],second[3:]})

    def test_concurrent_native_registration_unique(self):
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            replies=list(pool.map(lambda i:self.req(
                '/cgi-bin/uinserver.exe?U0&&Buddy'+str(i)+'&&4_13_9&&Account'+str(i)+'&&IP'),range(20)))
        self.assertEqual(len(set(replies)),20)
        self.assertEqual(len(json.loads(self.proxy.UIN_REGISTRATION_FILE.read_text())),20)

    def test_bad_registration_does_not_allocate(self):
        for query in ('U0','U0&&&&4_13_9&&Account&&IP','U1000&&Bob&&4_13_9&&Account&&IP'):
            c=http.client.HTTPConnection(*self.server.server_address,timeout=3)
            c.request('GET','/cgi-bin/uinserver.exe?'+query)
            response=c.getresponse();payload=response.read();c.close()
            self.assertEqual(response.status,400)
            self.assertNotRegex(payload.decode(),r'^UIN[0-9]+$')
        self.assertFalse(self.proxy.UIN_REGISTRATION_FILE.exists())

    def test_corrupt_registry_does_not_reset_or_allocate(self):
        self.proxy.UIN_REGISTRATION_FILE.write_text('{broken')
        c=http.client.HTTPConnection(*self.server.server_address,timeout=3)
        c.request('GET','/cgi-bin/uinserver.exe?U0&&Bob&&4_13_9&&Account&&IP')
        response=c.getresponse();response.read();c.close()
        self.assertEqual(response.status,400)
        self.assertEqual(self.proxy.UIN_REGISTRATION_FILE.read_text(),'{broken')


if __name__ == '__main__':
    unittest.main(verbosity=2)
