"""Opt-in native LAN transport settings. No changes to user profiles."""
import ipaddress,json,os,socket,tempfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CONFIG=ROOT/'cyber_lan_config.json'
STATUS=ROOT/'cyber_native_status.json'
_PRIVATE=tuple(ipaddress.ip_network(n) for n in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16','100.64.0.0/10'))

def private_ipv4(value):
    address=ipaddress.ip_address(str(value).strip())
    if address.version!=4 or not any(address in network for network in _PRIVATE):raise ValueError('Use a trusted LAN/VPN IPv4 address (10.x, 172.16-31.x, 192.168.x, or 100.64-127.x overlay VPN).')
    return str(address)

def read_settings(path=None):
    path=Path(path) if path else CONFIG
    try:data=json.loads(path.read_text(encoding='utf-8'))
    except FileNotFoundError:
        host=detect_private_host()
        return {'enabled':bool(host),'host_ip':host,'allowed_clients':[],'auto':True}
    if not isinstance(data,dict) or type(data.get('enabled',False)) is not bool:raise ValueError('Invalid native LAN settings')
    if not data.get('enabled',False):return {'enabled':False,'host_ip':None,'allowed_clients':[],'auto':False}
    host=private_ipv4(data.get('host_ip',''))
    clients=data.get('allowed_clients',[])
    if not isinstance(clients,list) or len(clients)>32:raise ValueError('Provide 0 to 32 trusted client IPv4 addresses.')
    clients=list(dict.fromkeys(private_ipv4(ip) for ip in clients))
    if host in clients:raise ValueError('Client addresses must belong to the other computer(s), not this server.')
    return {'enabled':True,'host_ip':host,'allowed_clients':clients,'auto':False}

def detect_private_host():
    """Best-effort private LAN/VPN address owned by this PC; never returns a public address."""
    candidates=[]
    try:
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as probe:
            probe.connect(('192.0.2.1',9))
            candidates.append(probe.getsockname()[0])
    except OSError: pass
    try:
        candidates.extend(socket.gethostbyname_ex(socket.gethostname())[2])
        candidates.extend(item[4][0] for item in socket.getaddrinfo(socket.gethostname(),None,socket.AF_INET))
    except OSError: pass
    for value in candidates:
        try:
            ip=ipaddress.ip_address(value)
            if ip.version==4 and not ip.is_loopback and any(ip in n for n in _PRIVATE):
                return str(ip)
        except ValueError: pass
    return None

def _same_private_segment(peer,host):
    """Auto mode accepts only the host's private segment; it never accepts public Internet peers."""
    try:
        p=ipaddress.ip_address(peer); h=ipaddress.ip_address(host)
        if p.version!=4 or h.version!=4:return False
        if not any(p in n for n in _PRIVATE):return False
        if h in ipaddress.ip_network('100.64.0.0/10'):
            return p in ipaddress.ip_network('100.64.0.0/10')
        return p in ipaddress.ip_network(str(h)+'/24',strict=False)
    except ValueError:return False

def allowed_peer(address,settings):
    try:ip=ipaddress.ip_address(address)
    except ValueError:return False
    if ip.version!=4:return False
    # Loopback preserves the existing local bot. LAN peers must be explicit.
    if ip.is_loopback:return True
    if not settings.get('enabled'):return False
    if settings.get('auto'):
        return _same_private_segment(str(ip),settings.get('host_ip'))
    return str(ip)==settings['host_ip'] or str(ip) in settings['allowed_clients']

def atomic_json(path,value):
    path=Path(path)
    with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=path.parent,prefix=path.name+'.',suffix='.tmp',delete=False) as f:
        temp=Path(f.name)
        try:json.dump(value,f,indent=2)
        except BaseException:f.close();temp.unlink(missing_ok=True);raise
    try:os.replace(temp,path)
    finally:temp.unlink(missing_ok=True)

def write_status(bindings,settings,active=True,path=None):
    usable=[list(pair) for pair in bindings]
    lan=bool(settings['enabled'] and any(ip==settings['host_ip'] for ip,port in bindings))
    address=settings['host_ip'] if lan else '' if settings['enabled'] else '127.0.0.2' if any(ip=='127.0.0.2' for ip,port in bindings) else ''
    atomic_json(path or STATUS,{'active':bool(active),'updated':time.time(),'pid':os.getpid(),'bindings':usable,'lan_ready':lan,'advertised_ip':address if active else ''})

def advertised_ip(path=None,now=None):
    try:
        data=json.loads(Path(path or STATUS).read_text(encoding='utf-8'));stamp=float(data.get('updated',0))
        age=(time.time() if now is None else now)-stamp
        if data.get('active') is not True or age<0 or age>30:return ''
        ip=ipaddress.ip_address(data.get('advertised_ip',''))
        if ip.version!=4:return ''
        if str(ip)=='127.0.0.2':return str(ip)
        return private_ipv4(str(ip))
    except (OSError,ValueError,TypeError):return ''

def firewall_commands(settings):
    if not settings['enabled']:return []
    host=private_ipv4(settings['host_ip']);clients=','.join(private_ipv4(v) for v in settings['allowed_clients'])
    return [
      "New-NetFirewallRule -DisplayName 'CyberBuddy Native LAN 12 UDP' -Direction Inbound -Action Allow -Protocol UDP -LocalPort 80,4010 -LocalAddress "+host+" -RemoteAddress "+clients+" -Profile Private",
      "New-NetFirewallRule -DisplayName 'CyberBuddy Native LAN 12 HTTP' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8081 -RemoteAddress "+clients+" -Profile Private",
      "New-NetFirewallRule -DisplayName 'CyberBuddy Native LAN 12 Client Replies' -Direction Inbound -Action Allow -Protocol UDP -LocalPort 80,4010 -RemoteAddress "+host+" -Profile Private",
    ]
