#!/usr/bin/env python3
from pathlib import Path
import configparser

ROOT=Path(__file__).resolve().parent
INI=ROOT/'proxy.ini'
PRESETS={
 '1':('Gmail','pop.gmail.com',995,'smtp.gmail.com',465,'ssl'),
 '2':('Outlook / Microsoft 365','outlook.office365.com',995,'smtp-mail.outlook.com',587,'starttls'),
 '3':('Yahoo Mail','pop.mail.yahoo.com',995,'smtp.mail.yahoo.com',465,'ssl'),
}
print('CyberBuddy Classic Proxy - Email Bridge Setup')
print('1. Gmail\n2. Outlook / Microsoft 365\n3. Yahoo Mail\n4. Custom POP3/SMTP')
choice=input('Choose provider [1-4]: ').strip()
if choice in PRESETS:
    name,poph,popp,smtph,smtpp,sec=PRESETS[choice]
elif choice=='4':
    name='Custom'
    poph=input('POP3 SSL host: ').strip(); popp=int(input('POP3 SSL port [995]: ') or '995')
    smtph=input('SMTP host: ').strip(); smtpp=int(input('SMTP port [465/587]: '))
    sec=(input('SMTP security [ssl/starttls]: ').strip().lower() or 'ssl')
    if sec not in ('ssl','starttls'): raise SystemExit('Security must be ssl or starttls')
else:
    raise SystemExit('No changes made.')
cfg=configparser.ConfigParser(); cfg.read(INI,encoding='utf-8')
if not cfg.has_section('server'): cfg.add_section('server')
cfg.set('server','bind','127.0.0.1'); cfg.set('server','port','8081')
if not cfg.has_section('pop3_bridge'): cfg.add_section('pop3_bridge')
for k,v in {'enabled':'yes','bind':'127.0.0.1','local_port':'110','remote_host':poph,'remote_port':str(popp)}.items(): cfg.set('pop3_bridge',k,v)
if not cfg.has_section('smtp_bridge'): cfg.add_section('smtp_bridge')
for k,v in {'enabled':'yes','bind':'127.0.0.1','local_port':'25','remote_host':smtph,'remote_port':str(smtpp),'security':sec}.items(): cfg.set('smtp_bridge',k,v)
with INI.open('w',encoding='utf-8') as f: cfg.write(f)
print('\nSaved:',INI)
print('Provider:',name)
print('CyberBuddy POP server: 127.0.0.1 port 110')
print('CyberBuddy SMTP server: 127.0.0.1 port 25')
print('Restart Classic Proxy after changing this configuration.')
print('Use an app password if your mail provider requires one.')
