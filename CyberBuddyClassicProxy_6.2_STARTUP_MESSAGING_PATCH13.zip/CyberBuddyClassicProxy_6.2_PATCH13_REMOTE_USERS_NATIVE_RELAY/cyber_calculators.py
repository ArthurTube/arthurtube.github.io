"""Deterministic chat calculators. No eval, API, or language model math."""
import re,math,calendar,ast,operator,random
from fractions import Fraction as F
from datetime import date,datetime,timedelta,timezone
MONTHS={name.lower():i for i,name in enumerate(calendar.month_name) if name}
ROMANS=((1000,'M'),(900,'CM'),(500,'D'),(400,'CD'),(100,'C'),(90,'XC'),(50,'L'),(40,'XL'),(10,'X'),(9,'IX'),(5,'V'),(4,'IV'),(1,'I'))
def fmt(value):
    if isinstance(value,F):
        if value.denominator==1:return str(value.numerator)
        return format(float(value),'.10g')
    return format(value,'.10g') if isinstance(value,float) else str(value)
def rational(expr):
    if len(expr)>200:raise ValueError()
    expr=expr.replace('×','*').replace('÷','/')
    for word,symbol in [('divided by','/'),('times','*'),('plus','+'),('minus','-')]:expr=re.sub(r'\b'+word+r'\b',symbol,expr)
    tree=ast.parse(expr,mode='eval')
    ops={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv}
    def walk(node):
        if isinstance(node,ast.Constant) and type(node.value) in (int,float):return F(ast.get_source_segment(expr,node))
        if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):return walk(node.operand)*(1 if isinstance(node.op,ast.UAdd) else -1)
        if isinstance(node,ast.BinOp) and type(node.op) in ops:
            value=ops[type(node.op)](walk(node.left),walk(node.right))
            if abs(value)>10**15 or value.denominator>10**15:raise ValueError()
            return value
        raise ValueError()
    return walk(tree.body)
def parsedate(text):
    text=text.strip();text=re.sub(r'(\d)(?:st|nd|rd|th)\b',r'\1',text)
    if re.fullmatch(r'\d{4}-\d{2}-\d{2}',text):return date.fromisoformat(text)
    m=re.fullmatch(r'([a-z]+) (\d{1,2}),? (\d{4})',text)
    if m and m[1] in MONTHS:return date(int(m[3]),MONTHS[m[1]],int(m[2]))
    raise ValueError('Use YYYY-MM-DD or Month Day, Year.')
def shift(day,count,unit):
    if abs(count)>100000:raise ValueError()
    if unit in ('day','week'):return day+timedelta(days=count*(7 if unit=='week' else 1))
    months=count*(12 if unit=='year' else 1);index=day.year*12+day.month-1+months;year,month=divmod(index,12);month+=1
    return date(year,month,min(day.day,calendar.monthrange(year,month)[1]))
def roman(n):
    if not 1<=n<=3999:raise ValueError('Roman conversion supports 1 to 3999.')
    result=''
    for value,symbol in ROMANS:
        count,n=divmod(n,value);result+=symbol*count
    return result
# Base units: meters, kilograms, square meters, cubic meters, m/s, bytes, seconds.
UNITS={}
def units(kind,factor,names):
    for name in names.split('|'):UNITS[name]=(kind,F(str(factor)))
for args in [
 ('length',1,'m|meter|meters'),('length',.01,'cm|centimeter|centimeters'),('length',.001,'mm|millimeter|millimeters'),('length',1000,'km|kilometer|kilometers'),('length',.0254,'in|inch|inches'),('length',.3048,'ft|foot|feet'),('length',.9144,'yard|yards'),('length',1609.344,'mile|miles'),
 ('weight',1,'kg|kilogram|kilograms'),('weight',.001,'g|gram|grams'),('weight',.000001,'mg|milligram|milligrams'),('weight',.000000001,'mcg|microgram|micrograms'),('weight',.45359237,'lb|lbs|pound|pounds'),('weight',.028349523125,'oz|ounce|ounces'),('weight',1000,'tonne|tonnes|metric tons'),('weight',907.18474,'us ton|us tons'),('weight',6.35029318,'stone|stones'),
 ('area',1,'sq m|square meters'),('area',.09290304,'sq ft|square feet'),('area',10000,'hectare|hectares'),('area',4046.8564224,'acre|acres'),('area',1000000,'sq km|square kilometers'),('area',2589988.110336,'sq miles|square miles'),
 ('volume',1,'cubic meters'),('volume',.001,'l|liter|liters|litre|litres'),('volume',.000001,'ml|milliliter|milliliters'),('volume',.003785411784,'us gallon|us gallons'),('volume',.00454609,'imperial gallon|imperial gallons'),
 ('speed',1,'m/s'),('speed',F(5,18),'km/h|kph'),('speed',.44704,'mph'),('speed',F(1852,3600),'knot|knots'),
 ('data',1,'byte|bytes|b'),('data',F(1,8),'bit|bits'),('data',1000,'kb|kilobyte|kilobytes'),('data',1000000,'mb|megabyte|megabytes'),('data',1000000000,'gb|gigabyte|gigabytes'),('data',1000000000000,'tb|terabyte|terabytes'),('data',1024,'kib'),('data',1048576,'mib'),('data',1073741824,'gib'),('data',1099511627776,'tib'),
 ('duration',1,'second|seconds'),('duration',60,'minute|minutes'),('duration',3600,'hour|hours'),('duration',86400,'day|days'),('duration',604800,'week|weeks')]:units(*args)
def calculate(question,today=None):
    today=today or date.today();q=' '.join(str(question).lower().split())
    q=re.sub(r'^cyber\b[,:! ]*','',q).strip(); q=q.rstrip('.?').strip();q=re.sub(r'^what (?:is|are) (?:the )?','',q)
    try:
        # Experimental 37: broad deterministic math engine. Keep this before
        # web/AI routing so arithmetic is never answered from Wikipedia or a model.
        expr=q
        expr=re.sub(r'^(?:calculate|compute|evaluate|solve)\s+','',expr)
        expr=re.sub(r'^(?:what is|what\'s)\s+','',expr)
        expr=expr.replace('×','*').replace('÷','/').replace('−','-')
        expr=re.sub(r'\bto the power of\b','**',expr)
        expr=re.sub(r'(?<=\d)\s*[xX]\s*(?=[\d(+-])','*',expr)
        expr=re.sub(r'(?<!\*)\^(?!\*)','**',expr)
        if re.fullmatch(r'[0-9eE.()+\-*/%*\s]+',expr) and re.search(r'\d',expr):
            tree=ast.parse(expr,mode='eval')
            ops={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv,ast.FloorDiv:operator.floordiv,ast.Mod:operator.mod,ast.Pow:operator.pow}
            def numwalk(node):
                if isinstance(node,ast.Constant) and type(node.value) in (int,float):
                    if abs(node.value)>10**15:raise ValueError()
                    return node.value
                if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
                    v=numwalk(node.operand);return v if isinstance(node.op,ast.UAdd) else -v
                if isinstance(node,ast.BinOp) and type(node.op) in ops:
                    a,b=numwalk(node.left),numwalk(node.right)
                    if isinstance(node.op,ast.Pow) and (abs(b)>100 or abs(a)>10**9):raise ValueError()
                    v=ops[type(node.op)](a,b)
                    if not math.isfinite(float(v)) or abs(v)>10**18:raise ValueError()
                    return v
                raise ValueError()
            value=numwalk(tree.body)
            if isinstance(value,float) and value.is_integer():value=int(value)
            return fmt(value)+'.'
        m=re.fullmatch(r'(?:square root|sqrt)\s*(?:of\s*)?([+-]?[\d.]+)',q)
        if m:
            n=float(m[1])
            if n<0:return 'A real square root is not defined for a negative number.'
            return 'Square root: '+fmt(math.sqrt(n))+'.'
        m=re.fullmatch(r'(?:cube root|cbrt)\s*(?:of\s*)?([+-]?[\d.]+)',q)
        if m:
            n=float(m[1]);v=math.copysign(abs(n)**(1/3),n)
            if abs(v-round(v))<1e-10:v=int(round(v))
            return 'Cube root: '+fmt(v)+'.'
        m=re.fullmatch(r'(?:average|mean) of (.+)',q)
        if m:
            vals=[F(x) for x in re.findall(r'[+-]?(?:\d+(?:\.\d+)?|\.\d+)',m[1])]
            if not vals:return None
            return 'Average = '+fmt(sum(vals,F(0))/len(vals))+'.'
        m=re.fullmatch(r'(?:median) of (.+)',q)
        if m:
            vals=sorted(F(x) for x in re.findall(r'[+-]?(?:\d+(?:\.\d+)?|\.\d+)',m[1]))
            if not vals:return None
            n=len(vals);v=vals[n//2] if n%2 else (vals[n//2-1]+vals[n//2])/2
            return 'Median = '+fmt(v)+'.'
        m=re.fullmatch(r'(\d+)!|factorial of (\d+)',q)
        if m:
            n=int(m[1] or m[2])
            if n>1000:return 'Factorial is limited to 1000.'
            return str(math.factorial(n))+'.'
        if q=='calculator help':return 'Try: factors of 2028; factor pairs of 2028; prime factorization of 2028; GCF of 56 and 80; 20% off 1400; simplify 2/4; 2026 in roman numerals; 20 m to cm; days between 2026-10-14 and 2027-04-03. See CALCULATOR_COMMANDS.txt.'
        m=re.fullmatch(r'(?:gcf|gcd|greatest common factor|mdc|lcm|least common multiple|mmc) of (.+)',q)
        if m:
            values=re.findall(r'[+-]?\d+',m[1]);nums=[int(v) for v in values]
            if not 2<=len(nums)<=10 or re.sub(r'[\d\s,+\-]|\band\b','',m[1]):raise ValueError()
            result=math.lcm(*nums) if q.startswith(('lcm','least','mmc')) else math.gcd(*nums)
            return ('LCM' if q.startswith(('lcm','least','mmc')) else 'GCF')+' = '+str(result)+'.'
        m=re.fullmatch(r'prime factorization of (\d+)',q)
        if m:
            n=int(m[1]);original=n
            if not 2<=n<=10**12:return 'Prime factorization supports integers from 2 to 1,000,000,000,000.'
            factors=[];divisor=2
            while divisor*divisor<=n:
                count=0
                while n%divisor==0:n//=divisor;count+=1
                if count:factors.append(str(divisor)+('^'+str(count) if count>1 else ''))
                divisor=3 if divisor==2 else divisor+2
            if n>1:factors.append(str(n))
            return str(original)+' = '+' x '.join(factors)+'.'
        m=re.fullmatch(r'([+-]?[\d.]+)\s*(?:%|percent)\s*(of|off|more than)\s*([+-]?[\d.]+)',q)
        if m:
            percent=F(m[1]);base=F(m[3]);value=base*percent/100
            if m[2]=='off':value=base-value
            if m[2]=='more than':value=base+value
            return fmt(value)+'.'
        m=re.fullmatch(r'([\d.]+) is what percent of ([\d.]+)',q)
        if m:return fmt(F(m[1])/F(m[2])*100)+'%.'
        m=re.fullmatch(r'(?:convert )?(\d+) (?:to|in) (binary|hexadecimal|hex|roman numerals)',q)
        if m:
            n=int(m[1]);kind=m[2]
            return ('Roman: '+roman(n) if kind=='roman numerals' else kind.title()+': '+(bin(n)[2:] if kind=='binary' else hex(n)[2:].upper()))+'.'
        m=re.fullmatch(r'(?:convert )?([0-9a-fivxlcdm]+) (binary|hex|hexadecimal|roman) (?:to|in) decimal',q)
        if m:
            value,base=m.groups()
            if base=='roman':
                token=value.upper();table=dict((sym,val) for val,sym in ROMANS if len(sym)==1);n=0
                for i,ch in enumerate(token):n+=(-1 if i+1<len(token) and table[ch]<table[token[i+1]] else 1)*table[ch]
                if roman(n)!=token:raise ValueError()
            else:n=int(value,2 if base=='binary' else 16)
            return 'Decimal: '+str(n)+'.'
        m=re.fullmatch(r'(?:simplify |fraction |calculate fractions? )(.+)',q)
        if m and '/' in m[1]:
            value=rational(m[1]);return 'Simplified fraction: '+str(value)+'. Decimal: '+fmt(value)+'.'
        m=re.fullmatch(r'(?:convert )?([+-]?[\d./]+) (?:to|as) (a fraction|fraction|decimal|percent|mixed number)',q)
        if m:
            value=F(m[1]);kind=m[2]
            if kind=='percent':return fmt(value*100)+'%.'
            if kind=='decimal':return fmt(value)+'.'
            if kind=='mixed number':
                whole,rest=divmod(abs(value.numerator),value.denominator);return ('-' if value<0 else '')+str(whole)+(' '+str(F(rest,value.denominator)) if rest else '')+'.'
            return str(value)+'.'
        m=re.fullmatch(r'([\d.]+)% (?:to|as) (decimal|fraction)',q)
        if m:
            value=F(m[1])/100;return (fmt(value) if m[2]=='decimal' else str(value))+'.'
        m=re.fullmatch(r'(simplify )?square root of (\d+)',q)
        if m:
            n=int(m[2]);root=math.isqrt(n)
            if root*root==n:return 'Square root: '+str(root)+'.'
            if m[1]:
                if n>10**12:return 'Radical simplification is limited to 1,000,000,000,000.'
                k=root
                while k>1 and n%(k*k):k-=1
                return 'Square root: '+(str(k)+' x ' if k>1 else '')+'sqrt('+str(n//(k*k))+').'
            return 'Square root approximately '+fmt(math.sqrt(n))+'.'
        m=re.fullmatch(r'(?:convert )?([+-]?[\d.]+)\s+(.+?)\s+(?:to|in)\s+(.+)',q)
        if m:
            value=F(m[1]);source,target=m[2],m[3]
            temps={'c','celsius','f','fahrenheit','k','kelvin'}
            if source in temps and target in temps:
                c=(value-32)*F(5,9) if source in ('f','fahrenheit') else value-F('273.15') if source in ('k','kelvin') else value
                result=c*F(9,5)+32 if target in ('f','fahrenheit') else c+F('273.15') if target in ('k','kelvin') else c
                return fmt(value)+' '+source+' = '+fmt(result)+' '+target+'.'
            if source in ('tons','ton','gallon','gallons') or target in ('tons','ton','gallon','gallons'):return 'Specify US tons or metric tonnes; specify US gallons or imperial gallons.'
            if source in UNITS and target in UNITS:
                a,af=UNITS[source];b,bf=UNITS[target]
                if a!=b:return 'Those units measure different quantities.'
                return fmt(value)+' '+source+' = '+fmt(value*af/bf)+' '+target+'.'+(' KB/MB/GB/TB use powers of 1000; KiB/MiB/GiB/TiB use 1024.' if a=='data' else '')
        m=re.fullmatch(r'(\d+) hours?(?: (\d+) minutes?)? (?:to|in|as) (minutes|decimal hours)',q)
        if m:
            minutes=int(m[1])*60+int(m[2] or 0);return (str(minutes)+' minutes.' if m[3]=='minutes' else fmt(F(minutes,60))+' hours.')
        m=re.fullmatch(r'(?:add )?([+-]?\d+) (days?|weeks?|months?|years?) (?:from|after|to) (.+)',q)
        if m:
            day=today if m[3]=='today' else parsedate(m[3]);result=shift(day,int(m[1]),m[2].rstrip('s'));return result.isoformat()+' ('+result.strftime('%A')+').'
        m=re.fullmatch(r'(?:subtract )?(\d+) (days?|weeks?|months?|years?) (?:ago from|before|ago) (.+)',q)
        if m:
            day=today if m[3]=='today' else parsedate(m[3]);return shift(day,-int(m[1]),m[2].rstrip('s')).isoformat()+'.'
        m=re.fullmatch(r'days between (.+) and (.+)',q)
        if m:return str(abs((parsedate(m[2])-parsedate(m[1])).days))+' days (end date minus start date).'
        m=re.fullmatch(r'(?:how many )?days until (.+)',q)
        if m:return str((parsedate(m[1])-today).days)+' days from today.'
        m=re.fullmatch(r'(?:what )?day of (?:the )?week (?:is )?(.+)',q)
        if m:return parsedate(m[1]).strftime('%A')+'.'
        m=re.fullmatch(r'(?:how many )?days (?:are )?in ([a-z]+) (\d{4})',q)
        if m and m[1] in MONTHS:return str(calendar.monthrange(int(m[2]),MONTHS[m[1]])[1])+' days.'
        m=re.fullmatch(r'(?:how many )?days (?:are )?in (\d{4})',q)
        if m:return str(366 if calendar.isleap(int(m[1])) else 365)+' days.'
        if q in ('day of the year','what day of the year is it'):return 'Day '+str(today.timetuple().tm_yday)+' of '+str(today.year)+'.'
        if q in ('week of the year','what week of the year is it'):return 'ISO week '+str(today.isocalendar().week)+', ISO year '+str(today.isocalendar().year)+'.'
        m=re.fullmatch(r'(?:convert )?(\d{1,2}):(\d{2}) (?:to|in) 12 hour(?: time)?',q)
        if m:return datetime.strptime(m[1]+':'+m[2],'%H:%M').strftime('%I:%M %p')+'.'
        m=re.fullmatch(r'(?:convert )?(\d{1,2}:\d{2}\s*[ap]m) (?:to|in) 24 hour(?: time)?',q)
        if m:return datetime.strptime(re.sub(r'\s*([ap]m)$',r' \1',m[1]).upper(),'%I:%M %p').strftime('%H:%M')+'.'
        m=re.fullmatch(r'(?:convert )?unix timestamp (\d+) (?:to|in) date',q)
        if m:return datetime.fromtimestamp(int(m[1]),timezone.utc).isoformat()+' (UTC).'
        m=re.fullmatch(r'half birthday of (.+)',q)
        if m:return shift(parsedate(m[1]),6,'month').isoformat()+'.'
        m=re.fullmatch(r'(?:pick|random number) (?:a number )?between ([+-]?\d+) and ([+-]?\d+)',q)
        if m:return str(random.randint(int(m[1]),int(m[2])))+'.'
    except (ValueError,TypeError,KeyError,ZeroDivisionError,OverflowError,SyntaxError):return 'I could not calculate that. Check the values, units and date format.'
    return None
